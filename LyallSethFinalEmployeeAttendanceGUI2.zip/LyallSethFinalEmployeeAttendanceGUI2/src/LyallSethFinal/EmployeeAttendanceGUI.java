/**
 * Seth Lyall - MVCTC
 * Nov 29, 2022
 */
package LyallSethFinal;

import java.io.FileNotFoundException;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class EmployeeAttendanceGUI extends Application {
	// The file and the employee attendance class initialization.
	public static java.io.File employeeFile = new java.io.File("empAtt.txt");
	private static EmployeeAttendance employeeAttendance = new EmployeeAttendance();

	// Buttons for listing employees on the table.
	private Button listAllEmployees = new Button("List all Employees");
	private Button listPresentEmployees = new Button("List all Present Employees");
	private Button listAbsentEmployees = new Button("List all Absent Employees");

	// Button for adding a new employee.
	private Button addEmployee = new Button("Add an Employee");

	// Buttons for finding employees by name and performing an action.
	private Button findEmployeeByName = new Button("Find an Employee by Name");
	private Button deleteEmployeeByName = new Button("Delete an Employee by Name");
	private Button markEmployeeAttendanceByName = new Button("Mark an Employee's Attendance by Name");
	private Button markEmployeeAbsenceByName = new Button("Mark an Employee's Absence by Name");

	// Buttons to confirm action.
	private Button confirmAttendance = new Button("Confirm Attendance");
	private Button confirmAbsence = new Button("Confirm Absence");
	private Button confirmEmployee = new Button("Confirm");
	private Button confirmDeletion = new Button("Confirm Deletion");
	private Button confirmName = new Button("Confirm Name");

	// The button for clearing process buttons, text fields, and labels, and
	// returning to the main menu.
	private Button returnToStart = new Button("Return");

	// The label for holding the employees list.
	private Label employeeTableWindow = new Label("");

	// Labels for marking text fields so the user knows what goes where.
	private Label employeeNameLabel = new Label("Employee Name");
	private Label employeeAddressLabel = new Label("Employee Address");
	private Label employeePresenceLabel = new Label("Employee Presence: [Present] or [Absent]");
	private Label employeeArrivalTimeLabel = new Label("Employee Arrival Time: (XX:XX AM/PM)");

	// Text fields for entering employee data.
	private TextField employeeNameTextField = new TextField();
	private TextField employeeAddressTextField = new TextField();
	private TextField employeePresenceTextField = new TextField();
	private TextField employeeArrivalTimeTextField = new TextField();

	// V and HBoxes for holding the UI window and data input.
	private static VBox window = new VBox();
	private VBox employeeDataLabelColumn = new VBox();
	private VBox employeeDataTextFieldColumn = new VBox();
	private HBox employeeDataInput = new HBox();

	// HBoxes for holding the various buttons.
	private HBox buttons1 = new HBox();
	private HBox buttons2 = new HBox();
	private HBox buttons3 = new HBox();

	@Override // Override the start method in the Application class.
	public void start(Stage primaryStage) {
		// Read any older employee records in from empAtt.txt
		readEmployees();

		// Set the properties for text fields and labels.
		employeeNameLabel.setContentDisplay(ContentDisplay.CENTER);
		employeeNameLabel.setPadding(new Insets(5, 5, 5, 5));
		employeeAddressLabel.setContentDisplay(ContentDisplay.CENTER);
		employeeAddressLabel.setPadding(new Insets(5, 5, 5, 5));
		employeePresenceLabel.setContentDisplay(ContentDisplay.CENTER);
		employeePresenceLabel.setPadding(new Insets(5, 5, 5, 5));
		employeeArrivalTimeLabel.setContentDisplay(ContentDisplay.CENTER);
		employeeArrivalTimeLabel.setPadding(new Insets(5, 5, 5, 5));
		employeeNameTextField.setPadding(new Insets(5, 5, 5, 5));
		employeeAddressTextField.setPadding(new Insets(5, 5, 5, 5));
		employeePresenceTextField.setPadding(new Insets(5, 5, 5, 5));
		employeeArrivalTimeTextField.setPadding(new Insets(5, 5, 5, 5));

		// Set the properties for the buttons.
		listAllEmployees.setContentDisplay(ContentDisplay.CENTER);
		listAllEmployees.setPadding(new Insets(5, 5, 5, 5));
		listAllEmployees.setOnAction(e -> allEmployeesTable());
		listPresentEmployees.setContentDisplay(ContentDisplay.CENTER);
		listPresentEmployees.setPadding(new Insets(5, 5, 5, 5));
		listPresentEmployees.setOnAction(e -> presentEmployeesTable());
		listAbsentEmployees.setContentDisplay(ContentDisplay.CENTER);
		listAbsentEmployees.setPadding(new Insets(5, 5, 5, 5));
		listAbsentEmployees.setOnAction(e -> absentEmployeesTable());
		findEmployeeByName.setContentDisplay(ContentDisplay.CENTER);
		findEmployeeByName.setPadding(new Insets(5, 5, 5, 5));
		findEmployeeByName.setOnAction(e -> findAnEmployeeByName());
		addEmployee.setContentDisplay(ContentDisplay.CENTER);
		addEmployee.setPadding(new Insets(5, 5, 5, 5));
		addEmployee.setOnAction(e -> addAnEmployee());
		deleteEmployeeByName.setContentDisplay(ContentDisplay.CENTER);
		deleteEmployeeByName.setPadding(new Insets(5, 5, 5, 5));
		deleteEmployeeByName.setOnAction(e -> deleteAnEmployeeByName());
		markEmployeeAttendanceByName.setContentDisplay(ContentDisplay.CENTER);
		markEmployeeAttendanceByName.setPadding(new Insets(5, 5, 5, 5));
		markEmployeeAttendanceByName.setOnAction(e -> markAttendedByName());
		markEmployeeAbsenceByName.setContentDisplay(ContentDisplay.CENTER);
		markEmployeeAbsenceByName.setPadding(new Insets(5, 5, 5, 5));
		markEmployeeAbsenceByName.setOnAction(e -> markAbsentByName());

		// Buttons for confirming actions.
		confirmEmployee.setContentDisplay(ContentDisplay.CENTER);
		confirmEmployee.setPadding(new Insets(5, 5, 5, 5));
		confirmEmployee.setOnAction(e -> confirmYourEmployee());
		confirmDeletion.setContentDisplay(ContentDisplay.CENTER);
		confirmDeletion.setPadding(new Insets(5, 5, 5, 5));
		confirmDeletion.setOnAction(e -> confirmDeletingEmployee());
		confirmAttendance.setContentDisplay(ContentDisplay.CENTER);
		confirmAttendance.setPadding(new Insets(5, 5, 5, 5));
		confirmAttendance.setOnAction(e -> confirmAttendanceByName());
		confirmAbsence.setContentDisplay(ContentDisplay.CENTER);
		confirmAbsence.setPadding(new Insets(5, 5, 5, 5));
		confirmAbsence.setOnAction(e -> confirmAbsenceByName());
		confirmName.setContentDisplay(ContentDisplay.CENTER);
		confirmName.setPadding(new Insets(5, 5, 5, 5));
		confirmName.setOnAction(e -> confirmEmployeesName());

		// Properties for return to start button.
		returnToStart.setContentDisplay(ContentDisplay.CENTER);
		returnToStart.setPadding(new Insets(5, 5, 5, 5));
		returnToStart.setOnAction(e -> exitButton());

		// Add the main menu buttons to the three button VBoxes.
		buttons1.getChildren().addAll(listAllEmployees, listPresentEmployees, listAbsentEmployees, findEmployeeByName);
		buttons1.setPadding(new Insets(5, 5, 5, 5));
		buttons2.getChildren().addAll(addEmployee, deleteEmployeeByName);
		buttons2.setPadding(new Insets(5, 5, 5, 5));
		buttons3.getChildren().addAll(markEmployeeAttendanceByName, markEmployeeAbsenceByName);
		buttons3.setPadding(new Insets(5, 5, 5, 5));

		// Build the employeeData HBox with the two employee data columns.
		employeeDataInput.getChildren().addAll(employeeDataLabelColumn, employeeDataTextFieldColumn);
		employeeDataInput.setPadding(new Insets(5, 5, 5, 5));

		// Add the employee attendance table, the buttons, and the employeeData text
		// fields to the window VBox.
		window.getChildren().addAll(employeeTableWindow, buttons1, buttons2, buttons3);
		window.setPadding(new Insets(5, 5, 5, 5));

		// Create the scene and put the border pane in the scene.
		Scene scene = new Scene(window, 580, 600);

		// Set the stage title, scene, and show the stage.
		primaryStage.setTitle("Employee Attendance");
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	// Lists all employees with the listAllEmployees function on the table label.
	private void allEmployeesTable() {
		employeeTableWindow.setText(employeeAttendance.listAllEmployees());
	}

	// Sets the table label's text for all present employees using the
	// listPresentEmployees function.
	private void presentEmployeesTable() {
		employeeTableWindow.setText(employeeAttendance.listPresentEmployees());
	}

	// Sets the table label's text for all absent employees using the
	// listAbsentEmployees function.
	private void absentEmployeesTable() {
		employeeTableWindow.setText(employeeAttendance.listAbsentEmployees());
	}

	// Adds the buttons required to enter an employee name and confirm, removes
	// primary menu buttons.
	private void findAnEmployeeByName() {
		window.getChildren().removeAll(buttons1, buttons2, buttons3);
		window.getChildren().addAll(employeeDataInput, confirmName, returnToStart);

		employeeDataLabelColumn.getChildren().addAll(employeeNameLabel);
		employeeDataTextFieldColumn.getChildren().addAll(employeeNameTextField);
	}

	// Sets the table label's text to an employee who has a matching name with
	// findEmployeeByName when confirm is pressed.
	private void confirmEmployeesName() {
		employeeTableWindow.setText(employeeAttendance.findEmployeeByName(employeeNameTextField.getText()));
	}

	// Adds the buttons necessary to add a new employee and removes primary menu
	// buttons.
	private void addAnEmployee() {
		window.getChildren().removeAll(buttons1, buttons2, buttons3);
		window.getChildren().addAll(employeeDataInput, confirmEmployee, returnToStart);

		employeeDataLabelColumn.getChildren().addAll(employeeNameLabel, employeeAddressLabel, employeePresenceLabel,
				employeeArrivalTimeLabel);
		employeeDataTextFieldColumn.getChildren().addAll(employeeNameTextField, employeeAddressTextField,
				employeePresenceTextField, employeeArrivalTimeTextField);
	}

	// Takes the four text fields entered by the user and ensure they have data in
	// them. The data is then checked for exceptions and if successful, the
	// addEmployee function is ran.
	private void confirmYourEmployee() {
		boolean isException = false;
		String na = employeeNameTextField.getText();
		String ad = employeeAddressTextField.getText();
		String pr = employeePresenceTextField.getText();
		String ar = employeeArrivalTimeTextField.getText();
		try {
			pr = employeePresenceTextField.getText();
			if (na == null || na == "") {
				throw new IllegalArgumentException("Please enter a value for each field.");
			} else if (ad == null || ad == "") {
				throw new IllegalArgumentException("Please enter a value for each field.");
			} else if (pr == null || pr == "") {
				throw new IllegalArgumentException("Please enter a value for each field.");
			} else if (ar == null || ar == "") {
				throw new IllegalArgumentException("Please enter a value for each field.");
			}
		} catch (IllegalArgumentException ex) {
			System.out.println("Exception: " + ex.getMessage());
		} finally {
			if (!isException) {
				System.out.println("An employee has been added.");
				employeeAttendance.addEmployee(na, ad, pr, ar);
				writeEmployees();
			}
		}
	}

	// Adds the buttons required to enter an employee name and removes primary menu
	// buttons.
	private void deleteAnEmployeeByName() {
		window.getChildren().removeAll(buttons1, buttons2, buttons3);
		window.getChildren().addAll(employeeDataInput, confirmDeletion, returnToStart);

		employeeDataLabelColumn.getChildren().addAll(employeeNameLabel);
		employeeDataTextFieldColumn.getChildren().addAll(employeeNameTextField);
	}

	// Runs the deleteEmployeeByName function when the confirm button is pressed.
	private void confirmDeletingEmployee() {
		employeeAttendance.deleteEmployeeByName(employeeNameTextField.getText());
		writeEmployees();
	}

	// Adds the required buttons to mark employee attendance given employee name,
	// and removes primary menu buttons.
	private void markAttendedByName() {
		window.getChildren().removeAll(buttons1, buttons2, buttons3);
		window.getChildren().addAll(employeeDataInput, confirmAttendance, returnToStart);

		employeeDataLabelColumn.getChildren().addAll(employeeNameLabel, employeeArrivalTimeLabel);
		employeeDataTextFieldColumn.getChildren().addAll(employeeNameTextField, employeeArrivalTimeTextField);
	}

	// Runs the markEmployeeAttendanceByName function using the employee name text
	// field when the confirm attendance button is pressed.
	private void confirmAttendanceByName() {
		employeeAttendance.markEmployeeAttendanceByName(employeeNameTextField.getText());
		employeeAttendance.setArrivalTimeByName(employeeNameTextField.getText(),
				employeeArrivalTimeTextField.getText());
		writeEmployees();
	}

	// Adds the required buttons to mark employee absence and removes the primary
	// menu buttons.
	private void markAbsentByName() {
		window.getChildren().removeAll(buttons1, buttons2, buttons3);
		window.getChildren().addAll(employeeDataInput, confirmAbsence, returnToStart);

		employeeDataLabelColumn.getChildren().addAll(employeeNameLabel);
		employeeDataTextFieldColumn.getChildren().addAll(employeeNameTextField);
	}

	// Run the markEmployeeAbsenceByName function with the employee name text field
	// when the confirm absence button is pressed.
	private void confirmAbsenceByName() {
		employeeAttendance.markEmployeeAbsenceByName(employeeNameTextField.getText());
		writeEmployees();
	}

	// Closes all unneeded buttons, labels, and text fields other than the primary
	// menu buttons, which are re-opened.
	private void exitButton() {
		window.getChildren().removeAll(confirmAttendance, confirmAbsence, confirmEmployee, confirmDeletion, confirmName,
				returnToStart, employeeNameLabel, employeeAddressLabel, employeePresenceLabel, employeeArrivalTimeLabel,
				employeeNameTextField, employeeAddressTextField, employeePresenceTextField,
				employeeArrivalTimeTextField, employeeDataLabelColumn, employeeDataTextFieldColumn, employeeDataInput);
		employeeDataLabelColumn.getChildren().removeAll(confirmAttendance, confirmAbsence, confirmEmployee,
				confirmDeletion, confirmName, returnToStart, employeeNameLabel, employeeAddressLabel,
				employeePresenceLabel, employeeArrivalTimeLabel, employeeNameTextField, employeeAddressTextField,
				employeePresenceTextField, employeeArrivalTimeTextField, employeeDataLabelColumn,
				employeeDataTextFieldColumn, employeeDataInput);
		employeeDataTextFieldColumn.getChildren().removeAll(confirmAttendance, confirmAbsence, confirmEmployee,
				confirmDeletion, confirmName, returnToStart, employeeNameLabel, employeeAddressLabel,
				employeePresenceLabel, employeeArrivalTimeLabel, employeeNameTextField, employeeAddressTextField,
				employeePresenceTextField, employeeArrivalTimeTextField, employeeDataLabelColumn,
				employeeDataTextFieldColumn, employeeDataInput);
		window.getChildren().addAll(buttons1, buttons2, buttons3);
	}

	// Reads the text file empAtt. empAtt needs at least one character in it to
	// "exist" in certain circumstances.
	public static void readEmployees() {
		System.out.println(employeeFile.getAbsolutePath());
		try {
			java.util.Scanner fileInput = new java.util.Scanner(employeeFile);
			while (fileInput.hasNext()) {
				employeeAttendance.addEmployee(fileInput.nextLine(), fileInput.nextLine(), fileInput.nextLine(),
						fileInput.nextLine());
			}
			fileInput.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			try {
				java.io.PrintWriter fileOutput = new java.io.PrintWriter(employeeFile);
				fileOutput.print(" ");
				fileOutput.close();
			} catch (FileNotFoundException ex) {
				e.printStackTrace();
			}
		}
	}

	// Retrieves the array lists from EmployeeAttendance and writes them to
	// empAtt.txt
	public static void writeEmployees() {
		try {
			java.io.PrintWriter fileOutput = new java.io.PrintWriter(employeeFile);
			fileOutput.print(employeeAttendance.writeAllEmployees());
			fileOutput.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		// Launch the overridden start method.
		launch(args);
	}
}
