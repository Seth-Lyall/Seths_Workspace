package edu.institution.asn2;

import java.util.ArrayList;
import java.util.List;

public class LinkedInUser extends UserAccount implements Comparable<LinkedInUser>{
	// Instance Variable(s)
	private String type;
	private List<LinkedInUser> connections = new ArrayList<>();
	
	// Constructor(s)
	public LinkedInUser(String username, String password) {
		super(username, password);
	}
	
	// Mutator(s) and Accessor(s)
	// Adds the supplied connection to the list of connections for this user.
	// @param user the connection to add.
	// @throws LinkedInException thrown if the supplied user is already connected to this user.
	public void addConnection (LinkedInUser user) throws LinkedInException {
		boolean userConnected = false;
		for (int i = 0; i < connections.size(); i++) {
			if (connections.get(i).getUsername().compareTo(user.getUsername()) == 0) {
				userConnected = true;
			}
		}
		if (userConnected) {
			throw new LinkedInException("You are already connected with this user.");
		} else {
			connections.add(user);
		}
	}
	
	// Removes the supplied user from the list of connections for this user.
	// @param user the user to remove.
	// @throws LinkedInException thrown if the supplied user is not connected to this user.
	public void removeConnection(LinkedInUser user) throws LinkedInException {
		boolean userConnected = false;
		for (int i = 0; i < connections.size(); i++) {
			if (connections.get(i).getUsername().compareTo(user.getUsername()) == 0) {
				userConnected = true;
			}
		}
		if (userConnected) {
			connections.remove(user);
		} else {
			throw new LinkedInException("You are NOT connected with this user.");
		}
	}
	
	// Returns a list of users that are connected to this user.
	// @return the list or empty list of this user has no connections.
	public List<LinkedInUser> getConnections() {
		List<LinkedInUser> connections = this.connections;
		return connections;
	}
	
	// Returns the type of this LinkedIn user. 
	// @return the type.
	public String getType() {
		return this.type;
	}
		
	@Override // Override the setType() abstract method.
	// Sets the type of this user. 
	// @param type the type.
	public void setType(String type) {
		this.type = type;
	}

	@Override // Override the compareTo() method.
	public int compareTo(LinkedInUser user) {
		return this.getUsername().toLowerCase().compareTo(user.getUsername().toLowerCase());
	}
}
