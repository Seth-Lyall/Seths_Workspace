package edu.institution.asn2;

import org.junit.Test;
import java.util.Collections;
import static org.junit.Assert.assertEquals;

public class LinkedInUserTest {

	@Test // Asserts that connections can be added to a LinkedInUser, read from A LinkedInUser, and deleted from a LinkedInUser.
	public void connectionsAddedReadDeleted() {
		LinkedInUser hanUser = new LinkedInUser("han", "anonymousPassword");
		LinkedInUser lukeUser = new LinkedInUser("luke", "anonymousPassword");
		LinkedInUser leiaUser = new LinkedInUser("leia", "anonymousPassword");
		try {
			hanUser.addConnection(lukeUser);
		} catch (LinkedInException ex) {
			ex.printStackTrace();
		}
		try {
			hanUser.addConnection(leiaUser);
		} catch (LinkedInException ex) {
			ex.printStackTrace();
		}
		assertEquals(hanUser.getConnections().size(), 2);
		assertEquals(hanUser.getConnections().get(0).getUsername(), "luke");
		assertEquals(hanUser.getConnections().get(1).getUsername(), "leia");
		try {
			hanUser.removeConnection(leiaUser);
		} catch (LinkedInException ex) {
			ex.printStackTrace();
		}
		assertEquals(hanUser.getConnections().size(), 1);
		assertEquals(hanUser.getConnections().get(0).getUsername(), "luke");
	}
	
	@Test // Asserts that setType() properly sets the value, and that getType() returns the given value.
	public void setTypeReturnsGivenText() {
		LinkedInUser anonymousUser = new LinkedInUser("anonymous", "anonymousPassword");
		anonymousUser.setType("P");
		assertEquals(anonymousUser.getType(), "P");
	}
	
	@Test // Asserts that LinkedInException is thrown when two of the same user is added twice.
	public void connectingTheSameUserThrowsLinkedInException() {
		String thrownException = null;
		LinkedInUser hanUser = new LinkedInUser("han", "anonymousPassword");
		LinkedInUser lukeUser = new LinkedInUser("luke", "anonymousPassword");
		try {
			hanUser.addConnection(lukeUser);
		} catch (LinkedInException ex) {
			ex.printStackTrace();
		}
		try {
			hanUser.addConnection(lukeUser);
		} catch (LinkedInException ex) {
			ex.printStackTrace();
			thrownException = ex.getMessage();
		}
		assertEquals(thrownException, "You are already connected with this user.");
	}
	
	@Test // Asserts that when a user is removed who isn't a connection LinkedInException will be thrown.
	public void removingAUserThatIsNotConnectedThrowsLinkedInException() {
		String thrownException = null;
		LinkedInUser hanUser = new LinkedInUser("han", "anonymousPassword");
		LinkedInUser lukeUser = new LinkedInUser("luke", "anonymousPassword");
		LinkedInUser leiaUser = new LinkedInUser("leia", "anonymousPassword");
		try {
			hanUser.addConnection(lukeUser);
		} catch (LinkedInException ex) {
			ex.printStackTrace();
		}
		try {
			hanUser.removeConnection(leiaUser);
		} catch (LinkedInException ex) {
			ex.printStackTrace();
			thrownException = ex.getMessage();
		}
		assertEquals(thrownException, "You are NOT connected with this user.");
	}
	
	@Test // Asserts that a list of connections can be sorted alphabetically by their user names ignoring upper case letters.
	public void connectionsListCanBeSortedAlphabeticallyByUsername() {
		LinkedInUser hanUser = new LinkedInUser("Han", "anonymousPassword");
		LinkedInUser lukeUser = new LinkedInUser("LUKE", "anonymousPassword");
		LinkedInUser leiaUser = new LinkedInUser("leia", "anonymousPassword");
		try {
			hanUser.addConnection(lukeUser);
		} catch (LinkedInException ex) {
			ex.printStackTrace();
		}
		try {
			hanUser.addConnection(leiaUser);
		} catch (LinkedInException ex) {
			ex.printStackTrace();
		}
		Collections.sort(hanUser.getConnections());
		assertEquals(hanUser.getConnections().get(0), "leia");
		assertEquals(hanUser.getConnections().get(1), "LUKE");
	}
}
