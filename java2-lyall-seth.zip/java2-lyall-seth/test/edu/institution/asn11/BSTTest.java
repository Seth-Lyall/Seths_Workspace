package edu.institution.asn11;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class BSTTest {

	@Test // Asserts that a binary search tree of integers correctly performs a breadth first traversal.
	public void integerBreadthTraversal() {
		Integer[] integerArray = {10, 5, 19, 6, 1, 17, 21};
		BST<Integer> binarySearchTree = new BST<Integer>(integerArray);
		
		String breadthFirstTraversalComparison = "[10, 5, 19, 1, 6, 17, 21]";
		String breadthFirstTraversal = "" + binarySearchTree.breadthFirstTraversal();
		assertEquals(breadthFirstTraversalComparison, breadthFirstTraversal);
	}
	
	@Test // Asserts that a binary search tree of integers correctly recieves its height.
	public void integerHeight() {
		Integer[] integerArray = {10, 5, 19, 6, 1, 17, 21};
		BST<Integer> binarySearchTree = new BST<Integer>(integerArray);
		
		String heightComparison = "2";
		String height = "" + binarySearchTree.getHeight();
		assertEquals(heightComparison, height);
	}
	
	@Test // Asserts that a binary search tree of integers correctly performs a non recursive in-order.
	public void integerNonRecursiveInorder() {
		Integer[] integerArray = {10, 5, 19, 6, 1, 17, 21};
		BST<Integer> binarySearchTree = new BST<Integer>(integerArray);
		
		String nonRecursiveInorderComparison = "[1, 5, 6, 10, 17, 19, 21]";
		String nonRecursiveInorder = "" + binarySearchTree.nonRecursiveInorder();
		assertEquals(nonRecursiveInorderComparison, nonRecursiveInorder);
	}
	
	@Test // Asserts that a binary search tree of strings correctly performs a breadth first traversal.
	public void doubleBreadthTraversal() {
		Double[] DoubleArray = {3.2, 5.7, 9.2, 15.3, -5.02, -10.0, -1.0};
		BST<Double> binarySearchTree = new BST<Double>(DoubleArray);
		
		String breadthFirstTraversalComparison = "[3.2, -5.02, 5.7, -10.0, -1.0, 9.2, 15.3]";
		String breadthFirstTraversal = "" + binarySearchTree.breadthFirstTraversal();
		assertEquals(breadthFirstTraversalComparison, breadthFirstTraversal);
	}
	
	@Test // Asserts that a binary search tree of strings correctly recieves its height.
	public void doubleHeight() {
		Double[] DoubleArray = {3.2, 5.7, 9.2, 15.3, -5.02, -10.0, -1.0};
		BST<Double> binarySearchTree = new BST<Double>(DoubleArray);
		
		String heightComparison = "3";
		String height = "" + binarySearchTree.getHeight();
		assertEquals(heightComparison, height);
	}
	
	@Test // Asserts that a binary search tree of strings correctly performs a non recursive in-order.
	public void doubleNonRecursiveInorder() {
		Double[] DoubleArray = {3.2, 5.7, 9.2, 15.3, -5.02, -10.0, -1.0};
		BST<Double> binarySearchTree = new BST<Double>(DoubleArray);
		
		String nonRecursiveInorderComparison = "[-10.0, -5.02, -1.0, 3.2, 5.7, 9.2, 15.3]";
		String nonRecursiveInorder = "" + binarySearchTree.nonRecursiveInorder();
		assertEquals(nonRecursiveInorderComparison, nonRecursiveInorder);
	}
}
