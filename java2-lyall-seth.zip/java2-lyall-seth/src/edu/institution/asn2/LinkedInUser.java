package edu.institution.asn2;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;


public class LinkedInUser extends UserAccount implements Comparable<LinkedInUser>, Serializable {

	private static final long serialVersionUID = 2L;
	// Instance Variable(s)
	private String type;
	private List<LinkedInUser> connections = new ArrayList<>();
	private Set<String> skillsets = new TreeSet<String>();

	// Constructor(s)
	public LinkedInUser(String username, String password) {
		super(username, password);
	}

	// Mutator(s) and Accessor(s)
	// Adds the supplied connection to the list of connections for this user.
	// @param user the connection to add.
	// @throws LinkedInException thrown if the supplied user is already connected to this user.
	public void addConnection (LinkedInUser user) throws LinkedInException {
		if (connections.contains(user)) {
			throw new LinkedInException("You are already connected with this user");
		} else {
			connections.add(user);
		}
	}

	// Removes the supplied user from the list of connections for this user.
	// @param user the user to remove.
	// @throws LinkedInException thrown if the supplied user is not connected to this user.
	public void removeConnection(LinkedInUser user) throws LinkedInException {
		if (connections.contains(user)) {
			connections.remove(user);
		} else {
			throw new LinkedInException("You are NOT connected with this user");
		}
	}

	// Returns a list of users that are connected to this user.
	// @return the list or empty list of this user has no connections.
	public List<LinkedInUser> getConnections() {
		List<LinkedInUser> connections = new ArrayList<LinkedInUser>();
		for (LinkedInUser u: this.connections) {
			connections.add(u);
		}
		return connections;
	}

	// Returns the type of this LinkedIn user. 
	// @return the type.
	public String getType() {
		return this.type;
	}

	@Override // Override the setType() abstract method.
	// Sets the type of this user. 
	// @param type the type.
	public void setType(String type) {
		this.type = type;
	}

	@Override // Override the compareTo() method.
	public int compareTo(LinkedInUser user) {
		if (getUsername() == null) {
			return -1;
		} else if (user == null || user.getUsername() == null) {
			return 1;
		} else {
			return this.getUsername().compareToIgnoreCase(user.getUsername());
		}
	}
	
	// Returns this users skill sets.
	// @return skill sets.
	public Set<String> getSkillsets() {
		Set<String> skillsetsCopy = new TreeSet<String>();
		if (this.skillsets == null || this.skillsets.isEmpty()) {
			return new TreeSet<String>();
		} else {
			for (String s: this.skillsets) {
				skillsetsCopy.add(s);
			}
			return skillsetsCopy;
		}
	}
	
	// Adds the supplied skill set from this user.
	public void addSkillset(String skillset) {
		this.skillsets.add(skillset);
	}
	
	// Removes the supplied skill set from this user.
	public void removeSkillset(String skillset) {
		this.skillsets.remove(skillset);
	}
}
