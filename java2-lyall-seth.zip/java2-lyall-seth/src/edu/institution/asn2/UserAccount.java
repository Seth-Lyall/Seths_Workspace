package edu.institution.asn2;

import java.io.Serializable;
import java.util.Objects;

public abstract class UserAccount implements Serializable{

	private static final long serialVersionUID = 1L;
	// Instance Variable(s)
	private String username;
	private String password;

	// Constructor(s)
	// A constructor accepting two strings; one to initiate the user name and the other to initiate the password. 
	UserAccount(String username, String password) {
		this.username = username;
		this.password = password;
	}

	// Mutator(s) and Accessor(s)
	// Returns the user name supplied on the constructor.
	public String getUsername() {
		return this.username;
	}

	// Returns true of the argument is the same as this account's password, false otherwise.
	public boolean isPasswordCorrect(String password) {
		if (password.compareTo(this.password) == 0) {
			return true;
		} else {
			return false;
		}
	}

	// Sets the type of this user. @param type the type.
	public abstract void setType(String type);

	// Displays the user name for the account.
	@Override // Override the toString method.
	public String toString() {
		return this.getUsername();
	}

	@Override
	public int hashCode() {
		return Objects.hash(username);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserAccount other = (UserAccount) obj;
		return Objects.equals(username, other.username);
	}

	
}
