package edu.institution.midterm;

import java.io.File;
import java.io.FileNotFoundException;
import java.math.*;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Scanner;
import com.google.gson.Gson;
import edu.institution.actions.asn5.Utilities;

public class PartManagerImpl implements PartManager {
	// Member Variable(s)
	private Hashtable<String, Part> partsList = new Hashtable<String, Part>(); // Holds a list of all parts read in from "bom.json".
	
	// Mutator(s)
	// Imports the part store from an external file.
	// Accepts the file path to the file which contains the parts to import.
	// Returns the number of parts imported.
	@Override // Override the importPartStore() method.
	public int importPartStore(String filePath) {
		String jsonData = "";
		Utilities utilities = new Utilities();
		Scanner input;
		Part[] parts;
		Gson gson = new Gson();
		List<Part> duplicatesList;
		try {
			input = new Scanner(new File(filePath));
			while (input.hasNext()) {
				jsonData += input.nextLine() + "\n";
			}
			input.close();
			parts = gson.fromJson(jsonData, Part[].class);
			duplicatesList = new ArrayList<Part>();
			for (Part p: parts) {
				duplicatesList.add(p);
			}
			utilities.removeDuplicates(duplicatesList);
			for (Part p: duplicatesList) {
				partsList.put(p.getPartNumber(), p);
			}
			return partsList.size();
		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
			return 0;
		}
	}

	// Computes the cost to manufacture the part associated with the supplied part number.
	// Accepts a part number which identifies the part to compute the cost for.
	@Override // Override the costPart() method.
	public Part costPart(String partNumber) {
		if (partNumber == "" || partNumber == null || partsList.get(partNumber) == null) {
			return null;
		}
		float extendedPrice = 0;
		for (BomEntry e: partsList.get(partNumber).getBillOfMaterial()) { // Read the current part's bill of materials.
			if (partsList.get(e.getPartNumber()).getPrice() == 0.00) { // If the current part is an assembly (if the price is $0.00).
				costPart(e.getPartNumber()).getPrice();
				extendedPrice = e.getQuantity() * roundForMoney(costPart(e.getPartNumber()).getPrice());
				partsList.get(partNumber).setPrice(extendedPrice);
			} else { // If the current part is not an assembly (if the price is greater than $0.00).
				extendedPrice += e.getQuantity() * roundForMoney(partsList.get(e.getPartNumber()).getPrice());
				partsList.get(partNumber).setPrice(extendedPrice);
			}
		}
		partsList.get(partNumber).setPrice(roundForMoney(partsList.get(partNumber).getPrice()));
		return partsList.get(partNumber);
	}

	// Rounds the float value sent to the method down to two decimal places and returns the value.
	private float roundForMoney(float value) {
		return new BigDecimal(value).setScale(2, RoundingMode.HALF_UP).floatValue();
	}

	// Retrieves  the part associated with the supplied part number from the part store.
	// Accepts a part number which identifies the part to retrieve.
	// Returns the part instance associated with the supplied part number or null if not found.
	@Override // Override the retrievePart() method.
	public Part retrievePart(String partNumber) {
		if (partNumber == "" || partNumber == null || partsList.get(partNumber) == null) {
			return null;
		}
		for (Part p: partsList.values()) {
			if (p.getPartNumber().compareTo(partNumber) == 0) {
				return p;
			}
		}
		return null;
	}

	// Returns all final assembly parts stored alphabetically by their part number.
	// Final assemblies have a part type of "ASSEMBLY".
	@Override // Override the getFinalAssemblies() method.
	public List<Part> getFinalAssemblies() {
		List<Part> finalAssemblies = new ArrayList<Part>();
		Part tempPart;
		for (Part p: partsList.values()) {
			if (p.getPartType().compareTo("ASSEMBLY") == 0) {
				finalAssemblies.add(p);
			}
		}
		for (int i = 0; i < finalAssemblies.size(); i++) {
			for (int j = 1; j < finalAssemblies.size(); j++) {
				if (finalAssemblies.get(j - 1).getPartNumber().compareTo(finalAssemblies.get(j).getPartNumber()) > 0) {
					tempPart = finalAssemblies.get(j);
					finalAssemblies.set(j, finalAssemblies.get(j - 1));
					finalAssemblies.set(j - 1, tempPart);
				}
			}
		}
		return finalAssemblies;
	}

	// Returns all purchased parts sorted by their price, highest price to lowest.
	// Purchase parts have a part type of "PURCHASE".
	@Override // Override the getPurchasedPartsByPrice() method.
	public List<Part> getPurchasedPartsByPrice() {
		List<Part> partsPurchased = new ArrayList<Part>();
		Part tempPart;
		for (Part p: partsList.values()) {
			if (p.getPartType().compareTo("PURCHASE") == 0) {
				partsPurchased.add(p);
			}
		}
		for (int i = 0; i < partsPurchased.size(); i++) {
			for (int j = 1; j < partsPurchased.size(); j++) {
				if (partsPurchased.get(j).getPrice() > partsPurchased.get(j - 1).getPrice()) {
					tempPart = partsPurchased.get(j);
					partsPurchased.set(j, partsPurchased.get(j - 1));
					partsPurchased.set(j - 1, tempPart);
				}
			}
		}
		return partsPurchased;
	}
}
