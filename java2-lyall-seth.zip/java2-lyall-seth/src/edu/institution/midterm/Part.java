package edu.institution.midterm;

import java.util.List;
import java.util.Objects;

public class Part {
	// Member variable(s)
	private String partNumber; // Identifies this part in the part store.
	private String name; // The display name for this part.
	private String partType; // The type of part. Valid values are: "ASSEMBLY", "PURCHASE", or "COMPONENT"
	// "ASSEMBLY" parts are the final assemblies that are sold to the customers.
	// "COMPONENT" parts are the sub component parts that make up the final assemblies.
	// "PURCHASE" parts are the external components purchased from a vendor.
	private float price; // The price of this part.
	private List<BomEntry> billOfMaterial; // The list of BOM entries one level under this part.
	
	// Getter(s) and Setter(s)
	public String getPartNumber() {
		return this.partNumber;
	}
	public void setPartNumber(String pn) {
		this.partNumber = pn;
	}
	public String getName() {
		return this.name;
	}
	public void setName(String n) {
		this.name = n;
	}
	public String getPartType() {
		return this.partType;
	}
	public void setPartType(String pt) {
		this.partType = pt;
	}
	public float getPrice() {
		return this.price;
	}
	public void setPrice(float p) {
		this.price = p;
	}
	public List<BomEntry> getBillOfMaterial(){
		return this.billOfMaterial;
	}
	public void setBillOfMaterial(List<BomEntry> bom) {
		this.billOfMaterial = bom;
	}
	
	@Override // Override the equals() method.
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Part other = (Part) obj;
		return Objects.equals(partNumber, other.partNumber);
	}
	@Override // Override the hashCode() method.
	public int hashCode() {
		return Objects.hash(partNumber);
	}
	@Override // Override the toString() method.
	public String toString() {
		String returnString = "\nPart Number: " + this.getPartNumber() + 
				"\nName: " + this.getName() + 
				"\nPart Type: " + this.getPartType() + 
				"\nPrice: " + this.getPrice();
		if (getBillOfMaterial() != null) {
			returnString += "\nBill Of Materials: [\n";
			for (BomEntry m: getBillOfMaterial()) {
				returnString += m + "\n";
			}
			returnString += "]";
		}
		return returnString;
	}
}
