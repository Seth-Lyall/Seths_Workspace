package edu.institution.actions.asn6;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import edu.institution.UserRepository;
import edu.institution.actions.MenuAction;
import edu.institution.asn2.LinkedInUser;

public class ListUserByConnectionAction implements MenuAction {

	// Sorts the userRepository numerically by connection size and alphabetically by user name and displays the results.
	@Override // Override the process method.
	public boolean process(Scanner scanner, UserRepository userRepository, LinkedInUser loggedInUser) {
		List<LinkedInUser> userList = new ArrayList<LinkedInUser>();
		int checkedConnections = 0;
		
		for (LinkedInUser u: userRepository.retrieveAll()) {
			if (checkedConnections < u.getConnections().size()) {
				checkedConnections = u.getConnections().size();
			}
			userList.add(u);
		}

		for (int i = 0; i < userList.size(); i++) {
			Collections.sort(userList);
			for (LinkedInUser v: userList) {
				if (v.getConnections().size() == checkedConnections) {
					System.out.println(v.getUsername() + ";	connection size = " + v.getConnections().size());
				}
			}
			checkedConnections--;
		}
		return true;
	}
}
