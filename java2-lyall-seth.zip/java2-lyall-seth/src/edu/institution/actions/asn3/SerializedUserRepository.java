package edu.institution.actions.asn3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import edu.institution.ApplicationHelper;
import edu.institution.asn2.LinkedInException;
import edu.institution.asn2.LinkedInUser;

public class SerializedUserRepository implements edu.institution.UserRepository{
	// Instance Variable(s)
	private String filePath;
	private String fileName;
	List<LinkedInUser> userList;

	// Mutator(s) and Accessor(s)
	// This method deserializes the data stored at the supplied filePath + fileName location into a list of LinkedIn users. 
	// If there is no previously saved data, then this method initializes a new list of LinkedIn users.
	@SuppressWarnings("unchecked")
	public void init(String filePath, String fileName) {
		this.filePath = filePath;
		this.fileName = fileName;
		try {
			ObjectInputStream fin= new ObjectInputStream(new FileInputStream(filePath + fileName));
			this.userList = (List<LinkedInUser>)fin.readObject();
			fin.close();
			ApplicationHelper.initSkillsetUsages(userList);
		} catch (FileNotFoundException e) {
			this.userList = new ArrayList<LinkedInUser>();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// This method ensures that the supplied user is ready to be added to the user repository and, if
	// so, adds the user to the list of users established from the init method.
	public void add(LinkedInUser user) throws LinkedInException {
		if (user.getUsername().equals("") || user.getUsername().equals(null) || user.getType().equals("") || user.getType().equals(null)) {
			throw new LinkedInException("\nThe user name and type are required to add a new user");
		}
		else if (user.getType().compareTo("P") == 0 && user.getType().compareTo("S") == 0) {
			throw new LinkedInException("\nInvalid user type. Valid types are P or S");
		}
		else if (userList.contains(user)) {
			throw new LinkedInException("\nA user already exists with that user name");
		}
		else {
			this.userList.add(user);
			saveAll();
		}
	}

	// This method overwrites (serializes) the list of LinkedIn users that was established in the init
	// method to the file system.
	public void saveAll() {
		File userFile = new File(filePath + fileName);
		if (!userFile.exists()) {
			try {
				userFile.createNewFile();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		try {
			ObjectOutputStream fout = new ObjectOutputStream(new FileOutputStream(userFile));
			fout.writeObject((List<LinkedInUser>)this.userList);
			fout.close();
		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	// This method removes the supplied LinkedIn user from the list of LinkedIn users that was
	// established in the init method. This method should call the saveAll() method to persist the
	// deleted data.
	public void delete(LinkedInUser user) {
		userList.remove(user);
		saveAll();
	}

	// This method returns the LinkedIn user associated with the supplied user name or null if there is
	// no user associated with the supplied user name.
	public LinkedInUser retrieve(String username) {
		LinkedInUser getMe;
		if (userList.size() > 0) {
			for (LinkedInUser u: this.userList) {
				if (u.getUsername().compareTo(username) == 0) {
					getMe = u;
					return getMe;
				}
			}
		}
		return null;
	}

	// This method returns all LinkedIn users in the repository or an empty list if there are no users in
	// the repository.
	public List<LinkedInUser> retrieveAll() {
		List<LinkedInUser> u = new ArrayList<LinkedInUser>();
		if (this.userList.isEmpty()) {
			return new ArrayList<LinkedInUser>();
		}
		else {
			for (LinkedInUser user: this.userList) {
				u.add(user);
			}
			return u;
		}
	}
}
