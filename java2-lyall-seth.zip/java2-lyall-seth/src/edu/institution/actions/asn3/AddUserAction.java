package edu.institution.actions.asn3;

import java.util.Scanner;
import edu.institution.UserRepository;
import edu.institution.actions.MenuAction;
import edu.institution.actions.asn10.UndoAction;
import edu.institution.actions.asn10.UndoActionData;
import edu.institution.asn2.LinkedInException;
import edu.institution.asn2.LinkedInUser;

public class AddUserAction implements MenuAction {
	// Prompts the user for a user name, password, and user type and
	// uses the add() function from the user repository to add the user.
	@Override // Override the process() method.
	public boolean process(Scanner scanner, UserRepository userRepository, LinkedInUser loggedInUser) {
		String username = "";
		String password = "";
		String type = "";
		System.out.println("\nEnter a username");
		username = scanner.nextLine();
		System.out.println("\nEnter a password");
		password = scanner.nextLine();
		while (password == "" || password == null) {
			System.out.println("\nPlease enter a password");
			password = scanner.nextLine();
		}
		System.out.println("\nEnter the type of user (P or S)");
		type = scanner.nextLine();
		while (!type.equalsIgnoreCase("P") && !type.equalsIgnoreCase("S")) {
			System.out.println("\nInvalid user type. Valid types are P or S");
			type = scanner.nextLine();
		}
		LinkedInUser user = new LinkedInUser(username, password);
		user.setType(type.toUpperCase());
		try {
			userRepository.add(user);
			userRepository.saveAll();
			UndoAction.history.push(new UndoActionData("Sign up a New User", username, user));
		} catch (LinkedInException ex) {
			System.out.println(ex.getMessage());
		}
		return true;
	}
}
