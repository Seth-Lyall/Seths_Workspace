package edu.institution.actions.asn3;

import java.util.List;

import edu.institution.asn2.*;

public interface UserRepository {
	// Mutator(s) and Accessor(s)
	public void init(String filePath, String fileName);
	
	public void add(LinkedInUser user) throws LinkedInException;
	
	public void saveAll();
	
	public void delete(LinkedInUser user);
	
	public LinkedInUser retrieve(String username);
	
	public List<LinkedInUser> retrieveAll();
}
