package edu.institution.actions.asn3;

import java.util.Scanner;
import edu.institution.UserRepository;
import edu.institution.actions.MenuAction;
import edu.institution.actions.asn10.UndoAction;
import edu.institution.actions.asn10.UndoActionData;
import edu.institution.asn2.LinkedInUser;

public class DeleteUserAction implements MenuAction {
	// Prompt for the user name to delete. Check if the supplied user name exists in the user list.
	// If the user does NOT exist, display an error message to the console and re-display the menu.
	// If the user does exist, prompt for the password of the user being deleted.
	// If the password is not correct, display an error message to the console and return out of the action.
	// If the password is correct, call the delete method on the user repository passing the user name.
	// If the deleted user was the logged in user, then the action should return false to tell the
	// Application Controller to sign out the current user. Otherwise, return true to keep the
	// user signed in.
	@Override // Override the process() method.
	public boolean process(Scanner scanner, UserRepository userRepository, LinkedInUser loggedInUser) {
		String username = "";
		String password = "";
		System.out.println("\nEnter the username: ");
		username = scanner.nextLine();
		LinkedInUser user = userRepository.retrieve(username);
		if (user == null) {
			System.out.println("\nUser does not exist");
			return true;
		} else {
			System.out.println("\nEnter the password");
			password = scanner.nextLine();
			if (!user.isPasswordCorrect(password)) {
				System.out.println("Invalid password");
				return true;
			} else if (user.equals(loggedInUser)) {
				userRepository.delete(user);
				UndoAction.history.push(new UndoActionData("Delete a User", username, user));
				return false;
			} else {
				userRepository.delete(user);
				UndoAction.history.push(new UndoActionData("Delete a User", username, user));
				return true;
			}
		}
	}
}
