package edu.institution.actions.asn3;

import java.util.Scanner;
import edu.institution.UserRepository;
import edu.institution.actions.MenuAction;
import edu.institution.actions.asn10.UndoAction;
import edu.institution.asn2.LinkedInUser;

public class SignoffAction implements MenuAction {
	// This method returns false to tell the Application Controller to sign out the current
	// user.
	@Override // Override the process() method.
	public boolean process(Scanner scanner, UserRepository userRepository, LinkedInUser loggedInUser) {
		UndoAction.history.clear();
		return false;
	}
}
