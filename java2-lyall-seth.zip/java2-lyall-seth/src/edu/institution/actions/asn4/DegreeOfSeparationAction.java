package edu.institution.actions.asn4;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import edu.institution.UserRepository;
import edu.institution.actions.MenuAction;
import edu.institution.asn2.LinkedInUser;

public class DegreeOfSeparationAction implements MenuAction {

	// Prompts for the user name to search for.
	//
	// Displays the path and the number of connections between the logged in user 
	// and the entered user.
	@Override // Override the process method.
	public boolean process(Scanner scanner, UserRepository userRepository, LinkedInUser loggedInUser) {
		List<LinkedInUser> returnList = new ArrayList<LinkedInUser>();
		String username = "";
		System.out.println("\nEnter the user name of the user you want to find");
		username = scanner.nextLine();
		if (userRepository.retrieve(username) == null) {
			System.out.println("\nThere is no user with that user name");
			return true;
		} else if (loggedInUser.getUsername().compareTo(username) == 0) {
			return true;
		} else if (!(userRepository.retrieve(username).getUsername().compareTo(username) == 0)) {
			return true;
		} else {
			recursiveSearch(loggedInUser, userRepository.retrieve(username), returnList);
			if (returnList.size() > 0) {
				System.out.println("\nThere is " + (returnList.size() - 1) + " degrees of separation between you and " + username);
				System.out.print(loggedInUser.getUsername());
				for (LinkedInUser u: returnList) {
					System.out.print(" -> " + u.getUsername());
				}
				System.out.print("\n");
			} else {
				System.out.println(loggedInUser.getUsername() + " is not connected to " + username + "\n");
			}
		}
		return true;
	}

	List<LinkedInUser> recursiveSearch(LinkedInUser searchUser, LinkedInUser findUser, List<LinkedInUser> returnList) {
		List<LinkedInUser> searchList = new ArrayList<LinkedInUser>();
		for (LinkedInUser u: searchUser.getConnections()) {
			searchList.add(u);
			if (u.getUsername().compareTo(findUser.getUsername()) == 0) {
				returnList.add(u);
				return returnList;
			}
		}
		for (LinkedInUser u: searchList) {
			if (u.getUsername().compareTo(findUser.getUsername()) == 0) {
				returnList.add(u);
				return returnList;
			} else {
				returnList.add(u);
				return recursiveSearch(u, findUser, returnList);
			}
		}
		return new ArrayList<LinkedInUser>();
	}
}
