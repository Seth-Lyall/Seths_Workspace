package edu.institution.actions.asn7;

import java.util.Scanner;
import java.util.Set;
import edu.institution.ApplicationHelper;
import edu.institution.UserRepository;
import edu.institution.actions.MenuAction;
import edu.institution.asn2.LinkedInUser;

public class ListSkillsetAction implements MenuAction {

	// If the user has no skill sets, display "You have not entered any skillsets".
	// Otherwise, display "Here are your skillsets\n" followed by each of the users
	// skill sets and the total number of users that share that skill set.
	// Return true to keep the user signed in.
	@Override // Override the process method.
	public boolean process(Scanner scanner, UserRepository userRepository, LinkedInUser loggedInUser) {
		Set<String> userSkillsets = loggedInUser.getSkillsets();
		if (userSkillsets == null || userSkillsets.isEmpty()) {
			System.out.println("You have no skillsets");
		} else {
			System.out.println("Here are your skillsets\n");
			userSkillsets.forEach(e -> System.out.println(e + " (" + ApplicationHelper.retrieveSkillsetCount(e) + " users)"));
		}
		return true;
	}
}
