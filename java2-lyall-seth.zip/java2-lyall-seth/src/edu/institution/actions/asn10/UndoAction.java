package edu.institution.actions.asn10;

import java.util.EmptyStackException;
import java.util.Scanner;
import java.util.Stack;
import edu.institution.ApplicationHelper;
import edu.institution.UserRepository;
import edu.institution.actions.MenuAction;
import edu.institution.asn2.LinkedInException;
import edu.institution.asn2.LinkedInUser;

public class UndoAction implements MenuAction {

	// Publicly available to all actions.
	public static Stack<UndoActionData> history = new Stack<UndoActionData>();
	
	@Override
	public boolean process(Scanner scanner, UserRepository userRepository, LinkedInUser loggedInUser) {
		char choice = ' ';
		try {
			if (history.isEmpty()) {
				throw new EmptyStackException();
			} else {
				String menuOptionText = history.peek().getMenuActionName();
				String username = history.peek().getMenuActionRecipient();
				String skillset = history.peek().getSkillset();
				LinkedInUser user = history.peek().getUser();
				// Prompt the user to decide whether or not to undo the action.
				System.out.print("\nThe last menu option selected was \"" + menuOptionText + "\" involving " + username + ". Undo? (Y/N): ");
				choice = scanner.nextLine().charAt(0);
				if (choice == 'Y' || choice == 'y') {
					switch (menuOptionText) { // If the user responded 'y' to undo the option perform this switch.
					case "Add Connection":
						loggedInUser.removeConnection(userRepository.retrieve(username));
						System.out.println("\n" + username + " was removed from " + loggedInUser.getUsername() + "'s connections");
						break;
					case "Remove Connection":
						loggedInUser.addConnection(userRepository.retrieve(username));
						System.out.println("\n" + username + " was added to " + loggedInUser.getUsername() + "'s connections");
						break;
					case "Add Skillset":
						ApplicationHelper.decrementSkillsetCount(skillset);
						loggedInUser.removeSkillset(skillset);
						System.out.println(skillset + " has been removed from " + username + "'s skillsets");
						break;
					case "Remove Skillset":
						ApplicationHelper.incrementSkillsetCount(skillset);
						loggedInUser.addSkillset(skillset);
						System.out.println(skillset + " has been added to " + username + "'s skillsets");
						break;
					case "Sign up a New User":
						userRepository.delete(userRepository.retrieve(username));
						System.out.println("\n" + username + " has been removed from the user repository");
						break;
					case "Delete a User":
						userRepository.add(user);
						System.out.println("\n" + user.getUsername() + " has been added to the user repository");
						break;
					}
					history.pop(); // The action has been undone so remove it from the action history.
					return true;
				} else {
					return true;
				}
			}
		} catch (EmptyStackException ex) {
			System.out.println("\nThere are no actions to undo");
			return true;
		} catch (LinkedInException e) {
			System.out.println(e.getMessage());
		}
		return true;
	}
}
