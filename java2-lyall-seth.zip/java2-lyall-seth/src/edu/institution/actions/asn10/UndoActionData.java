package edu.institution.actions.asn10;

import edu.institution.asn2.LinkedInUser;

// Holds data that will be needed to undo an action in the UndoAction
// process method.
public class UndoActionData {
	// Member Variable(s)
	private String menuActionName; // Holds the name of the menu action that was performed.
	private String menuActionRecipient; // Holds the user name of the user that was influenced by the menu action.
	private String skillset; // Holds the skill set that was held by the given user.
	private LinkedInUser user; // Holds the LinkedInUser that used to be in the user repository.
	
	// Constructor(s)
	public UndoActionData (String mn, String mr) {
		setMenuActionName(mn);
		setMenuActionRecipient(mr);
	}
	public UndoActionData(String mn, String mr, String ss) {
		setMenuActionName(mn);
		setMenuActionRecipient(mr);
		setSkillset(ss);
	}
	public UndoActionData(String mn, String mr, LinkedInUser u) {
		setMenuActionName(mn);
		setMenuActionRecipient(mr);
		setUser(u);
	}
	
	// Mutator(s) and Accessor(s)
	public String getMenuActionName() {
		return this.menuActionName;
	}
	public String getMenuActionRecipient() {
		return this.menuActionRecipient;
	}
	public String getSkillset() {
		return this.skillset;
	}
	public LinkedInUser getUser() {
		return this.user;
	}
	public void setMenuActionName(String mn) {
		this.menuActionName = mn;
	}
	public void setMenuActionRecipient(String mr) {
		this.menuActionRecipient = mr;
	}
	public void setSkillset(String ss) {
		this.skillset = ss;
	}
	public void setUser(LinkedInUser u) {
		this.user = u;
	}
}
