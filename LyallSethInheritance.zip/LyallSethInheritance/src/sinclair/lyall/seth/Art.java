package sinclair.lyall.seth;

public class Art extends Property {
	// Instance Variable(s)
	private String artistName;
	private int yearCreated;
	
	// Constructor(s)
	public Art(String n, double c, int yp, double av, String an, int yc) {
		super(n, c, yp, av);
		setArtistName(an);
		setYearCreated(yc);
	}
			
	// Mutator(s) and Accessor(s)
	public String getArtistName() {
		return this.artistName;
	}
	public void setArtistName(String an) {
		this.artistName = an;
	}
	public int getYearCreated() {
		return this.yearCreated;
	}
	public void setYearCreated(int yc) {
		this.yearCreated = yc;
	}
	@Override // Override the toString method.
	public String toString() {
		String newString = super.toString() + "\nArtist        : " + getArtistName() + "\nYear Created  : " + getYearCreated();
		return newString;
	}
}
