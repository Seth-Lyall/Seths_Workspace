package sinclair.lyall.seth;

public class Asset {
	// Instance Variable(s)
	private String name;
	private double cost;
	private int yearPurchased;
	
	// Constructor(s)
	public Asset(String n, double c, int yp) {
		setName(n);
		setCost(c);
		setYearPurchased(yp);
	}
	
	// Mutator(s) and Accessor(s)
	public String getName() {
		return this.name;
	}
	public void setName(String n) {
		this.name = n;
	}
	public double getCost() {
		return this.cost;
	}
	public void setCost(double c) {
		this.cost = c;
	}
	public int getYearPurchased() {
		return this.yearPurchased;
	}
	public void setYearPurchased(int yp) {
		this.yearPurchased = yp;
	}
	public double amortizedCost(int currentYear) {
		return cost / (currentYear - yearPurchased);
	}
	public double computeValue() {
		return getCost();
	}
	@Override // Override the toString method.
	public String toString() {
		String assetCost = String.format("%.1f", getCost());
		String newString = 	"Name          : " + getName() + "\nCost          : " + assetCost + "\nPurchase Date : " + getYearPurchased();
		return newString;
	}
}
