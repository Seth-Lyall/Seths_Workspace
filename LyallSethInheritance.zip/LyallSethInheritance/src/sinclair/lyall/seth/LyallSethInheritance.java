/**
 * Seth Lyall - MVCTC
 * Jan 9, 2023
 */
package sinclair.lyall.seth;

public class LyallSethInheritance {

	public static void main(String[] args) {
		System.out.println("Inheritance Project - Assets\n");
		
		Stock microsoft = new Stock("Microsoft Stock", 8000, 1994, "MSFT", 200, 56);
		Building beachHouse = new Building("Beach House", 9000, 1964, 35000, "123 Seashore Ave, Malibu, CA");
		Art nighthawks = new Art("Nighthawks", 850, 1955, 7500, "Edward Hopper", 1942);
		Asset[] assetArray = new Asset[] {microsoft, beachHouse, nighthawks};
		final int currentYear = 2002;
		int count = 0;
		
		System.out.print("Amortized costs per year:\n");
		for (Asset asset: assetArray) {
			switch(count) {
			case 0: System.out.print("Microsoft Stock");
				break;
			case 1: System.out.print("Beach House");
				break;
			default: System.out.print("Nighthawks");
				break;
			}
			System.out.printf("\t$%8.2f", asset.amortizedCost(currentYear));
			System.out.print("\n");
			count++;
		}
		
		count = 0;
		System.out.print("\nValuations:\n");
		for (Asset asset: assetArray) {
			switch(count) {
			case 0: System.out.print("Microsoft Stock");
				break;
			case 1: System.out.print("Beach House");
				break;
			default: System.out.print("Nighthawks");
				break;
			}
			System.out.printf("\t$%8.2f", asset.computeValue());
			System.out.print("\n");
			count++;
		}
		
		System.out.print("\nAsset Details:\n");
		for (Asset asset: assetArray) {
			System.out.print(asset.toString());
			System.out.print("\n\n");
			count++;
		}
	}
}
