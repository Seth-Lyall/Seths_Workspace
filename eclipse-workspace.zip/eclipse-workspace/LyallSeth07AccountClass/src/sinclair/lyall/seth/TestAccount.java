/**
 * Seth Lyall - MVCTC
 * Oct 10, 2022
 */
package sinclair.lyall.seth;

import java.util.Scanner;

public class TestAccount {

	public static void main(String[] args) {
		// Create a scanner to get user input, and construct an instance of the Account
		// class.
		Scanner input = new Scanner(System.in);
		Account checkingAccount = new Account();

		// Have the user enter the ID, balance, and annual interest rate for the account
		// and use setters to set those values for the checkingAccount Account class
		// instance.
		System.out.print("Enter the ID for your account: ");
		checkingAccount.setId(input.nextInt());
		System.out.print("Enter the balance for your account: ");
		checkingAccount.setBalance(input.nextDouble());
		System.out.print("Enter the annual interest rate for your account: ");
		checkingAccount.setAnnualInterestRate(input.nextDouble());

		// Have the user enter a withdrawal and deposition for the account and use the
		// withdraw and deposit member functions to alter the balance in the class.
		System.out.print("Enter the amount you would like to withdraw from your account: ");
		checkingAccount.withdraw(input.nextDouble());
		System.out.print("Enter the amount you would like to deposit to your account: ");
		checkingAccount.deposit(input.nextDouble());

		// Use getters from the Account class to output the balance, monthly interest
		// rate, and date created for the account.
		System.out.println("");
		System.out.printf("Your account balance is $%.2f", checkingAccount.getBalance());
		System.out.println("");
		System.out.printf("Your account's monthly interest is %.2f", checkingAccount.getMonthlyInterestRate());
		System.out.println("%");
		System.out.println("Your account was created on " + checkingAccount.getDateCreated());

		// Close the scanner.
		input.close();
	}
}
