/**
 * Seth Lyall - MVCTC
 * Oct 10, 2022
 */
package sinclair.lyall.seth;

import java.util.Date;

public class Account {
	// Member(s).
	int id;
	double balance;
	double annualInterestRate;
	private Date dateCreated;

	// Constructor(s).
	Account() {
		setId(0);
		setBalance(0.00);
		setAnnualInterestRate(0.00);
		dateCreated = new Date();
	}

	Account(int i, double b) {
		setId(i);
		setBalance(b);
		setAnnualInterestRate(0.00);
		dateCreated = new Date();
	}

	// Getter(s).
	public int getId() {
		return id;
	}

	public double getBalance() {
		return balance;
	}

	public double getAnnualInterestRate() {
		return annualInterestRate;
	}

	public Date getDateCreated() {
		return dateCreated;
	}

	public double getMonthlyInterestRate() {
		return annualInterestRate / 12.00;
	}

	// Setter(s) or Mutators(s).
	public void setId(int i) {
		id = i;
	}

	public void setBalance(double b) {
		balance = b;
	}

	public void setAnnualInterestRate(double a) {
		annualInterestRate = a;
	}

	public void withdraw(double b) {
		setBalance(getBalance() - b);
	}

	public void deposit(double b) {
		setBalance(getBalance() + b);
	}
}
