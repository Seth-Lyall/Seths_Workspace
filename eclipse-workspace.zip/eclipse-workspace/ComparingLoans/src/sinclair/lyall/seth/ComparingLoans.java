/**
 * Seth Lyall - MVCTC
 * Sep 13, 2022
 */
package sinclair.lyall.seth;

import java.util.Scanner;

public class ComparingLoans {

	public static void main(String[] args) {
		// Program Variables.
		int numberOfYears = 0;
		double rate = 0.00;
		int term = 0;
		double loanAmount = 0.00;
		double monthlyPayment = 0.00;
		double totalPayment = 0.00;
		// Creates a scanner to read console input.
		Scanner input = new Scanner(System.in);

		// Reads the loan amount and number of years from the console.
		System.out.print("Loan Amount: ");
		loanAmount = input.nextDouble();
		System.out.print("Number of Years: ");
		numberOfYears = input.nextInt();

		// Prints the first line of the table so it can be easily understood.
		System.out.println("Interest Rate___Monthly Payment______Total Payment");

		// Do a for loop for each interest rate, and display the monthly and total
		// payments.
		for (double r = 5.000; r <= 8.000; r += 0.125) {
			// Calculate the rate and term for the current loan interest rate.
			rate = (r / 100.00) / 12.00;
			term = (numberOfYears * 12);
			// Calculate the monthly payment using the formula for calculating monthly
			// payment and the rate and term calculated previously.
			monthlyPayment = loanAmount
					* (rate * Math.pow(1.000 + rate, term) / (Math.pow(1.000 + rate, term) - 1.000));
			// Calculate the total payment by multiplying the monthly payment by the term.
			totalPayment = monthlyPayment * term;
			// Display a row of the table using printf to format it.
			System.out.printf("%2.3f", r);
			System.out.print("___________");
			System.out.printf("%4.2f", monthlyPayment);
			System.out.print("_______________");
			System.out.printf("%5.2f", totalPayment);
			System.out.println("");
		}

		// Close the scanner input.
		input.close();
	}
}
