/**
 * Seth Lyall - MVCTC
 * Sep 13, 2022
 */
/**
 * @author lyall52354
 *
 */
module ComparingLoans {
}