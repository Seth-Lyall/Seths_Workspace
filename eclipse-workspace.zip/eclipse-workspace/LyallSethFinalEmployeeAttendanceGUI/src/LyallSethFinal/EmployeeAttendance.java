/**
 * Seth Lyall - MVCTC
 * Nov 29, 2022
 */
package LyallSethFinal;

import java.util.ArrayList;

public class EmployeeAttendance {
	// Member(s)
	private static final int arraySize = 100; // Constant variable for size of the arrays.
	private static ArrayList<String> name = new ArrayList<String>(arraySize);
	private static ArrayList<String> address = new ArrayList<String>(arraySize);
	private static ArrayList<String> presence = new ArrayList<String>(arraySize);
	private static ArrayList<String> arrivalTime = new ArrayList<String>(arraySize);
	
	// Constructor(s) (The array lists are automatically initialized when the class is created.)
	public EmployeeAttendance() {
		System.out.println("A new Employee Attendance Class has been created.");
	}

	// Setter(s)
	public void setName(int i, String na) {
		name.set(i, na);
	}
	
	public void setAddress(int i, String ad) {
		address.set(i, ad);
	}
	
	public void setPresence(int i, String pr) {
		presence.set(i, pr);
	}
	
	public void setArrivalTime(int i, String ar) {
		arrivalTime.set(i, ar);
	}
	
	public void addEmployee(String na, String ad, String pr, String ar) {
		// Add the string data to the array list.
		name.add(na);
		address.add(ad);
		presence.add(pr);
		arrivalTime.add(ar);
	}
	
	public void deleteEmployeeByName(String na) {
		boolean deleted = false;

		// Loop through the name array to find the matching name the user input, then
		// set all values in that location to null.
		for (int i = 0; i < name.size(); i++) {
			if (name.get(i) != null && name.get(i).contains(na) && deleted == false) {
				name.set(i, null);
				address.set(i, null);
				presence.set(i, null);
				arrivalTime.set(i, null);
				deleted = true;
			}
		}
	}

	public void markEmployeeAttendanceByName(String na) {
		// Loop through the name array until an empty space is found, then mark the
		// presence as present and run the markEmployeeArrivalTime function.
		for (int i = 0; i < name.size(); i++) {
			if (name.get(i).contains(na)) {
				presence.set(i, "Present");
				arrivalTime.set(i, "08:00 AM");
			}
		}
	}

	public void markEmployeeAbsenceByName(String na) {
		// Loop through the name array until an empty space is found, and mark the
		// presence as absent and the arrival time as N/A.
		for (int i = 0; i < name.size(); i++) {
			if (name.get(i).contains(na)) {
				presence.set(i, "Absent");
				arrivalTime.set(i, "N/A");
			}
		}
	}
	
	public void setArrivalTimeByName(String na, String ar) {
		// Loop through the name array until an empty space is found, and mark the
		// presence as absent and the arrival time as N/A.
		for (int i = 0; i < name.size(); i++) {
			if (name.get(i).contains(na)) {
				presence.set(i, "Present");
				arrivalTime.set(i, ar);
			}
		}
	}

	// Getter(s)
	public int getMaxSize() {
		return arraySize;
	}
	
	public int getSize() {
		return name.size();
	}
	
	public String getName(int i) {
		return name.get(i);
	}
	
	public String getAddress(int i) {
		return address.get(i);
	}
	
	public String getPresence(int i) {
		return presence.get(i);
	}
	
	public String getArrivalTime(int i) {
		return arrivalTime.get(i);
	}
	
	public String writeAllEmployees() {
		String allEmployees = "";
		// Loop through name array to find a full spot, and display information for that
		// employee.
		for (int i = 0; i < name.size(); i++) {
			if (name.get(i) != null && name.get(i) != "") {
				allEmployees += name.get(i) + "\n" + address.get(i) + "\n" + presence.get(i) + "\n" + arrivalTime.get(i) + "\n";
			}
		}
		if (allEmployees == "") {
			return " ";
		} else {
			return allEmployees;
		}
	}
	
	public String listAllEmployees() {
		String allEmployees = "";
		// Loop through name array to find a full spot, and display information for that
		// employee.
		for (int i = 0; i < name.size(); i++) {
			if (name.get(i) != null && name.get(i) != "") {
				allEmployees += name.get(i) + "\n	" + address.get(i) + "\n	" + presence.get(i) + "\n	" + arrivalTime.get(i) + "\n";
			}
		}
		if (allEmployees == "") {
			return "No employees found.";
		} else {
			return allEmployees;
		}
	}

	public String listPresentEmployees() {
		String presentEmployees = "";
		// Loop through presence array to find a full spot, and display information for
		// that employee.
		for (int i = 0; i < presence.size(); i++) {
			if (presence.get(i).charAt(0) == 'P' || presence.get(i).charAt(0) == 'p') {
				presentEmployees += name.get(i) + "\n	" + address.get(i) + "\n	" + presence.get(i) + "\n	" + arrivalTime.get(i) + "\n";
			}
		}
		if (presentEmployees == "") {
			return "No present employees found.";
		} else {
			return presentEmployees;
		}
	}

	public String listAbsentEmployees() {
		String absentEmployees = "";
		// Loop through presence array to find a full spot, and display information for
		// that employee.
		for (int i = 0; i < presence.size(); i++) {
			if (presence.get(i).charAt(0) == 'A' || presence.get(i).charAt(0) == 'a') {
				absentEmployees += name.get(i) + "\n	" + address.get(i) + "\n	" + presence.get(i) + "\n	" + arrivalTime.get(i) + "\n";
			}
		}
		if (absentEmployees == "") {
			return "No absent employees found.";
		} else {
			return absentEmployees;
		}	
	}

	public String findEmployeeByName(String nameChoice) {
		// Loop through name array to find a name match, and display information for
		// that employee.
		for (int i = 0; i < name.size(); i++) {
			if (name.get(i).contains(nameChoice)) {
				return (name.get(i) + "\n	" + address.get(i) + "\n	" + presence.get(i) + "\n	" + arrivalTime.get(i));
			}
		}
		return "No matching name found.";
	}

	// No mutators were necessary, data was only being added and retrieved.
	
}
