package edu.institution.midterm;

import static org.junit.Assert.assertEquals;
import java.io.File;
import org.junit.Test;

public class PartManagerTest {
	
	@Test // Asserts whether the price of 290B7266J1 is equal to $415.16 using costPart().
	public void assembly290B7266J1WorksWithCostPart() {
		PartManagerImpl partManager = new PartManagerImpl();
		partManager.importPartStore(System.getProperty("user.home") + File.separator + "Java2" + File.separator + "bom.json");
		double price = 415.16;
		double delta = 0.001;
		assertEquals(partManager.costPart("290B7266J1").getPrice(), price, delta);
	}
	
	@Test // Asserts whether the price of 290B7266J2 is equal to $532.20 using costPart().
	public void assembly290B7266J2WorksWithCostPart() {
		PartManagerImpl partManager = new PartManagerImpl();
		partManager.importPartStore(System.getProperty("user.home") + File.separator + "Java2" + File.separator + "bom.json");
		double price = 532.20;
		double delta = 0.001;
		assertEquals(partManager.costPart("290B7266J2").getPrice(), price, delta);
	}
	
	@Test // Asserts whether the price of 290B7266J6 is equal to $334.10 using costPart().
	public void assembly290B7266J6WorksWithCostPart() {
		PartManagerImpl partManager = new PartManagerImpl();
		partManager.importPartStore(System.getProperty("user.home") + File.separator + "Java2" + File.separator + "bom.json");
		double price = 334.10;
		double delta = 0.001;
		assertEquals(partManager.costPart("290B7266J6").getPrice(), price, delta);
	}
	
	@Test // Asserts whether the price of 20-0001 is equal to $96.39 using costPart().
	public void assembly200001WorksWithCostPart() {
		PartManagerImpl partManager = new PartManagerImpl();
		partManager.importPartStore(System.getProperty("user.home") + File.separator + "Java2" + File.separator + "bom.json");
		double price = 96.39;
		double delta = 0.001;
		assertEquals(partManager.costPart("20-0001").getPrice(), price, delta);
	}
	
	@Test // Asserts whether the price of 20-0015 is equal to $70.46 using costPart().
	public void assembly200015WorksWithCostPart() {
		PartManagerImpl partManager = new PartManagerImpl();
		partManager.importPartStore(System.getProperty("user.home") + File.separator + "Java2" + File.separator + "bom.json");
		double price = 70.46;
		double delta = 0.001;
		assertEquals(partManager.costPart("20-0015").getPrice(), price, delta);
	}
	
	@Test // Asserts that costPart() returns null when sent a null string.
	public void nullCostPartReturnsNull() {
		PartManagerImpl partManager = new PartManagerImpl();
		partManager.importPartStore(System.getProperty("user.home") + File.separator + "Java2" + File.separator + "bom.json");
		assertEquals(partManager.costPart(null), null);
	}
	
	@Test // Asserts that costPart() returns null when sent an empty string.
	public void emptyCostPartReturnsNull() {
		PartManagerImpl partManager = new PartManagerImpl();
		partManager.importPartStore(System.getProperty("user.home") + File.separator + "Java2" + File.separator + "bom.json");
		assertEquals(partManager.costPart(""), null);
	}
	
	@Test // Asserts that costPart() returns null when sent a part that does not exist.
	public void nonexistentCostPartReturnsNull() {
		PartManagerImpl partManager = new PartManagerImpl();
		partManager.importPartStore(System.getProperty("user.home") + File.separator + "Java2" + File.separator + "bom.json");
		assertEquals(partManager.costPart("apple"), null);
	}
	
	@Test // Asserts that retrievePart() retrieves assemblies.
	public void retrievePartRetrievesAssemblies() {
		PartManagerImpl partManager = new PartManagerImpl();
		partManager.importPartStore(System.getProperty("user.home") + File.separator + "Java2" + File.separator + "bom.json");
		Part partToCompare = new Part();
		partToCompare.setName("Rotor Shaft Assembly Final");
		assertEquals(partManager.retrievePart("290B7266J1").getName(), partToCompare.getName());
	}
	
	@Test // Asserts that retrievePart() retrieves components.
	public void retrievePartRetrievesComponents() {
		PartManagerImpl partManager = new PartManagerImpl();
		partManager.importPartStore(System.getProperty("user.home") + File.separator + "Java2" + File.separator + "bom.json");
		Part partToCompare = new Part();
		partToCompare.setName("EveryRoad, PCBA, Model 300");
		assertEquals(partManager.retrievePart("20-0015").getName(), partToCompare.getName());
	}
	
	@Test // Asserts that retrievePart() returns null when asked to retrieve a null part.
	public void retrievePartReturnsNullWhenSentNull() {
		PartManagerImpl partManager = new PartManagerImpl();
		partManager.importPartStore(System.getProperty("user.home") + File.separator + "Java2" + File.separator + "bom.json");
		assertEquals(partManager.retrievePart(null), null);
	}
	
	@Test // Asserts that retrievePart() returns null when asked to retrieve an empty string.
	public void retrievePartReturnsNullWhenSentAnEmptyString() {
		PartManagerImpl partManager = new PartManagerImpl();
		partManager.importPartStore(System.getProperty("user.home") + File.separator + "Java2" + File.separator + "bom.json");
		assertEquals(partManager.retrievePart(""), null);
	}
	
	@Test // Asserts that retrievePart() returns null when asked to retrieve a nonexistent part.
	public void retrievePartReturnsNullWhenSentANonexistentPart() {
		PartManagerImpl partManager = new PartManagerImpl();
		partManager.importPartStore(System.getProperty("user.home") + File.separator + "Java2" + File.separator + "bom.json");
		assertEquals(partManager.retrievePart("apple"), null);
	}
	
	@Test // Asserts that getFinalAssemblies() returns a list of all final assemblies in ascending order by part number.
	public void getFinalAssembliesReturnsFinalAssemblies() {
		PartManagerImpl partManager = new PartManagerImpl();
		partManager.importPartStore(System.getProperty("user.home") + File.separator + "Java2" + File.separator + "bom.json");
		assertEquals(partManager.getFinalAssemblies().get(0), partManager.retrievePart("20-0001"));
		assertEquals(partManager.getFinalAssemblies().get(1), partManager.retrievePart("290B7266J1"));
		assertEquals(partManager.getFinalAssemblies().get(2), partManager.retrievePart("290B7266J2"));
		assertEquals(partManager.getFinalAssemblies().get(3), partManager.retrievePart("290B7266J6"));
	}

	@Test // Asserts that getPurchasedPartsByPrice() returns the parts ordered by price in descending order.
	public void getPurchasedPartsByPriceReturnsPurchasedPartsOrderedByPrice() {
		PartManagerImpl partManager = new PartManagerImpl();
		partManager.importPartStore(System.getProperty("user.home") + File.separator + "Java2" + File.separator + "bom.json");
		assertEquals(partManager.getPurchasedPartsByPrice().get(0), partManager.retrievePart("290B381041")); // First list item checked.
		assertEquals(partManager.getPurchasedPartsByPrice().get(25), partManager.retrievePart("40-0045")); // Middle list item checked.
		assertEquals(partManager.getPurchasedPartsByPrice().get(51), partManager.retrievePart("40-0057")); // Last list item checked.
	}
}
