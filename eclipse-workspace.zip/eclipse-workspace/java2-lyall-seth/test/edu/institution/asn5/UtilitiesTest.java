package edu.institution.asn5;

import static org.junit.Assert.assertEquals;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import edu.institution.actions.asn5.Utilities;
import edu.institution.asn2.LinkedInUser;

public class UtilitiesTest {

	@Test // Asserts that when duplicate integers are included in a list, the removeDuplicates() method will fix the list.
	public void duplicateIntegersAreRemoved() {
		List<Integer> list = new ArrayList<Integer>();
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		list.add(5);
		list.add(3);
		list.add(4);
		
		Utilities utilities = new Utilities();
		utilities.removeDuplicates(list);
		List<Integer> compareList = new ArrayList<Integer>();
		compareList.add(1);
		compareList.add(2);
		compareList.add(3);
		compareList.add(4);
		compareList.add(5);
		
		assertEquals(list, compareList);
	}
	
	@Test // Asserts that when duplicate Strings are included in a list, the removeDuplicates() method will fix the list.
	public void duplicateStringsAreRemoved() {
		List<String> list = new ArrayList<String>();
		list.add("one");
		list.add("two");
		list.add("three");
		list.add("four");
		list.add("four");
		list.add("five");
		list.add("four");
		
		Utilities utilities = new Utilities();
		utilities.removeDuplicates(list);
		List<String> compareList = new ArrayList<String>();
		compareList.add("one");
		compareList.add("two");
		compareList.add("three");
		compareList.add("four");
		compareList.add("five");
		
		assertEquals(list, compareList);
	}
	
	@Test // Asserts that when duplicate LinkedInUsers are included in a list, the removeDuplicates() method will fix the list.
	public void duplicateLinkedInUsersAreRemoved() {
		List<LinkedInUser> list = new ArrayList<LinkedInUser>();
		list.add(new LinkedInUser("phil", "phil"));
		list.add(new LinkedInUser("gary", "gary"));
		list.add(new LinkedInUser("alex", "alex"));
		list.add(new LinkedInUser("alex", "alex"));
		list.add(new LinkedInUser("patt", "patt"));
		list.add(new LinkedInUser("gwen", "gwen"));
		list.add(new LinkedInUser("patt", "patt"));
		
		Utilities utilities = new Utilities();
		utilities.removeDuplicates(list);
		List<LinkedInUser> compareList = new ArrayList<LinkedInUser>();
		compareList.add(new LinkedInUser("phil", "phil"));
		compareList.add(new LinkedInUser("gary", "gary"));
		compareList.add(new LinkedInUser("alex", "alex"));
		compareList.add(new LinkedInUser("patt", "patt"));
		compareList.add(new LinkedInUser("gwen", "gwen"));
		
		assertEquals(list, compareList);
	}
	
	@Test // Asserts that an empty list is completely unchanged when passed to the removeDuplicates() method.
	public void nothingIsDoneToAnEmptyList() {
		List<LinkedInUser> list = new ArrayList<LinkedInUser>();
		
		Utilities utilities = new Utilities();
		utilities.removeDuplicates(list);
		List<LinkedInUser> compareList = new ArrayList<LinkedInUser>();
		
		assertEquals(list, compareList);
	}
	
	@Test // Asserts that an empty list is completely unchanged when passed to the removeDuplicates() method.
	public void nothingIsDoneToAOneItemList() {
		List<LinkedInUser> list = new ArrayList<LinkedInUser>();
		list.add(new LinkedInUser("seth", "seth"));
		
		Utilities utilities = new Utilities();
		utilities.removeDuplicates(list);
		List<LinkedInUser> compareList = new ArrayList<LinkedInUser>();
		compareList.add(new LinkedInUser("seth", "seth"));
		
		assertEquals(list, compareList);
	}
	
	@Test // Asserts that only one item remains when a list is passed to the removeDuplicates() method and all items are the same.
	public void oneItemRemainsInAUniformList() {
		List<LinkedInUser> list = new ArrayList<LinkedInUser>();
		list.add(new LinkedInUser("seth", "seth"));
		list.add(new LinkedInUser("seth", "seth"));
		list.add(new LinkedInUser("seth", "seth"));
		list.add(new LinkedInUser("seth", "seth"));
		list.add(new LinkedInUser("seth", "seth"));
		list.add(new LinkedInUser("seth", "seth"));
		list.add(new LinkedInUser("seth", "seth"));
		
		Utilities utilities = new Utilities();
		utilities.removeDuplicates(list);
		List<LinkedInUser> compareList = new ArrayList<LinkedInUser>();
		compareList.add(new LinkedInUser("seth", "seth"));
		
		assertEquals(list, compareList);
	}
	
	@Test // Asserts that when duplicate nulls are included in a list, the removeDuplicates() method will remove the duplicate nulls.
	public void nullItemDuplicatesAreRemoved() {
		List<LinkedInUser> list = new ArrayList<LinkedInUser>();
		list.add(new LinkedInUser("phil", "phil"));
		list.add(new LinkedInUser(null, null));
		list.add(new LinkedInUser("alex", "alex"));
		list.add(new LinkedInUser("alex", "alex"));
		list.add(new LinkedInUser("patt", "patt"));
		list.add(new LinkedInUser(null, null));
		list.add(new LinkedInUser("patt", "patt"));
		
		Utilities utilities = new Utilities();
		utilities.removeDuplicates(list);
		List<LinkedInUser> compareList = new ArrayList<LinkedInUser>();
		compareList.add(new LinkedInUser("phil", "phil"));
		compareList.add(new LinkedInUser(null, null));
		compareList.add(new LinkedInUser("alex", "alex"));
		compareList.add(new LinkedInUser("patt", "patt"));
		
		assertEquals(list, compareList);
	}
	
	@Test // Asserts that a linear search for an integer returns the correct integer.
	public void integerLinearSearchReturnsInteger() {
		List<Integer> list = new ArrayList<Integer>();
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		list.add(5);
		
		Utilities utilities = new Utilities();
		int found = utilities.linearSearch(list, 4);
		
		assertEquals(found, 4);
	}
	
	@Test // Asserts that a linear search for a string returns the correct string.
	public void stringLinearSearchReturnsString() {
		List<String> list = new ArrayList<String>();
		list.add("one");
		list.add("two");
		list.add("three");
		list.add("four");
		list.add("five");
		
		Utilities utilities = new Utilities();
		String found = utilities.linearSearch(list, "three");
		
		assertEquals(found, "three");
	}
	
	@Test // Asserts that a linear search for a LinkedInUser returns the correct LinkedInUser.
	public void linkedInUserLinearSearchReturnsLinkedInUser() {
		List<LinkedInUser> list = new ArrayList<LinkedInUser>();
		list.add(new LinkedInUser("phil", "phil"));
		list.add(new LinkedInUser("gary", "gary"));
		list.add(new LinkedInUser("alex", "alex"));
		list.add(new LinkedInUser("patt", "patt"));
		list.add(new LinkedInUser("gwen", "gwen"));
		
		Utilities utilities = new Utilities();
		LinkedInUser found = utilities.linearSearch(list, new LinkedInUser("alex", "alex"));
		
		assertEquals(found, new LinkedInUser("alex", "alex"));
	}
	
	@Test // Asserts that a linear search that is empty returns null.
	public void emptyLinearSearchReturnsNull() {
		List<LinkedInUser> list = new ArrayList<LinkedInUser>();
		
		Utilities utilities = new Utilities();
		LinkedInUser found = utilities.linearSearch(list, new LinkedInUser("alex", "alex"));
		
		assertEquals(found, null);
	}
	
	@Test // Asserts that a null linear search returns null.
	public void nullUserSearchReturnsNull() {
		List<LinkedInUser> list = new ArrayList<LinkedInUser>();
		list.add(new LinkedInUser(null, null));
		list.add(new LinkedInUser(null, null));
		list.add(new LinkedInUser(null, null));
		list.add(new LinkedInUser(null, null));
		list.add(new LinkedInUser(null, null));
		
		Utilities utilities = new Utilities();
		LinkedInUser found = utilities.linearSearch(list, new LinkedInUser(null, null));
		
		assertEquals(found, new LinkedInUser(null, null));
	}
	
	@Test // Asserts that a linear search with one value returns that value.
	public void singleLinearSearchReturnsASingleValue() {
		List<LinkedInUser> list = new ArrayList<LinkedInUser>();
		list.add(new LinkedInUser("seth", "seth"));
		
		Utilities utilities = new Utilities();
		LinkedInUser found = utilities.linearSearch(list, new LinkedInUser("seth", "seth"));
		
		assertEquals(found, new LinkedInUser("seth", "seth"));
	}
}
