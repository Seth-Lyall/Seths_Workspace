/*
 Copyright (C) 2020. Doug Estep -- All Rights Reserved.
 Copyright Registration Number: TXU002159309.

 This file is part of the Tag My Code application.

 This application is protected under copyright laws and cannot be used, distributed, or copied without prior written
 consent from Doug Estep.  Unauthorized distribution or use is strictly prohibited and punishable by domestic and
 international law.

 Proprietary and confidential.
 */
package edu.institution;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import edu.institution.asn2.LinkedInUser;

/**
 * Contains static helper methods to aid with the command line user interface.
 */
public class ApplicationHelper {

	/**
	 * Explanation:
	 * A HashMap is good for storing the skill set counts because:
	 * It can store integer data with a string key.
	 * Skill set entries can be located, inserted, and deleted with a hash map.
	 * It does not need to be thread safe nor synchronized because actions being performed 
	 * on the skill set counts are being done after it is loaded in. (Thread safety is not an issue.)
	 * It is not required for the skill set counts to be held in any particular order.
	 */
	private static Map<String, Integer> skillsetCounts = new HashMap<String, Integer>();
	
	/**
	* Increments the number of users associated with the supplied skill set.
	* If this is the first occurrence of the supplied skill set, then add
	* the skill set to your collection and default the count to one.
	*
	* @param skillset the skill set to increment.
	*/
	public static void incrementSkillsetCount(String skillset) {
		if (skillsetCounts.containsKey(skillset)) {
			skillsetCounts.put(skillset, skillsetCounts.get(skillset) + 1);
		} else {
			skillsetCounts.put(skillset, 1);
		}
	}
	
	/**
	* Decrements the number of users associated with the supplied skill set.
	* If the number of users associated with the supplied skill set is zero,
	* then remove the skill set from your collection.
	*
	* @param skillset the skill set to decrement.
	*/
	public static void decrementSkillsetCount(String skillset) {
		skillsetCounts.put(skillset, skillsetCounts.get(skillset) - 1);
		if (skillsetCounts.get(skillset) <= 0) {
			skillsetCounts.remove(skillset);
		}
	}
	
	/**
	* Retrieves the number of users associated with the supplied skill set.
	* If the skill set is not in the collection, return -1.
	*
	* @param skillset the skill set to lookup.
	*/
	public static int retrieveSkillsetCount(String skillset) {
		if (skillsetCounts.containsKey(skillset)) {
			return skillsetCounts.get(skillset);
		} else {
			return -1;
		}
	}
	
	/**
	* Loops through each user and increments the global skill set usage count for
	* each skill set associated with the user.
	*
	* @param users the list of users.
	*/
	public static void initSkillsetUsages(List<LinkedInUser> users) {
		users.forEach(e -> e.getSkillsets().forEach(f -> incrementSkillsetCount(f)));
	}
	
	/**
	 * Displays the supplied message to the console.
	 * 
	 * @param message the message.
	 */
	public static void showMessage(String message) {
		System.out.println("\n" + message);
	}
}
