package edu.institution.actions.asn4;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import edu.institution.UserRepository;
import edu.institution.actions.MenuAction;
import edu.institution.asn2.LinkedInUser;

public class ListConnectionAction implements MenuAction {

	// This action loops through the logged in user’s connections and display the user name of each
	// LinkedIn user in the connections list. 
	//
	// If the logged in user has no connections, displays message, “You have no connections” to the console.
	//
	// Returns true to keep the user logged in.
	@Override // Override the process method.
	public boolean process(Scanner scanner, UserRepository userRepository, LinkedInUser loggedInUser) {
		List<LinkedInUser> userList = new ArrayList<LinkedInUser>(loggedInUser.getConnections());
		if (userList.size() < 1) {
			System.out.println("\nYou have no connections");
			return true;
		} else {
			for (LinkedInUser u: userList) {
				System.out.println(u.getUsername());
			}
			return true;
		}
	}
}
