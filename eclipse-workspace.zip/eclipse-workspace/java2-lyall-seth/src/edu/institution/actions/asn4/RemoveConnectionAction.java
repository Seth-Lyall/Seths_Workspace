package edu.institution.actions.asn4;

import java.util.Scanner;
import edu.institution.UserRepository;
import edu.institution.actions.MenuAction;
import edu.institution.asn2.LinkedInException;
import edu.institution.asn2.LinkedInUser;

public class RemoveConnectionAction implements MenuAction {

	// Prompts for the user name of the connection to remove.
	//
	// If the user does NOT exist, displays the message “There is no user with that user name”
	// and returns true to keep the user signed in.
	//
	// If the user does exist, removes the user from the logged in user’s connection list and
	// displays the message “The connection was removed successfully”.
	//
	// If the user was not connected to the logged in user, catches the LinkedInException
	// that was thrown in the second assignment and displays the message contained within
	// the exception.
	//
	// Return true to keep the user signed in.
	@Override // Override the process method.
	public boolean process(Scanner scanner, UserRepository userRepository, LinkedInUser loggedInUser) {
		String username = "";
		System.out.println("\nEnter the user name of the user you want to remove");
		username = scanner.nextLine();
		if (userRepository.retrieve(username) == null) {
			System.out.println("\nThere is no user with that user name");
			return true;
		} else if (userRepository.retrieve(username).equals(loggedInUser)) {
			System.out.println("\nYou cannot remove yourself");
			return true;
		} else {
			LinkedInUser userToRemove = userRepository.retrieve(username);
			try {
				loggedInUser.removeConnection(userToRemove);
				System.out.println("\nThe connection was removed successfully");
				return true;
			} catch (LinkedInException ex) {
				System.out.println(ex.getMessage());
				return true;
			}
		}
	}
}
