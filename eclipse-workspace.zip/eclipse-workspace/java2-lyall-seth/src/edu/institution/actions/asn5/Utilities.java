package edu.institution.actions.asn5;

import java.util.ArrayList;
import java.util.List;

public class Utilities {

	// Steps  through a generic list that was passed to the method
	// and removes any duplicate entries in the list. 
	//
	// Returns a list with no duplicate entries.
	public <T> void removeDuplicates(List<T> items) {
		List<T> newList = new ArrayList<T>();
		for (T x: items) {
			boolean found = false;
			for (T y: items) {
				if (x.equals(y) && found == false && !(newList.contains(x))) {
					newList.add(y);
					found = true;
				}
			}
		}
		items.clear();
		for (T x: newList) {
			items.add(x);
		}
	}

	// Steps through a generic list that was passed to the method
	// and finds a generic value that matches the generic key
	// that was passed.
	//
	// Returns a generic value.
	public <E> E linearSearch(List<E> list, E key) {
		for (E x: list) {
			if (x.equals(key)) {
				return x;
			}
		}
		return null;
	}
}
