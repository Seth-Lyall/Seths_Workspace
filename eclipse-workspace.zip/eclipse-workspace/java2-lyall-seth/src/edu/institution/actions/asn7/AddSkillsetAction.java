package edu.institution.actions.asn7;

import java.util.Scanner;
import java.util.Set;
import edu.institution.ApplicationHelper;
import edu.institution.UserRepository;
import edu.institution.actions.MenuAction;
import edu.institution.asn2.LinkedInUser;

public class AddSkillsetAction implements MenuAction {

	// Prompt the user to enter a skill set to add.
	// If they don't have that skill set, then use addSkillset(),
	// incrementSkillsetCount(), and display "(skill set) has been added to your skillsets".
	// Return true to keep the user signed in.
	@Override // Override the process method.
	public boolean process(Scanner scanner, UserRepository userRepository, LinkedInUser loggedInUser) {
		Set<String> userSkillsets = loggedInUser.getSkillsets();
		String skillset;
		System.out.print("Please enter the skillset you want to add: ");
		skillset = scanner.nextLine();
		if (userSkillsets == null || userSkillsets.isEmpty()) {
			loggedInUser.addSkillset(skillset);
			ApplicationHelper.incrementSkillsetCount(skillset);
			System.out.println(skillset + " has been added to your skillsets");
		} else if (userSkillsets.contains(skillset)) {
			System.out.println(skillset + " is already in your skillsets");
		} else {
			loggedInUser.addSkillset(skillset);
			ApplicationHelper.incrementSkillsetCount(skillset);
			System.out.println(skillset + " has been added to your skillsets");
		}
		return true;
	}
}
