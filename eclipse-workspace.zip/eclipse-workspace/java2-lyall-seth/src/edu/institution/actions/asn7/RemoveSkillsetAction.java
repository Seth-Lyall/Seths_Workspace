package edu.institution.actions.asn7;

import java.util.Scanner;
import java.util.Set;
import edu.institution.ApplicationHelper;
import edu.institution.UserRepository;
import edu.institution.actions.MenuAction;
import edu.institution.asn2.LinkedInUser;

public class RemoveSkillsetAction implements MenuAction {

	// Prompts the user to enter the skill set they want to remove.
	// If they do not have that skill set, display "(skill set) is not in your skillsets"
	// and return true to keep the user signed in.
	// If they have the skill set use removeSkillset(), decrementSkillsetCount(), and
	// display "(skill set) has been removed from your skillsets".
	// Return true to keep the user signed in.
	@Override // Override the process method.
	public boolean process(Scanner scanner, UserRepository userRepository, LinkedInUser loggedInUser) {
		Set<String> userSkillsets = loggedInUser.getSkillsets();
		String skillset;
		System.out.print("Please enter the skillset you want to remove: ");
		skillset = scanner.nextLine();
		if (userSkillsets == null || userSkillsets.isEmpty()) {
			System.out.println("You have no skillsets");
		} else if (userSkillsets.contains(skillset)) {
			loggedInUser.removeSkillset(skillset);
			ApplicationHelper.decrementSkillsetCount(skillset);
			System.out.println(skillset + " has been removed from your skillsets");
		} else {
			System.out.println(skillset + " is not in your skillsets");
		}
		return true;
	}
}
