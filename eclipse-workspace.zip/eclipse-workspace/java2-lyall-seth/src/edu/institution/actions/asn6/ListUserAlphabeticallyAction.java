package edu.institution.actions.asn6;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import edu.institution.UserRepository;
import edu.institution.actions.MenuAction;
import edu.institution.asn2.LinkedInUser;

public class ListUserAlphabeticallyAction implements MenuAction {

	// Sorts the userRepository alphabetically by user name and displays the results.
	@Override // Override the process method.
	public boolean process(Scanner scanner, UserRepository userRepository, LinkedInUser loggedInUser) {
		List<LinkedInUser> userList = new ArrayList<LinkedInUser>();
		
		for (LinkedInUser u: userRepository.retrieveAll()) {
			userList.add(u);
		}
		
		Collections.sort(userList);
		
		for (LinkedInUser u: userList) {
			System.out.println(u.getUsername());
		}
		return true;
	}
}
