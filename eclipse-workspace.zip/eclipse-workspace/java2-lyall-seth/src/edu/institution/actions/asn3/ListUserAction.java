package edu.institution.actions.asn3;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import edu.institution.UserRepository;
import edu.institution.actions.MenuAction;
import edu.institution.asn2.LinkedInUser;

public class ListUserAction implements MenuAction {
	// Retrieves all of the LinkedIn users from the user repository and prints each
	// user name to the console.
	@Override // Override the process() method.
	public boolean process(Scanner scanner, UserRepository userRepository, LinkedInUser loggedInUser) {
		List<LinkedInUser> userList = new ArrayList<LinkedInUser>();
		userList.addAll(userRepository.retrieveAll());
		for (LinkedInUser u: userList) {
				System.out.println(u.getUsername());
		}
		return true;
	}
}
