package edu.institution.midterm;

import java.util.List;

public interface PartManager {
	// Mutator(s) and Accessor(s)
	// Imports the part store from an external file.
	// Accepts the file path to the file which contains the parts to import.
	// Returns the number of parts imported.
	int importPartStore(String filePath);
	
	// Computes the cost to manufacture the part associated with the supplied part number.
	// Accepts a part number which identifies the part to compute the cost for.
	Part costPart(String partNumber);
	
	// Retrieves  the part associated with the supplied part number from the part store.
	// Accepts a part number which identifies the part to retrieve.
	// Returns the part instance associated with the supplied part number or null if not found.
	Part retrievePart(String partNumber);
	
	// Returns all final assembly parts stored alphabetically by their part number.
	// Final assemblies have a part type of "ASSEMBLY".
	List<Part> getFinalAssemblies();
	
	// Returns all purchased parts sorted by their price, highest price to lowest.
	// Purchase parts have a part type of "PURCHASE".
	List<Part> getPurchasedPartsByPrice();
}
