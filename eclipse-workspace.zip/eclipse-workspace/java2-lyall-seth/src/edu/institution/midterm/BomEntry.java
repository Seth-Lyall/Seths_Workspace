package edu.institution.midterm;

import java.util.Objects;

public class BomEntry {
	// Member variable(s)
	private String partNumber; // Identifies the part in the BOM.
	private int quantity; // The Quantity needed for this part entry.
	
	// Getter(s) and Setter(s)
	public String getPartNumber() {
		return this.partNumber;
	}
	public void setPartNumber(String pn) {
		this.partNumber = pn;
	}
	public int getQuantity() {
		return this.quantity;
	}
	public void setQuantity(int q) {
		this.quantity = q;
	}
	
	@Override // Override the equals() method.
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BomEntry other = (BomEntry) obj;
		return Objects.equals(partNumber, other.partNumber);
	}
	@Override // Override the hashCode() method.
	public int hashCode() {
		return Objects.hash(partNumber);
	}
	@Override // Override the toString() method.
	public String toString() {
		return "Part Number: " + this.getPartNumber() + " Quantity: " + this.getQuantity();
	}
}
