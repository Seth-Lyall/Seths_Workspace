package java_00047534;

public class WalletAddress {
	// Member Variable(s)
	private String publicKeyWallet;
	
	// Constructor(s)
	// Set public key wallet to null given no input.
	public WalletAddress() {
		setAdd(null);
	}
	// Set public key wallet to address with string input from the user.
	public WalletAddress(final String a) {
		setAdd(a);
	}
	
	// Mutator(s) and Accessor(s)
	public String getAdd() {
		return publicKeyWallet;
	}
	public void setAdd(final String a) {
		this.publicKeyWallet = a;
	}
}
