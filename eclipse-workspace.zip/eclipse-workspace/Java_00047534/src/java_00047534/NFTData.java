package java_00047534;

public class NFTData {
	// Member Variable(s)
	private String userName;
	private String productName;
	private String rarity;
	private String collectionName;
	private double floorPrice;
	private String tokenType;
	private String nftAddress;
	public WalletAddress walletAddress;
	
	// Constructor(s)
	// Gets the username and collection from user input.
	public NFTData(final String un, final String cn) {
		setUN(un);
		setCollection(cn);
	}
	// Get the username, product name, rarity, collection name, and floor price from user input.
	public NFTData(final String un, final String pn, final String r, final String cn, final double fp) {
		setUN(un);
		setPN(pn);
		setRarity(r);
		setCollection(cn);
		setFloorPrice(fp);
	}
	
	// Mutator(s) and Accessor(s)
	public String getUN() {
		return this.userName;
	}
	public void setUN(final String a) {
		this.userName = a;
	}
	public String getPN() {
		return this.productName;
	}
	public void setPN(final String a) {
		this.productName = a;
	}
	public String getRarity() {
		return rarity;
	}
	public void setRarity(final String a) {
		this.rarity = a;
	}
	public String getCollection() {
		return this.collectionName;
	}
	public void setCollection(final String a) {
		this.collectionName = a;
	}
	public double getFloorPrice() {
		return this.floorPrice;
	}
	public void setFloorPrice(final double a) {
		this.floorPrice = a;
	}
	public String getTokenType() {
		return this.tokenType;
	}
	public void setTokenType(final String a) {
		this.tokenType = a;
	}
	public String getNFTAddress() {
		return this.nftAddress;
	}
	public void setNFTAddress(final String a) {
		this.nftAddress = a;
	}
	@Override //Override the toString method.
	public String toString() {
		return "Username: " + getUN() + "\nProduct Name: " + getPN() + "\nRarity: " + getRarity() + "\nCollection Name: " + 
				getCollection() + "\nFloor Price: " + getFloorPrice() + "\nToken Type: " + getNFTAddress() + "\nWallet Address: " + walletAddress;
	}
}
