package sinclair.lyall.seth;

import java.util.Scanner;

public class LyallSethCreditCardValidation {

	public static void main(String[] args) {
		long creditCardNumber = 0;
		boolean valid = false;
		Scanner input = new Scanner(System.in);

		// Prompt the user to enter a credit card number.
		System.out.print("Enter a credit card number as a long integer: ");
		creditCardNumber = input.nextLong();
		// Check if the input is valid, using the functions performed below.
		// Display whether it's valid or invalid, and end the program.
		valid = isValid(creditCardNumber);
		if (valid == true) {
			System.out.print(creditCardNumber + " is valid.");
		} else {
			System.out.print(creditCardNumber + " is invalid.");
		}
		input.close();
	}

	public static boolean isValid(long number) {
		boolean validity = true;
		int stepFourTotal = 0;
		int num = 0;
		int stepThreeTotal = 0;
		// Convert the credit card long to a string, and get its length.
		String creditCardNumber = String.valueOf(number);
		int creditCardNumberLength = creditCardNumber.length();

		// Get the total of the odd positioned numbers in the card number.
		for (int i = creditCardNumber.length(); i >= 1; i -= 2) {
			num = (creditCardNumber.charAt(i - 1) - '0');
			stepThreeTotal += num;
		}

		// Get the total for odd positioned numbers, and doubled even positioned
		// numbers.
		stepFourTotal = sumOfDoubleEvenPlace(number) + stepThreeTotal;

		// Check if the total is divisible by ten, and that it matches in length and
		// prefix.
		if ((stepFourTotal % 10 == 0) && (prefixMatched(number, creditCardNumberLength) == true)) {
			return validity;
		} else {
			validity = false;
			return validity;
		}
	}

	public static int sumOfDoubleEvenPlace(long number) {
		int sum = 0;
		int num = 0;
		String numString = "";
		// Convert the credit card long to a string.
		String creditCardNumber = String.valueOf(number);
		for (int i = creditCardNumber.length(); i >= 1; i -= 2) {
			num = (creditCardNumber.charAt(i - 2) - '0') * 2;
			// If the number multiplied by two is two digits, add each digits in the double
			// digit number together, then use that instead.
			if (num >= 10) {
				numString = "";
				numString += num;
				num = 0;
				num += numString.charAt(1) - '0';
				num += numString.charAt(0) - '0';
			}
			// Add the number total to the sum.
			sum += num;
		}
		return sum;
	}

	public static boolean prefixMatched(long number, int d) {
		boolean matched = true;
		// Convert the credit card long to a string.
		String creditCardNumber = String.valueOf(number);
		// Check if the credit card number is at or between 13 and 16 characters long.
		if (d > 12 && d < 17) {
			// Check if the credit card number starts with a valid card prefix.
			if (creditCardNumber.charAt(0) == '4' || creditCardNumber.charAt(0) == '5'
					|| creditCardNumber.charAt(0) == '6'
					|| (creditCardNumber.charAt(0) == '3' && creditCardNumber.charAt(1) == '7')) {
				return matched;
			} else {
				matched = false;
				return matched;
			}
		} else {
			matched = false;
			return matched;
		}
	}

}
