/**
 * Seth Lyall - MVCTC
 * Aug 16, 2022
 */
package sinclair.lyall.seth;

/**
 * @author lyall52354
 *
 */
public class FirstJava {
	/**
	 * @param args
	 */
	public static void main(String[] args) {

		System.out.println("");
		System.out.print("Welcome to Java, ");
		System.out.print("welcome to computer science, ");
		System.out.println("programming is fun.");

		System.out.println("");
		System.out.print("Welcome to Java. ");
		System.out.print("Welcome to Java. ");
		System.out.print("Welcome to Java. ");
		System.out.print("Welcome to Java. ");
		System.out.println("Welcome to Java. ");

		System.out.println("");
		System.out.println("    J    A    V     V    A   ");
		System.out.println("    J   A A    V   V    A A  ");
		System.out.println("J   J  AAAAA    V V    AAAAA ");
		System.out.println(" J J  A     A    V    A     A");

		System.out.println("");
		System.out.println("a     a^2   a^3");
		System.out.println("1     1     1  ");
		System.out.println("2     4     6  ");
		System.out.println("3     9     27 ");
		System.out.println("4     16    64 ");

		System.out.println("");
		System.out.println("The result of the equation is " + ((9.5 * 4.5) - (2.5 * 3)) / (45.5 - 3.5));

		System.out.println("");
		System.out.println("The result of the equation is " + (1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9));

		System.out.println("");
		System.out.println("The result of the first equation is "
				+ (4.0 * (1.0 - (1.0 / 3.0) + (1.0 / 5.0) - (1.0 / 7.0) + (1.0 / 9.0) - (1.0 / 11.0))));
		System.out.println("The result of the second equation is "
				+ (4.0 * (1.0 - (1.0 / 3.0) + (1.0 / 5.0) - (1.0 / 7.0) + (1.0 / 9.0) - (1.0 / 11.0) + (1.0 / 13.0))));

		System.out.println("");
		System.out.println("The area of the circle is " + (5.5 * 5.5 * 3.14159265358979323846));
		System.out.println("The perimeter of the circle is " + (2 * 5.5 * 3.14159265358979323846));

		System.out.println("");
		System.out.println("The area of the rectangle is " + (4.5 * 7.9));
		System.out.println("The perimeter of the rectangle is " + ((4.5 * 2) + (7.9 * 2)));

		System.out.println("");
		System.out.print("The runner ran average speed of " + ((14.0 / (16.0 / 10.0)) / (45.5 / 60.0)));
		System.out.println(" miles per hour.");

		System.out.println("");
		System.out.println("The population for the year 2023 will be "
				+ (312032486.0 + (4505142.857 - 2425846.154 + 700800.0) * 1.0));
		System.out.println("The population for the year 2024 will be "
				+ (312032486.0 + (4505142.857 - 2425846.154 + 700800.0) * 2.0));
		System.out.println("The population for the year 2025 will be "
				+ (312032486.0 + (4505142.857 - 2425846.154 + 700800.0) * 3.0));
		System.out.println("The population for the year 2026 will be "
				+ (312032486.0 + (4505142.857 - 2425846.154 + 700800.0) * 4.0));
		System.out.println("The population for the year 2027 will be "
				+ (312032486.0 + (4505142.857 - 2425846.154 + 700800.0) * 5.0));

		System.out.println("");
		System.out.println(
				"The runner ran an average speed of " + ((24 * (1 / 1.676388889)) * 1.6) + " kilometers an hour.");

		System.out.println("");
		System.out.println("x = " + (((44.5 * 0.55) - (50.2 * 5.90)) / ((3.40 * 0.55) - (50.2 * 2.10))));
		System.out.println("y = " + (((3.40 * 5.90) - (44.5 * 2.10)) / ((3.40 * 0.55) - (50.2 * 2.10))));

	}
}
