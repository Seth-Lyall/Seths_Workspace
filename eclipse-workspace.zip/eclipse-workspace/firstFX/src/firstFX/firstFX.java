package firstFX;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class firstFX extends Application {
	@Override
	public void start(Stage primaryStage) {
		// Pane pane = new Pane();
		// pane.setPadding(new Insets(5, 5, 5, 5));

		Text text = new Text(20, 20, "Click the BUTTON.");
		text.setFont(Font.font("Sans Serif", FontWeight.BOLD, 15));

		Button btnOK = new Button("BUTTON");

		// pane.getChildren().add(pane);
		// pane.getChildren().add(btnOK);

		Scene scene = new Scene(btnOK, 1000, 700);

		primaryStage.setTitle("My First JavaFX");
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	public static void main(String[] args) {
		Application.launch(args);
	}
}
