/**
 * Seth Lyall - MVCTC
 * Nov 2, 2022
 */
package chap12;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.InputMismatchException;
import java.util.Scanner;

public class DemoExceptionsIO {

	public static void main(String[] args) {
		// Scanner for reading user input.
		Scanner input = new Scanner(System.in);
		// File, Scanner, and PrintWriter for reading and writing 20 random numbers from
		// 0 to 200.
		File f = new File("randomNumbers.txt");
		Scanner fileInput = null;
		PrintWriter fileOutput = null;
		// Array Size final.
		final int SIZE = 20;
		// Index number for the user to enter, and array for 20 random numbers from 0 to
		// 200.
		int index = 0;
		double numbers[] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		for (int i = 0; i < SIZE; i++) {
			numbers[i] = (Math.random() * 200);
		}

		// Try to write the array of 20 random numbers from 0 to 200 to the
		// randomNumbers.txt file. Check for FileNotFoundException.
		try {
			fileOutput = new PrintWriter(f);
			for (int i = 0; i < SIZE; i++) {
				fileOutput.println(numbers[i]);
			}
		} catch (FileNotFoundException ex) {
			System.out.println("The file was not found.");
			ex.printStackTrace();
		} finally {
			fileOutput.close();
		}

		// Try to read the 20 random numbers from 0 to 200 from the randomNumbers.txt
		// file. Check for FileNotFoundException.
		try {
			fileInput = new Scanner(f);
			while (fileInput.hasNext()) {
				System.out.printf("%10.3f", fileInput.nextDouble());
				System.out.println("");
			}
		} catch (FileNotFoundException ex) {
			System.out.println("The file was not found.");
			ex.printStackTrace();
		} finally {
			fileInput.close();
		}

		// Have the user try to enter an index number, and check for
		// InputMismatchException and IndexOutOfBoundsException.
		System.out.println("");
		System.out.print("Enter an index number: ");
		try {
			index = input.nextInt();

			System.out.println("");
			System.out.print("Element at index " + index + ": ");

			try {
				System.out.printf("%10.3f", numbers[index]);
				System.out.println("");
			} catch (IndexOutOfBoundsException ex) {
				System.out.println("This index number is out of bounds.");
				ex.printStackTrace();
			}
		} catch (InputMismatchException ex) {
			System.out.println("You have not entered valid data.");
			ex.printStackTrace();
		} finally {
			// Close the input scanner, say it was closed, and display the absolute file
			// path with getAbsolutePath().
			input.close();
			System.out.println("");
			System.out.println("The scanner object is closed.");
			System.out.println("");
			System.out.println("File path: " + f.getAbsolutePath());
		}
	}
}
