/**
 * Seth Lyall - MVCTC
 * Aug 23, 2022
 */
package sinclair.lyall.seth;

/**
 * @author lyall52354
 *
 */
public class Hello {

	/**
	 * 
	 */
	public Hello() {

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Hello, World!");
	}

}
