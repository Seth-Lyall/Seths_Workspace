/**
 * Seth Lyall - MVCTC
 * Dec 5, 2022
 */
package chap11InheritancePolymorphism;

public class Employee {
	// Member(s)
	private String firstName = "";
	private String lastName = "";
	private String phoneNumber = "";

	// Constructor(s)
	public Employee() {
		setFirstName("");
		setLastName("");
		setPhoneNumber("");
	}

	public Employee(String f, String l) {
		setFirstName(f);
		setLastName(l);
		setPhoneNumber("");
	}

	public Employee(String f, String l, String p) {
		setFirstName(f);
		setLastName(l);
		setPhoneNumber(p);
	}

	// Setter(s) and Getter(s)
	public void setFirstName(String f) {
		this.firstName = f;
	}

	public void setLastName(String l) {
		this.lastName = l;
	}

	public void setPhoneNumber(String p) {
		this.phoneNumber = p;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public String getLastName() {
		return this.lastName;
	}

	public String getPhoneNumber() {
		return this.phoneNumber;
	}

	@Override // Override the toString method.
	public String toString() {
		return getFirstName() + " " + getLastName() + "\n	Phone: " + getPhoneNumber();
	}
}
