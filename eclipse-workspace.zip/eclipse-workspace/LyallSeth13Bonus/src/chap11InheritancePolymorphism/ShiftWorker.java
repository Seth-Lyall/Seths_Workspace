/**
 * Seth Lyall - MVCTC
 * Dec 5, 2022
 */
package chap11InheritancePolymorphism;

public class ShiftWorker extends Employee {
	// Member(s)
	private double payRate = 0.00;
	private double hoursWorked = 0.00;
	private int shiftNumber = 0;

	// Constructor(s)
	ShiftWorker() {
		super();
		setPayRate(0.00);
		setHoursWorked(0.00);
		setShiftNumber(0);
	}

	ShiftWorker(String f, String l, double r, double h, int s) {
		super(f, l);
		setPayRate(r);
		setHoursWorked(h);
		setShiftNumber(s);
	}

	ShiftWorker(String f, String l, String p, double r, double h, int s) {
		super(f, l, p);
		setPayRate(r);
		setHoursWorked(h);
		setShiftNumber(s);
	}

	// Setter(s) and Getter(s)
	public void setPayRate(double r) {
		this.payRate = r;
	}

	public void setHoursWorked(double h) {
		this.hoursWorked = h;
	}

	public void setShiftNumber(int s) {
		this.shiftNumber = s;
	}

	public double getPayRate() {
		return this.payRate;
	}

	public double getHoursWorked() {
		return this.hoursWorked;
	}

	public int getShiftNumber() {
		return this.shiftNumber;
	}

	public double getTotalPay() {
		double shiftDifferential = 1;
		if (getShiftNumber() == 1) {
			shiftDifferential = 1;
		} else if (getShiftNumber() == 2) {
			shiftDifferential = 1.5;
		}
		return getPayRate() * shiftDifferential * getHoursWorked();
	}

	@Override // Override the toString method.
	public String toString() {
		return super.toString() + "\n	Shift: " + getShiftNumber() + "\n	Pay Rate: $"
				+ String.format("%,.2f", getPayRate()) + "\n	Hours Worked: "
				+ String.format("%,.2f", getHoursWorked()) + "\n	Total Pay for Period: $"
				+ String.format("%,.2f", getTotalPay());
	}

}
