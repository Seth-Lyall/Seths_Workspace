package sinclair.lyall.seth;

public class Asset {
	// Instance Variable(s)
	private String assetName;
	private double assetCost;
	private int yearPurchased;
	
	// Constructor(s)
	public Asset(String n, double c, int yp) {
		setName(n);
		setCost(c);
		setYearPurchased(yp);
	}
	
	// Mutator(s) and Accessor(s)
	public String getName() {
		return this.assetName;
	}
	public void setName(String n) {
		this.assetName = n;
	}
	public double getCost() {
		return this.assetCost;
	}
	public void setCost(double c) {
		this.assetCost = c;
	}
	public int getYearPurchased() {
		return this.yearPurchased;
	}
	public void setYearPurchased(int yp) {
		this.yearPurchased = yp;
	}
	public double amortizedCost(int currentYear) {
		return assetCost / (currentYear - yearPurchased);
	}
	public double computeValue() {
		return getCost();
	}
	@Override // Override the toString method.
	public String toString() {
		String assetCost = String.format("%.1f", getCost());
		String newString = 	"Name          : " + getName() + "\nCost          : " + assetCost + "\nPurchase Date : " + getYearPurchased();
		return newString;
	}
}
