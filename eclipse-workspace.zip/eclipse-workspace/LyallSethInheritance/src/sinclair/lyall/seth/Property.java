package sinclair.lyall.seth;

public class Property extends Asset {
	// Instance Variable(s)
	private double assessedValue;
	
	// Constructor(s)
	public Property(String n, double c, int yp, double av) {
		super(n, c, yp);
		setAssessedValue(av);
	}
			
	// Mutator(s) and Accessor(s)
	public double getAssessedValue() {
		return this.assessedValue;
	}
	public void setAssessedValue(double av) {
		this.assessedValue = av;
	}
	@Override // Override the computeValue method.
	public double computeValue() {
		return getAssessedValue();
	}
	@Override // Override the toString method.
	public String toString() {
		String newString = super.toString() + "\nAssessment    : " + getAssessedValue();
		return newString;
	}
}
