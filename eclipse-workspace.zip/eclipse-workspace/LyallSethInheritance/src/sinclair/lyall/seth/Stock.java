package sinclair.lyall.seth;

public class Stock extends Asset {
	// Instance Variable(s)
	private String tickerSymbol;
	private int sharesOwned;
	private double stockPrice;
	
	// Constructor(s)
	public Stock(String n, double c, int yp, String ts, int so, double p) {
		super(n, c, yp);
		setTickerSymbol(ts);
		setSharesOwned(so);
		setPrice(p);
	}
		
	// Mutator(s) and Accessor(s)
	public String getTickerSymbol() {
		return this.tickerSymbol;
	}
	public void setTickerSymbol(String ts) {
		this.tickerSymbol = ts;
	}
	public int getSharesOwned() {
		return this.sharesOwned;
	}
	public void setSharesOwned(int so) {
		this.sharesOwned = so;
	}
	public double getPrice() {
		return this.stockPrice;
	}
	public void setPrice(double p) {
		this.stockPrice = p;
	}
	@Override // Override the computeValue method.
	public double computeValue() {
		return getSharesOwned() * getPrice();
	}
	@Override // Override the toString method.
	public String toString() {
		String stockPrice =  String.format("%.1f", getPrice());
		String newString = super.toString() + "\nSymbol        : " + getTickerSymbol() + "\nShares        : " + getSharesOwned() + "\nPrice         : " + stockPrice;
		return newString;
	}
}
