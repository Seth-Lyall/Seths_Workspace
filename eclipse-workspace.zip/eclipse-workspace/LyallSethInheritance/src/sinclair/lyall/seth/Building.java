package sinclair.lyall.seth;

public class Building extends Property {
	// Instance Variable(s)
	private String address;
	
	// Constructor(s)
	public Building(String n, double c, int yp, double av, String a) {
		super(n, c, yp, av);
		setAddress(a);
	}
			
	// Mutator(s) and Accessor(s)
	public String getAddress() {
		return this.address;
	}
	public void setAddress(String a) {
		this.address = a;
	}
	@Override // Override the toString method.
	public String toString() {
		String newString = super.toString() + "\nAddress       : " + getAddress();
		return newString;
	}
}
