/**
 * Seth Lyall - MVCTC
 * Nov 14, 2022
 */
package chap16JavaFXUI;

import java.util.InputMismatchException;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class TaxCalculatorTest extends Application {
	private RadioButton singleBtn = new RadioButton("Single Filers");
	private RadioButton marriedJointBtn = new RadioButton("Married filing jointly or qualifying widow(er)");
	private RadioButton marriedSeparatelyBtn = new RadioButton("Married filing seperately");
	private RadioButton headOfHouseholdBtn = new RadioButton("Head of Household");
	private ToggleGroup group = new ToggleGroup();
	private TextField taxableIncomeTextField = new TextField();
	private TextField taxTextField = new TextField();
	private Button computeTax = new Button("Compute Tax");
	private VBox centerPane = new VBox();
	private VBox rightPane = new VBox();
	private VBox bottomPane = new VBox();
	private Label ratesRow1 = new Label();
	private Label ratesRow2 = new Label();
	private Label ratesRow3 = new Label();
	private Label ratesRow4 = new Label();
	private Label ratesRow5 = new Label();
	private Label ratesRow6 = new Label();
	private Label ratesRow7 = new Label();
	private Label ratesRow8 = new Label();

	@Override // Override the start method in the Application class.
	public void start(Stage primaryStage) {
		// Set the content display and padding for the buttons and set the buttons in
		// the group.
		singleBtn.setContentDisplay(ContentDisplay.LEFT);
		singleBtn.setPadding(new Insets(5, 5, 5, 5));
		marriedJointBtn.setContentDisplay(ContentDisplay.LEFT);
		marriedJointBtn.setPadding(new Insets(5, 5, 5, 5));
		marriedSeparatelyBtn.setContentDisplay(ContentDisplay.LEFT);
		marriedSeparatelyBtn.setPadding(new Insets(5, 5, 5, 5));
		headOfHouseholdBtn.setContentDisplay(ContentDisplay.LEFT);
		headOfHouseholdBtn.setPadding(new Insets(5, 5, 5, 5));
		singleBtn.setToggleGroup(group);
		marriedJointBtn.setToggleGroup(group);
		marriedSeparatelyBtn.setToggleGroup(group);
		headOfHouseholdBtn.setToggleGroup(group);

		// Set the filing info based on which button is selected.
		singleBtn.setOnAction(e -> setFilingInfo());
		marriedJointBtn.setOnAction(e -> setFilingInfo());
		marriedSeparatelyBtn.setOnAction(e -> setFilingInfo());
		headOfHouseholdBtn.setOnAction(e -> setFilingInfo());

		// Set the default text for the filing info.
		ratesRow1.setText("No filing status selected.");
		ratesRow2.setText("");
		ratesRow3.setText("");
		ratesRow4.setText("");
		ratesRow5.setText("");
		ratesRow6.setText("");
		ratesRow7.setText("");
		ratesRow8.setText("");

		// Create a grid pane for holding the taxable income and tax text fields.
		GridPane gridPane = new GridPane();
		gridPane.setAlignment(Pos.CENTER);
		gridPane.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
		gridPane.setHgap(5.5);
		gridPane.setVgap(5.5);

		// Set the preferred width and padding for the compute tax button, the taxable
		// income text field, and the tax text field. Set the tax text field's
		// properties.
		computeTax.setPadding(new Insets(5, 5, 5, 5));
		computeTax.setPrefWidth(90);
		computeTax.setOnAction(e -> computeTax());
		taxableIncomeTextField.setPadding(new Insets(5, 5, 5, 5));
		taxableIncomeTextField.setMaxWidth(120);
		taxTextField.setPadding(new Insets(5, 5, 5, 5));
		taxTextField.setMaxWidth(120);
		taxTextField.setEditable(true);
		taxTextField.setMouseTransparent(true);
		taxTextField.setFocusTraversable(false);

		// Add the taxable income text field, tax text field, and compute tax button to
		// the grid pane.
		gridPane.add(new Label("Taxable Income"), 0, 0);
		gridPane.add(taxableIncomeTextField, 1, 0);
		gridPane.add(new Label("Tax"), 0, 1);
		gridPane.add(taxTextField, 1, 1);
		gridPane.add(computeTax, 1, 2);

		// Add the text "Select Tax Status", along with the single filing button, joint
		// filing button, and separately filing button.
		centerPane.getChildren().addAll(new Label("Select Tax Status"), singleBtn, marriedJointBtn,
				marriedSeparatelyBtn, headOfHouseholdBtn);
		// Add the text that tells the user what each filing status means.
		rightPane.getChildren().addAll(ratesRow1, ratesRow2, ratesRow3, ratesRow4, ratesRow5, ratesRow6, ratesRow7,
				ratesRow8);
		// Add the grid pane for holding the taxable income and tax text labels and the
		// compute tax button.
		bottomPane.getChildren().addAll(gridPane);

		// Create a border pane for housing each of the panes, and set its padding.
		BorderPane BPane = new BorderPane();
		BPane.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
		BPane.setCenter(centerPane);
		BPane.setRight(rightPane);
		BPane.setBottom(bottomPane);

		// Create the scene and put the border pane in the scene.
		Scene scene = new Scene(BPane, 460, 270);

		// Set the stage title, scene, and show the stage.
		primaryStage.setTitle("Investment Value");
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	private void setFilingInfo() {
		// If else statement for each filing status button. Depending on the button
		// selected, each row of the filing status information pane is set and aligned.
		if (singleBtn.isSelected()) {
			ratesRow1.setText("Single Filers");
			ratesRow2.setText("Taxable Income		Rate");
			ratesRow3.setText("Up to $8,350			10%");
			ratesRow4.setText("$8,351 - $33,950		15%");
			ratesRow5.setText("$33,951 - $82,250		25%");
			ratesRow6.setText("$82,251 - $171,550		28%");
			ratesRow7.setText("$171,551 - $372,950	33%");
			ratesRow8.setText("$372,951 or more		35%");
		} else if (marriedJointBtn.isSelected()) {
			ratesRow1.setText("Married Jointly Filers");
			ratesRow2.setText("Taxable Income		Rate");
			ratesRow3.setText("Up to $16,700			10%");
			ratesRow4.setText("$16,701 - $67,900		15%");
			ratesRow5.setText("$67,901 - $137,050		25%");
			ratesRow6.setText("$137,051 - $208,850	28%");
			ratesRow7.setText("$208,851 - $372,950	33%");
			ratesRow8.setText("$372,951 or more		35%");
		} else if (marriedSeparatelyBtn.isSelected()) {
			ratesRow1.setText("Married Separately Filers");
			ratesRow2.setText("Taxable Income		Rate");
			ratesRow3.setText("Up to $8,350			10%");
			ratesRow4.setText("$8,351 - $33,950		15%");
			ratesRow5.setText("$33,951 - $68,525		25%");
			ratesRow6.setText("$68,525 - $104,425		28%");
			ratesRow7.setText("$104,426 - $186,475	33%");
			ratesRow8.setText("$186,476 or more		35%");
		} else if (headOfHouseholdBtn.isSelected()) {
			ratesRow1.setText("Head of Household Filers");
			ratesRow2.setText("Taxable Income		Rate");
			ratesRow3.setText("Up to $11,950			10%");
			ratesRow4.setText("$11,951 - $45,500		15%");
			ratesRow5.setText("$45,501 - $117,450		25%");
			ratesRow6.setText("$117,451 - $190,200	28%");
			ratesRow7.setText("$190,201 - $372,950	33%");
			ratesRow8.setText("$372,951 or more		35%");
		} else {
			ratesRow1.setText("No filing status selected.");
			ratesRow2.setText("");
			ratesRow3.setText("");
			ratesRow4.setText("");
			ratesRow5.setText("");
			ratesRow6.setText("");
			ratesRow7.setText("");
			ratesRow8.setText("");
		}
	}

	private void computeTax() {
		// Initialize values for holding taxable income and filing status for the
		// investment value class, and add a boolean variable for tracking whether or
		// not exceptions were thrown.
		double taxableIncome = 0.00;
		int filingStatus = 0;
		boolean noExceptions = true;

		// Try to read user input for the taxable income text field and parse it to
		// taxable income. If the number is less than zero, prevent the user from
		// continuing. Checks for InputMismatchException and IllegalArgumentException if
		// taxable income is below zero.
		try {
			taxableIncome = Double.parseDouble(taxableIncomeTextField.getText());
			if (taxableIncome < 0.00)
				throw new IllegalArgumentException("Please enter a positive double for taxable income.");
		} catch (InputMismatchException ex) {
			noExceptions = false;
			System.out.println("Please enter a positive number for taxable income.");
		} catch (IllegalArgumentException ex) {
			noExceptions = false;
			System.out.println("Exception: " + ex.getMessage());
		} finally {
			System.out.println("Taxable Income read successfully.");
		}

		// Try to check which button is selected, and set the filing status accordingly.
		// Checks for InputMismatchException for invalid items and
		// IllegalArgumentException if no filing status is selected.
		try {
			if (singleBtn.isSelected()) {
				filingStatus = 0;
			} else if (marriedJointBtn.isSelected()) {
				filingStatus = 1;
			} else if (marriedSeparatelyBtn.isSelected()) {
				filingStatus = 2;
			} else if (headOfHouseholdBtn.isSelected()) {
				filingStatus = 3;
			} else {
				throw new IllegalArgumentException("Please select a filing status.");
			}
		} catch (InputMismatchException ex) {
			noExceptions = false;
			System.out.println("Exception: Invalid radio buttons pressed.");
		} catch (IllegalArgumentException ex) {
			noExceptions = false;
			System.out.println("Exception: " + ex.getMessage());
		} finally {
			System.out.println("Filing Status read successfully.");
		}

		// If there are no exceptions, create the TaxCalculator class and set the tax
		// text field to the resulting value.
		if (noExceptions) {
			TaxCalculator taxCalculator = new TaxCalculator(taxableIncome, filingStatus);
			taxTextField.setText(String.format("%,10.2f", taxCalculator.getTax()));
		}
	}

	public static void main(String[] args) {
		// Launch the overridden start method.
		launch(args);
	}
}
