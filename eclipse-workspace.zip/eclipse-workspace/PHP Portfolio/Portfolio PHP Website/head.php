<?php 

session_start();

?>

<head>
<meta charset="ISO-8859-1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="SethStyle.css">
<title>Seth Lyall's Portfolio</title>
</head>