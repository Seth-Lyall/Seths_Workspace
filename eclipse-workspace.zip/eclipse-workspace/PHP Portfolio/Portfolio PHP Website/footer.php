<footer>

<?php
include "hitCounter.php";
?>

<?php
include "displayUser.php";
?>

<br>
Seth Lyall | 2021 | lyall52354@mvctc.com
<br>
Alternative Email: lyalls2004@gmail.com

</footer>