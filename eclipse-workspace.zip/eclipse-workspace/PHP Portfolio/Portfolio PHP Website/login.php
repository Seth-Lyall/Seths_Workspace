<?php
//error_reporting(E_ALL); ini_set('display_errors', '1');

require ("dbconn.php");
include ("head.php");
include ("nav.php");

if (isset($_POST['username'])){ // If these variables have values, continue, otherwise display the form.
    
    $username=$_POST['username'];
    $password=md5($_POST['password']);
    
    $sql = "SELECT COUNT(email) FROM registration WHERE username = ? AND password = ?";
    $query = $con->prepare($sql);
    $query->bind_param('ss', $username, $password);
    $query->execute();
    $query->store_result();
    $query->bind_result($result);
    $query->fetch();
    // Run a query to see if the inputted username or password is correct.

    if ($result == 1) { // Check if the query returned any results.
       
       $sql = "SELECT email, username FROM registration WHERE username = ? AND password = ?";
       $query = $con->prepare($sql);
       $query->bind_param('ss', $username, $password);
       $query->execute();
       $query->bind_result($sessionEmail, $sessionUsername);
       $query->fetch();
       
       $_SESSION["sessionEmail"] = $sessionEmail;
       $_SESSION["sessionUsername"] = $sessionUsername;
       $_SESSION["loggedIn"] = true;
       
       echo '<h3>You have successfully logged in, you will be redirected shortly.</h3>';
       header("Refresh: 3; url=discussionBoard.php");
       
    }
    else {
        
        echo '<h3>Sorry, your username or password was not found.</h3>';
        header("Refresh: 3; url=login.php");
        
    }
}
else {
    
    echo '
    
    <!DOCTYPE html>
    <html>
    <head>
    <title>Login</title>
    </head>
    <body>
    
    <form method="POST" action="login.php">
    <h2>Login</h2>
    
    <h3>
       <p>
            <label for="username"><tt>Username</label>
            <br />
            <input type="text" name="username">
       </p>
       <p>
            <label for="password"><tt>Password</label>
            <br />
            <input type="password" name="password">
       </p>
    
            <br />
            <input type="submit">
            <input type="reset">
    </h3>
    
    ';

}

?>

<?php 
include "footer.php";
?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
