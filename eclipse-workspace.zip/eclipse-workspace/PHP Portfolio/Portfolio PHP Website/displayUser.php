<?php

require ('dbconn.php');

if (isset($_SESSION['visited'])){
    
    if ($_SESSION["sessionUsername"]) {
        echo ' | Logged in as ' . $_SESSION["sessionUsername"];
    }
    
}

$con->close();

?>

<?php

/*
    $query = "SELECT username FROM registration ORDER BY email DESC LIMIT 1";
    // Query that gets the first record.
    $sql = "SELECT username FROM registration WHERE email = " . $_SESSION["sessionEmail"] . " ORDER BY email DESC LIMIT 1";
    // Query that gets a record from an email gathered from a session variable "sessionEmail".
    
    // Gets output from a select query.
    if ($result = $con->query($sql)){
        $row = $result->fetch_assoc();
        $username = $row['username'];
        echo ' | Logged in as ' . $username;
    
    }
    */
    
    /*
     $sql = "SELECT ... FROM ... WHERE ... = " . $... . " AND ... = " . $...;
     if ($result = $conn->query($sql)) {
     while ($row = $result->fetch_assoc()) {
     .....
     }
     }
*/

?>