<?php
$username="students";
$password="studentPass0";
$database="astudent";

$con=new mysqli ("localhost", $username,$password,$database);

if($con->connect_error){
    echo "Failed to conect to database: (" . $con->connect_error . ") ". $con->connect_error;
}
?>