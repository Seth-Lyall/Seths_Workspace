/**
 * Seth Lyall - MVCTC
 * Dec 8, 2022
 */
package LyallSethFinal;

public class Attendance extends Employee {
	// Member(s)
	private boolean present;
	private String date;
	
	// Constructor(s)
	public Attendance() {
		super();
		setPresence(false);
		setDate(new java.util.Date().toString());
	}
	public Attendance(String n, String a, boolean p) {
		super(n, a);
		setPresence(p);
		setDate(new java.util.Date().toString());
	}
	public Attendance(String n, String a, boolean p, String d) {
		super(n, a);
		setPresence(p);
		setDate(d);
	}
	
	// Setter(s) and Getter(s)
	public void setPresence(boolean p) {
		this.present = p;
	}
	
	public void setDate() {
		this.date = new java.util.Date().toString();
	}
	
	public void setDate(String d) {
		this.date = d;
	}
	
	public boolean getPresence() {
		return this.present;
	}
	
	public String getDate(){
		return this.date;
	}
	
	@Override // Override the toString method.
	public String toString() {
		String presence = "";
		if (getPresence() == true) {
			presence = "Present";
		}
		else if (getPresence() == false) {
			presence = "Absent";
		}
		return super.toString() + "\n	Presence: " + presence + "\n	Date: " + getDate() + "\n";
	}
}
