/**
 * Seth Lyall - MVCTC
 * Dec 8, 2022
 */
package LyallSethFinal;

public class Employee {
	// Member(s)
	private String name;
	private String address;
	
	// Constructor(s)
	public Employee(){
		setName("");
		setAddress("");
	}
	public Employee(String n, String a) {
		setName(n);
		setAddress(a);
	}
	
	// Setter(s) and Getter(s)
	public void setName(String n) {
		this.name = n;
	}
	
	public void setAddress(String a) {
		this.address = a;
	}
	
	public String getName() {
		return this.name;
	}
	
	public String getAddress() {
		return this.address;
	}
	
	@Override // Override the toString method.
	public String toString() {
		return getName() + "\n	Address: " + getAddress();
	}
}
