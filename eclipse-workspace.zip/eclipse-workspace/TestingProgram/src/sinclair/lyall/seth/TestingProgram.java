/**
 * Seth Lyall - MVCTC
 * Aug 19, 2022
 */
package sinclair.lyall.seth;

import java.util.ArrayList;
import java.util.List;

public class TestingProgram {

	public static void main(String[] args) {
		List<Integer> list = new ArrayList<Integer>();
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		list.add(5);
		
		long startTime = System.currentTimeMillis();
		list.contains(4);
		long endTime = System.currentTimeMillis();
		long passedTime = (endTime - startTime);
		System.out.println("Total time passed for list.contains(4): " + passedTime);
		
		startTime = System.currentTimeMillis();
		list.contains(2);
		endTime = System.currentTimeMillis();
		passedTime = (endTime - startTime);
		System.out.println("Total time passed for list.contains(2): " + passedTime);
		
		System.out.println(System.currentTimeMillis());
	}
}
