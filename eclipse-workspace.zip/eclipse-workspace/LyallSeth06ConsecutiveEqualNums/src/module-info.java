/**
 * Seth Lyall - MVCTC Sep 27, 2022
 */

module LyallSeth06ConsecutiveEqualNums {
}