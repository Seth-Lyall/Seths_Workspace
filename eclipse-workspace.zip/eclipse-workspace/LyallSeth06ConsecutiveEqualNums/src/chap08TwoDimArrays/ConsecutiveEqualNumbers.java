/**
 * Seth Lyall - MVCTC
 * Sep 13, 2022
 */
package chap08TwoDimArrays;

import java.util.Scanner;

public class ConsecutiveEqualNumbers {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		final int ROWS = 6;
		final int COLUMNS = 7;
		int table[][] = { { 0, 0, 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0, 0, 0 },
				{ 0, 0, 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0, 0, 0 } };

		// Receive user input for all of the spaces in the table.
		for (int i = 0; i < ROWS; i++) {
			for (int j = 0; j < COLUMNS; j++) {
				System.out.print("Please enter the data for row " + (i + 1) + " and column " + (j + 1) + ": ");
				table[i][j] = input.nextInt();
			}
		}

		// Display the table the user entered.
		System.out.println("Here is your table: ");
		for (int i = 0; i < ROWS; i++) {
			System.out.println("");
			for (int j = 0; j < COLUMNS; j++) {
				System.out.print(table[i][j] + "  ");
			}
		}

		// Skip two lines, then state whether or not the table has four consecutive
		// equal numbers straight, vertically, or diagonally.
		System.out.println("");
		System.out.println("");
		isConsecutiveFour(table);
		input.close();
	}

	public static boolean isConsecutiveFour(int[][] values) {
		boolean isConsecutive = false;
		int n = 0;
		int fourthBack = 0;
		int thirdBack = 0;
		int secondBack = 0;
		int currentNum = 0;
		final int ROWS = 6;
		final int COLUMNS = 7;

		// Horizontal equality check.
		for (int i = 0; i < ROWS; i++) {
			for (int j = 3; j < COLUMNS; j++) {
				fourthBack = values[i][j - 3];
				thirdBack = values[i][j - 2];
				secondBack = values[i][j - 1];
				currentNum = values[i][j];
				if (fourthBack == currentNum && thirdBack == currentNum && secondBack == currentNum) {
					isConsecutive = true;
					n = currentNum;
				}
			}
		}

		// Vertical equality check.
		for (int i = 0; i < ROWS; i++) {
			for (int j = 0; j < 3; j++) {
				fourthBack = values[j][i];
				thirdBack = values[j + 1][i];
				secondBack = values[j + 2][i];
				currentNum = values[j + 3][i];
				if (fourthBack == currentNum && thirdBack == currentNum && secondBack == currentNum) {
					isConsecutive = true;
					n = currentNum;
				}
			}
		}

		// Diagonally up equality check.
		for (int i = ROWS - 1; i > ROWS - 3; i--) {
			for (int j = 0; j < 3; j++) {
				fourthBack = values[i][j];
				thirdBack = values[i - 1][j + 1];
				secondBack = values[i - 2][j + 2];
				currentNum = values[i - 3][j + 3];
				if (fourthBack == currentNum && thirdBack == currentNum && secondBack == currentNum) {
					isConsecutive = true;
					n = currentNum;
				}
			}
		}

		// Diagonally down equality check.
		for (int i = 0; i < 2; i++) {
			for (int j = 0; j < 3; j++) {
				fourthBack = values[j][i];
				thirdBack = values[j + 1][i + 1];
				secondBack = values[j + 2][i + 2];
				currentNum = values[j + 3][i + 3];
				if (fourthBack == currentNum && thirdBack == currentNum && secondBack == currentNum) {
					isConsecutive = true;
					n = currentNum;
				}
			}
		}

		// Display whether or not there were four occurrences and return it.
		if (isConsecutive) {
			System.out.println("Found four consecutive occurrences of " + n + ".");
		} else {
			System.out.println("Did not find four consecutive occurrences.");
		}
		return isConsecutive;
	}

}
