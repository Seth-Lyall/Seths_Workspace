/**
 * Seth Lyall - MVCTC
 * Sep 15, 2022
 */
package sinclair.lyall.seth;

public class LoopPatterns {

	public static void main(String[] args) {
		final int rows = 7;

		System.out.println("1.");
		System.out.println("");

		for (int i = 1; i <= rows; i++) {
			for (int j = 1; j <= i; j++) {
				System.out.print(j + " ");
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("2.");
		System.out.println("");

		for (int i = rows; i >= 1; i--) {
			for (int j = 1; j <= i; j++) {
				System.out.print(j + " ");
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("3.");
		System.out.println("");

		for (int i = 1; i <= rows; i++) {
			for (int j = 1; j <= i; j++) {
				System.out.print(i + " ");
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("4.");
		System.out.println("");

		for (int i = rows; i >= 1; i--) {
			for (int j = 1; j <= i; j++) {
				System.out.print(i + " ");
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("5.");
		System.out.println("");

		for (int i = rows; i >= 1; i--) {
			for (int j = rows; j >= i; j--) {
				System.out.print(j + " ");
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("6.");
		System.out.println("");

		for (int i = 1; i <= rows; i++) {
			for (int j = rows; j >= i; j--) {
				System.out.print(j + " ");
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("7.");
		System.out.println("");

		for (int i = 1; i <= rows; i++) {
			for (int j = i; j >= 1; j--) {
				System.out.print(j + " ");
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("8.");
		System.out.println("");

		for (int i = rows; i >= 1; i--) {
			for (int j = i; j >= 1; j--) {
				System.out.print(j + " ");
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("9.");
		System.out.println("");

		for (int i = 1; i <= rows; i++) {
			for (int j = 1; j <= i; j++) {
				System.out.print(j + " ");
			}
			System.out.println("");
		}
		// Printing lower half of the pattern
		for (int i = rows - 1; i >= 1; i--) {
			for (int j = 1; j <= i; j++) {
				System.out.print(j + " ");
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("10.");
		System.out.println("");

		for (int i = rows; i >= 1; i--) {
			for (int j = 1; j <= i; j++) {
				System.out.print(j + " ");
			}
			System.out.println("");
		}
		// Printing lower half of the pattern
		for (int i = 2; i <= rows; i++) {
			for (int j = 1; j <= i; j++) {
				System.out.print(j + " ");
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("11.");
		System.out.println("");

		for (int i = 1; i <= rows; i++) {
			// Printing first half of the row
			for (int j = 1; j <= i; j++) {
				System.out.print(j + " ");
			}
			// Printing second half of the row
			for (int j = i - 1; j >= 1; j--) {
				System.out.print(j + " ");
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("12.");
		System.out.println("");

		for (int i = 1; i <= rows; i++) {
			// Printing spaces at the beginning of each row
			for (int j = 2 * rows - i; j > i; j--) {
				System.out.print(" ");
			}
			// Printing 1 to i value at the end of each row
			for (int j = 1; j <= i; j++) {
				System.out.print(j + " ");
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("13.");
		System.out.println("");

		for (int i = rows; i >= 1; i--) {
			// Printing spaces at the beginning of each row
			for (int j = 2 * rows - i; j > i; j--) {
				System.out.print(" ");
			}
			// Printing 1 to i value at the end of each row
			for (int j = 1; j <= i; j++) {
				System.out.print(j + " ");
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("14.");
		System.out.println("");

		for (int i = 1; i <= rows; i++) {
			// Printing spaces at the beginning of each row
			for (int j = 2 * rows - i; j > i; j--) {
				System.out.print(" ");
			}
			// Printing 1 to i value at the end of each row
			for (int j = i; j >= 1; j--) {
				System.out.print(j + " ");
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("15.");
		System.out.println("");

		for (int i = rows; i >= 1; i--) {
			// Printing spaces at the beginning of each row
			for (int j = 2 * rows - i; j > i; j--) {
				System.out.print(" ");
			}
			// Printing i to 1 value at the end of each row
			for (int j = i; j >= 1; j--) {
				System.out.print(j + " ");
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("16.");
		System.out.println("");

		for (int i = 1; i <= rows; i++) {
			// Printing i spaces at the beginning of each row
			for (int j = 1; j < i; j++) {
				System.out.print(" ");
			}
			// Printing i to rows value at the end of each row
			for (int j = i; j <= rows; j++) {
				System.out.print(j + " ");
			}
			System.out.println("");
		}
		// Printing lower half of the pattern
		for (int i = rows - 1; i >= 1; i--) {
			// Printing i spaces at the beginning of each row
			for (int j = 1; j < i; j++) {
				System.out.print(" ");
			}
			// Printing i to rows value at the end of each row
			for (int j = i; j <= rows; j++) {
				System.out.print(j + " ");
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("17.");
		System.out.println("");

		for (int i = 1; i <= rows; i++) {
			// Printing rows-i spaces at the beginning of each row
			for (int j = 1; j <= rows - i; j++) {
				System.out.print(" ");
			}
			// Printing 1 to i value at the end of each row
			for (int j = 1; j <= i; j++) {
				System.out.print(j + " ");
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("18.");
		System.out.println("");

		for (int i = 1; i <= rows; i++) {
			// Printing rows-i spaces at the beginning of each row
			for (int j = 1; j <= rows - i; j++) {
				System.out.print(" ");
			}
			// Printing i to 2*i value at the end of each row
			for (int j = i; j < 2 * i; j++) {
				System.out.print(j + " ");
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("19.");
		System.out.println("");

		for (int i = 1; i <= rows; i++) {
			// Printing rows-i spaces at the beginning of each row
			for (int j = 1; j <= rows - i; j++) {
				System.out.print(" ");
			}
			// Printing i value i times at the end of each row
			for (int j = 1; j <= i; j++) {
				System.out.print(i + " ");
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("20.");
		System.out.println("");

		for (int i = rows; i >= 1; i--) {
			// Printing rows-i spaces at the beginning of each row
			for (int j = 1; j <= rows - i; j++) {
				System.out.print(" ");
			}
			// Printing i value i times at the end of each row
			for (int j = 1; j <= i; j++) {
				System.out.print(i + " ");
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("21.");
		System.out.println("");

		for (int i = rows; i >= 1; i--) {
			// Printing i spaces at the beginning of each row
			for (int j = 1; j < i; j++) {
				System.out.print(" ");
			}
			// Printing i to rows value at the end of each row
			for (int j = i; j <= rows; j++) {
				System.out.print(j + " ");
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("22.");
		System.out.println("");

		for (int i = 1; i <= rows; i++) {
			// Printing i spaces at the beginning of each row
			for (int j = 1; j < i; j++) {
				System.out.print(" ");
			}
			// Printing i to rows value at the end of each row
			for (int j = i; j <= rows; j++) {
				System.out.print(j + " ");
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("23.");
		System.out.println("");

		for (int i = rows; i >= 1; i--) {
			// Printing i spaces at the beginning of each row
			for (int j = 1; j < i; j++) {
				System.out.print(" ");
			}
			// Printing rows to i value at the end of each row
			for (int j = rows; j >= i; j--) {
				System.out.print(j + " ");
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("24.");
		System.out.println("");

		for (int i = 1; i <= rows; i++) {
			// Printing i spaces at the beginning of each row
			for (int j = 1; j < i; j++) {
				System.out.print(" ");
			}
			// Printing rows to i value at the end of each row
			for (int j = rows; j >= i; j--) {
				System.out.print(j + " ");
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("25.");
		System.out.println("");

		for (int i = 1; i <= rows; i++) {
			// Printing i spaces at the beginning of each row
			for (int j = 1; j < i; j++) {
				System.out.print(" ");
			}
			// Printing i to rows value at the end of each row
			for (int j = i; j <= rows; j++) {
				System.out.print(j + " ");
			}
			System.out.println("");
		}
		// Printing lower half of the pattern
		for (int i = rows - 1; i >= 1; i--) {
			// Printing i spaces at the beginning of each row
			for (int j = 1; j < i; j++) {
				System.out.print(" ");
			}
			// Printing i to rows value at the end of each row
			for (int j = i; j <= rows; j++) {
				System.out.print(j + " ");
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("26.");
		System.out.println("");

		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < rows; j++) {
				if (i == j) {
					System.out.print(i);
				} else {
					System.out.print("0");
				}
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("27.");
		System.out.println("");

		for (int i = 1; i <= rows; i++) {
			int num = i;
			for (int j = 1; j <= i; j++) {
				System.out.print(num + " ");
				num = num + rows - j;
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("28.");
		System.out.println("");

		int num = 0;
		for (int i = 1; i <= rows; i++) {
			if (i % 2 == 0) {
				int value = num + i - 1;

				for (int j = 1; j <= i; j++) {
					System.out.print(value + " ");

					value--;

					num++;
				}
			} else {
				for (int j = 1; j <= i; j++) {
					System.out.print(num + " ");

					num++;
				}
			}

			System.out.println("");
		}

		System.out.println("");
		System.out.println("29.");
		System.out.println("");

		for (int i = 1; i <= rows; i++) {
			for (int j = 1; j <= 2 * i - 1; j++) {
				if (i == j) {
					System.out.print(i);
				} else {
					System.out.print("*");
				}
			}
			System.out.println("");
		}

		System.out.println("");
		System.out.println("30.");
		System.out.println("");

		char ch = 'A';

		for (int i = 1; i <= rows; i++) {
			for (int j = 1; j <= i; j++) {
				System.out.print(j);
			}

			for (int j = i + 1; j <= rows; j++) {
				System.out.print(ch);
			}

			ch++;

			System.out.println("");
		}

	}
}
