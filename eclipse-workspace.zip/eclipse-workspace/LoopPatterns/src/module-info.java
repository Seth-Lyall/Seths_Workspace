/**
 * Seth Lyall - MVCTC Sep 15, 2022
 */

module LoopPatterns {
}