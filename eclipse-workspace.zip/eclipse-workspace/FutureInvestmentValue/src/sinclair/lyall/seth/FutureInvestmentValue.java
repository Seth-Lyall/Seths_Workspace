/**
 * Seth Lyall - MVCTC
 * Aug 24, 2022
 */
package sinclair.lyall.seth;

import java.util.Scanner;

public class FutureInvestmentValue {

	public static void main(String[] args) {
		double accumulatedValue = 0.00;
		double investmentAmount = 0.00;
		double interestRate = 0.00;
		int numberOfYears = 0;
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the investment amount: ");
		investmentAmount = input.nextDouble();
		System.out.print("Enter the annual interest rate: ");
		interestRate = input.nextDouble();
		System.out.print("Enter the number of years: ");
		numberOfYears = input.nextInt();
		accumulatedValue = (investmentAmount
				* Math.pow((1.0 + ((interestRate / 12.0) / 100.0)), (numberOfYears * 12.0)));
		System.out.println("Your accumulated value is: " + accumulatedValue);
		input.close();
	}
}
