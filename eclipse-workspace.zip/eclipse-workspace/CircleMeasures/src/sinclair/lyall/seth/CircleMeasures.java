/**
 * Seth Lyall - MVCTC
 * Aug 23, 2022
 */
package sinclair.lyall.seth;

import java.util.Scanner;

/**
 * @author lyall52354
 *
 */
public class CircleMeasures {

	/**
	 * 
	 */
	public CircleMeasures() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		final double PI = 3.14159265;
		Scanner input = new Scanner(System.in);
		System.out.println("Please enter the radius of your circle.");
		double radius = input.nextDouble();
		double circumference = 2 * PI * radius;
		double area = Math.pow((PI * radius), 2);
		System.out.println("The circumference of your circle is " + circumference);
		System.out.println("The area of your circle is " + area);
		input.close();
	}

}
