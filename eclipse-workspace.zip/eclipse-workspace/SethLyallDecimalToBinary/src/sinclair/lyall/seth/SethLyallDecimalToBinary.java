package sinclair.lyall.seth;

import java.util.Scanner;

public class SethLyallDecimalToBinary {

	public static void main(String[] args) {
		int decimalNumber = 0;
		String binaryNumber = "0";
		Scanner input = new Scanner(System.in);

		System.out.print("Enter a decimal number: ");
		decimalNumber = input.nextInt();
		binaryNumber = decimalToBinary(decimalNumber);
		System.out.print("The binary number is " + binaryNumber);
		input.close();
	}

	public static String decimalToBinary(int decimalValue) {
		String binaryNumber = "";

		for (int i = 128; i >= 1; i /= 2) {
			if (decimalValue >= i) {
				binaryNumber += "1";
				decimalValue -= i;
			} else {
				binaryNumber += "0";
			}
		}

		return binaryNumber;
	}

}
