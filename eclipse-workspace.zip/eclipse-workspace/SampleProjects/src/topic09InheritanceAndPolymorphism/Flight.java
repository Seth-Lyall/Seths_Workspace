package topic09InheritanceAndPolymorphism;

import java.util.Calendar;

public class Flight {
	 private String flightNo;
	  private Calendar departureTime;
	  private Calendar arrivalTime;
	  
	  public Flight(String flightNo, Calendar departureTime, 
	      Calendar arrivalTime) {
	    this.flightNo = flightNo;
	    this.departureTime = departureTime;
	    this.arrivalTime = arrivalTime;
	  }
	  
	  public int getFlightTime() {
	    return (int)(arrivalTime.getTimeInMillis() - departureTime.getTimeInMillis()) 
	       / (1000 * 60);
	  }
	  
	  public Calendar getDepartureTime() {
	    return departureTime;
	  }

	  public Calendar getArrivalTime() {
	    return arrivalTime;
	  }
	  
	  public void setArrivalTime(Calendar arrivalTime) {
	    this.arrivalTime = arrivalTime;
	  }

	  public void setDepartureTime(Calendar departureTime) {
	    this.departureTime = departureTime;
	  }
}
