package topic09InheritanceAndPolymorphism;

import java.util.List;

public class Itinerary {
	private List<Flight> flights;
	  
	  public Itinerary(List<Flight> flights) {
	    this.flights = flights;
	  }
	  
	  public int getTotalTravelTime() {
	    int totalTime = getTotalFlightTime();
	    for (int i = 0; i < flights.size() - 1; i++) {
	      long time = flights.get(i + 1).getDepartureTime().getTimeInMillis() -
	        flights.get(i).getArrivalTime().getTimeInMillis();
	      totalTime += (int)time / (1000 * 60);
	    }
	    return totalTime;
	  }
	  
	  public int getTotalFlightTime() {
	    int flightTime = 0;
	    for (Flight flight: flights)
	      flightTime += flight.getFlightTime();
	    return flightTime;
	  }
}
