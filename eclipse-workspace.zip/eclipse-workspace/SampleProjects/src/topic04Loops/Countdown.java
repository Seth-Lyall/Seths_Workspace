package topic04Loops;
import java.util.Scanner;

public class Countdown {

	public static void main(String[] args) {
	    Scanner input = new Scanner(System.in);
	    System.out.print("Enter a starting number: ");
	    int numberStart = input.nextInt();
	    int numberCurrent = numberStart;
	    while (numberCurrent > 0) {
	      System.out.println(numberCurrent);        
	      numberCurrent -= 1;
	    }
	    System.out.println("Stopped");
	  }
		
}
