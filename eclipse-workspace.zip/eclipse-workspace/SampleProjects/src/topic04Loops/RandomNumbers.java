package topic04Loops;
import java.util.Scanner;

public class RandomNumbers {
	public static void main(String[] args) {
	    double value = Math.random();
	    while (value <= 0.75) {
	      System.out.println(value);
	      value = Math.random();
	    }
	    System.out.println(value);
	  }
}
