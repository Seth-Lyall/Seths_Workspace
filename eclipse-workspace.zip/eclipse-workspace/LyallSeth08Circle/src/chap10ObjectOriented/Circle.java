/**
 * Seth Lyall - MVCTC
 * Oct 18, 2022
 */
package chap10ObjectOriented;

public class Circle {

	// Member(s)
	static final double PI = 3.141592653589793;
	private double x;
	private double y;
	private double radius;

	// Constructor(s)
	Circle() {
		x = 0.00;
		y = 0.00;
		radius = 1.00;
	}

	Circle(double i) {
		x = i;
		y = 0.00;
		radius = 1.00;
	}

	Circle(double i, double j) {
		x = i;
		y = j;
		radius = 1.00;
	}

	Circle(double i, double j, double k) {
		x = i;
		y = j;
		radius = k;
	}

	// Getter(s)
	double getX() {
		return x;
	}

	double getY() {
		return y;
	}

	double getRadius() {
		return radius;
	}

	double getArea() {
		double area = 0.00;

		area = PI * Math.pow((getRadius()), 2.00);

		return area;
	}

	double getPerimeter() {
		double perimeter = 0.00;

		perimeter = 2.00 * PI * getRadius();

		return perimeter;
	}

	boolean contains(double i, double j) {
		boolean contains;

		if (Math.sqrt(Math.pow((i - getX()), 2.00) + Math.pow((j - getY()), 2.00)) < radius) {
			contains = true;
		} else {
			contains = false;
		}

		return contains;
	}

	boolean contains(Circle circle) {
		boolean contains = false;

		if (Math.sqrt(Math.pow((circle.getX() - getX()), 2.00) + Math.pow((circle.getY() - getY()), 2.00))
				+ (circle.getRadius() / 2.00) < (getRadius() / 2.00)) {
			contains = true;
		} else {
			contains = false;
		}

		return contains;
	}

	boolean overlaps(Circle circle) {
		boolean overlaps = false;

		if (Math.sqrt(Math.pow((circle.getX() - getX()), 2.00)
				+ Math.pow((circle.getY() - getY()), 2.00)) <= (circle.getRadius() / 2.00) + (getRadius() / 2.00)) {
			overlaps = true;
		} else {
			overlaps = false;
		}

		return overlaps;
	}

}
