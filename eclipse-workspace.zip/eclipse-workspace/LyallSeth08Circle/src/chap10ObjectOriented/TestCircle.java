/**
 * Seth Lyall - MVCTC
 * Oct 18, 2022
 */
package chap10ObjectOriented;

public class TestCircle {

	public static void main(String[] args) {
		// Use the Circle (double, double) Constructor from the circle class to create a
		// circle with an x position of 2, a y position of 5.5, and a radius of 1.
		Circle c1 = new Circle(2, 5.5);

		// Use getter functions from the Circle class to display the area and perimeter
		// of c1.
		System.out.print("The area of your circle is ");
		System.out.printf("%.3f", c1.getArea());
		System.out.println("");
		System.out.print("The perimeter of your circle is ");
		System.out.printf("%.3f", c1.getPerimeter());
		System.out.println("");

		// Use the contains (double, double) function from the Circle class and an if
		// statement to display whether or not the specified point is inside of c1.
		System.out.println("");
		System.out.println("Is 'c1.contains(3, 3)' true?");
		if (c1.contains(3, 3)) {
			System.out.println("Your point is contained in c1. (True)");
			System.out.println("");
		} else {
			System.out.println("Your point is not contained in c1. (False)");
			System.out.println("");
		}

		// Use the contains (Circle) function from the Circle class and an if statement
		// to display whether or not the specified circle is inside of c1.
		System.out.println("Is 'c1.contains(new Circle(4, 5, 10.5))' true?");
		if (c1.contains(new Circle(4, 5, 10.5))) {
			System.out.println("Your new circle is contained in c1. (True)");
			System.out.println("");
		} else {
			System.out.println("Your new circle is not contained in c1. (False)");
			System.out.println("");
		}

		// Use the overlaps (Circle) function from the Circle class and an if statement
		// to display whether or not the specified circle is inside of c1.
		System.out.println("Is 'c1.overlaps(new Circle(3, 5, 2.3))' true?");
		if (c1.overlaps(new Circle(3, 5, 2.3))) {
			System.out.println("Your new circle overlaps c1. (True)");
		} else {
			System.out.println("Your new circle doesn't overlap in c1. (False)");
		}
	}
}
