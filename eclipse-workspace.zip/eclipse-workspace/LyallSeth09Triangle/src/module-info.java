/**
 * Seth Lyall - MVCTC
 * Oct 25, 2022
 */
/**
 * @author lyall52354
 *
 */
module LyallSeth09Triangle {
}