/**
 * Seth Lyall - MVCTC
 * Oct 25, 2022
 */
package chap11InheritancePolymorphism;

import java.util.Date;

public class GeometricObject {
	// Member(s)
	private String color;
	private Boolean filled;
	private Date dateCreated;

	// Constructor(s)
	public GeometricObject() {
		this.color = "white";
		this.filled = false;
		this.dateCreated = new Date();
	}

	public GeometricObject(String c, Boolean f) {
		this.color = c;
		this.filled = f;
		this.dateCreated = new Date();
	}

	// Getter(s)
	public String getColor() {
		return this.color;
	}

	public Boolean isFilled() {
		return this.filled;
	}

	public Date getDateCreated() {
		return this.dateCreated;
	}

	@Override
	public String toString() {
		return "This object was created on " + getDateCreated() + ". Filled is " + isFilled() + ". The color is "
				+ getColor() + ".";
	}

	// Setter(s)
	public void setColor(String c) {
		this.color = c;
	}

	public void setFilled(Boolean f) {
		this.filled = f;
	}
}
