/**
 * Seth Lyall - MVCTC
 * Oct 25, 2022
 */
package chap11InheritancePolymorphism;

public class Triangle extends GeometricObject {
	// Member(s)
	private double side1;
	private double side2;
	private double side3;

	// Constructor(s)
	public Triangle() {
		super();
		this.side1 = 1.0;
		this.side2 = 1.0;
		this.side3 = 1.0;
	}

	public Triangle(String c, Boolean f) {
		super(c, f);
		this.side1 = 1.0;
		this.side2 = 1.0;
		this.side3 = 1.0;
	}

	public Triangle(double s1, double s2, double s3) {
		super();
		this.side1 = s1;
		this.side2 = s2;
		this.side3 = s3;
	}

	public Triangle(String c, Boolean f, double s1, double s2, double s3) {
		super(c, f);
		this.side1 = s1;
		this.side2 = s2;
		this.side3 = s3;
	}

	// Getter(s)
	public double getSide1() {
		return this.side1;
	}

	public double getSide2() {
		return this.side2;
	}

	public double getSide3() {
		return this.side3;
	}

	public double getArea() {
		return Math.sqrt((getPerimeter() / 2) * ((getPerimeter() / 2) - getSide1())
				* ((getPerimeter() / 2) - getSide2()) * ((getPerimeter() / 2) - getSide3()));
	}

	public double getPerimeter() {
		return getSide1() + getSide2() + getSide3();
	}

	@Override
	public String toString() {
		return "Triangle: side1 = " + getSide1() + " side2 = " + getSide2() + " side3 = " + getSide3();
	}

	// Setter(s)
	public void setSide1(double s1) {
		this.side1 = s1;
	}

	public void setSide2(double s2) {
		this.side2 = s2;
	}

	public void setSide3(double s3) {
		this.side3 = s3;
	}
}
