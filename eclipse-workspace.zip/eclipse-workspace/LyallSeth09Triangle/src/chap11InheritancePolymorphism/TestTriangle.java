/**
 * Seth Lyall - MVCTC
 * Oct 25, 2022
 */
package chap11InheritancePolymorphism;

public class TestTriangle {

	public static void main(String[] args) {
		// Creates a triangle class object where color is yellow, filled is true, side1
		// is 1.0, side2 is 1.5, and side3 is 1.0.
		Triangle myTriangle = new Triangle("yellow", true, 1.0, 1.5, 1.0);

		// Displays the area of the triangle.
		System.out.print("The area of your triangle is ");
		System.out.printf("%,.3f", myTriangle.getArea());
		System.out.println("");

		// Displays the perimeter of the triangle.
		System.out.print("The perimeter of your triangle is ");
		System.out.printf("%,.3f", myTriangle.getPerimeter());
		System.out.println("");

		// Displays the color of the triangle.
		System.out.println("The color of your triangle is " + myTriangle.getColor() + ".");

		// Displays whether or not the triangle is filled.
		System.out.println("Filled triangle is " + myTriangle.isFilled() + ".");
	}
}
