/**
 * Seth Lyall - MVCTC
 * Sep 7, 2022
 */
package sinclair.lyall.seth;

import java.util.Scanner;

public class PhoneKeypads {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);

		String letter = "a";
		String binary1 = "0";
		String binary2 = "0";
		String binary3 = "0";
		String binary4 = "0";
		String binaryDigit = "";
		char character = 'a';
		int originalDigit = 0;
		int digit = 0;

		System.out.print("Enter a letter from A to Z: ");
		letter = input.next();
		character = letter.charAt(0);
		if (character >= 97 && character <= 122) {
			character -= 32;
		}

		if (character >= 65 && character <= 67) {
			originalDigit = 2;
		} else if (character >= 68 && character <= 70) {
			originalDigit = 3;
		} else if (character >= 71 && character <= 73) {
			originalDigit = 4;
		} else if (character >= 74 && character <= 76) {
			originalDigit = 5;
		} else if (character >= 77 && character <= 79) {
			originalDigit = 6;
		} else if (character >= 80 && character <= 83) {
			originalDigit = 7;
		} else if (character >= 84 && character <= 86) {
			originalDigit = 8;
		} else {
			originalDigit = 9;
		}

		digit = originalDigit;

		if (digit < 8) {
			binary1 = "0";
		} else {
			binary1 = "1";
			digit -= 8;
		}
		if (digit < 4) {
			binary2 = "0";
		} else {
			binary2 = "1";
			digit -= 4;
		}
		if (digit < 2) {
			binary3 = "0";
		} else {
			binary3 = "1";
			digit -= 2;
		}
		if (digit < 1) {
			binary4 = "0";
		} else {
			binary4 = "1";
			digit -= 1;
		}

		binaryDigit = (binary1 + binary2 + binary3 + binary4);
		System.out.println("Your corresponding digit is " + originalDigit + " or binary 0000" + binaryDigit);

		input.close();
	}

}
