package sinclair.lyall.seth;

import java.util.Scanner;

public class SethLyallBinaryToHex {

	public static void main(String[] args) {
		String binaryNumber = "0";
		String hexNumber = "0";
		Scanner input = new Scanner(System.in);

		System.out.print("Enter a binary number: ");
		binaryNumber = input.next();
		hexNumber = binaryToHex(binaryNumber);
		System.out.print("The hex value is " + hexNumber);

		input.close();
	}

	public static String binaryToHex(String binaryValue) {
		int decimalValue = binaryToDecimal(binaryValue);
		return decimalToHex(decimalValue);
	}

	public static int binaryToDecimal(String binaryString) {
		int value = binaryString.charAt(0) - '0';
		for (int i = 1; i < binaryString.length(); i++) {
			value = value * 2 + binaryString.charAt(i) - '0';
		}

		return value;
	}

	/** Convert a decimal to a hex as a string */
	public static String decimalToHex(int decimal) {
		String hex = "";

		while (decimal != 0) {
			int hexValue = decimal % 16;
			hex = toHexChar(hexValue) + hex;
			decimal = decimal / 16;
		}

		return hex;
	}

	/** Convert an integer to a single hex digit in a character */
	public static char toHexChar(int hexValue) {
		if (hexValue <= 9 && hexValue >= 0)
			return (char) (hexValue + '0');
		else // hexValue <= 15 && hexValue >= 10
			return (char) (hexValue - 10 + 'A');
	}

}
