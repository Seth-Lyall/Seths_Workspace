<?php

	$errors = array('email'=>'', 'username'=>'', 'age'=>'', 'birthday'=>'', 'password'=>'', 'favoriteCandy'=>'');

	if(isset($_POST['submit'])) {

		// Check the email.
			if (empty($_POST['email'])) {
				$errors['email'] = 'An email is required <br />';
			} else {
				$email = $_POST['email'];
				if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
					$errors['email'] = 'Email must be a valid email address';
				}
			}
		// Check the username.
			if (empty($_POST['username'])) {
				$errors['username'] = 'A username is required <br />';
			} else {
				$username = $_POST['username'];
			}
		// Check the age.
			if (empty($_POST['age'])) {
				$errors['age'] = 'An age is required <br />';
			} else {
				$age = $_POST['age'];
			}
		// Check the birthday.
			if (empty($_POST['birthday'])) {
				$errors['birthday'] = 'A birthday is required <br />';
			} else {
				$birthday = $_POST['birthday'];
			}
		// Check the password.
			if (empty($_POST['password'])) {
				$errors['password'] = 'A password is required <br />';
			} else {
				$password = $_POST['password'];
			}
		// Check the favorite candy.
			if (empty($_POST['favoriteCandy'])) {
				$errors['favoriteCandy'] = 'A favorite candy is required <br />';
			} else {
			    $favoriteCandyButtons = $_POST['favoriteCandy'];
				if ($favoriteCandyButtons == 'favoriteCandyChocolate') {
				    $favoriteCandy = 'Chocolate';
				}
				if ($favoriteCandyButtons == 'favoriteCandyGummies') {
				    $favoriteCandy = 'Gummies';
				}
				if ($favoriteCandyButtons == 'favoriteCandyPastries') {
				    $favoriteCandy = 'Pastries';
				}
				if ($favoriteCandyButtons == 'favoriteCandyBakedGoods') {
				    $favoriteCandy = 'Baked Goods';
				}
				if ($favoriteCandyButtons == 'favoriteCandyCaramels') {
				    $favoriteCandy = 'Caramels';
				}
			}
		// Save the favorite ice cream if it was filled out.
			error_reporting(E_ERROR | E_WARNING | E_PARSE);
			if (isset($_POST['favoriteIceCream'])) {
				$favoriteIceCreamBoxes = $_POST['favoriteIceCream'];
				unset($iceCreamBox);
				foreach ($favoriteIceCreamBoxes as $iceCreamBox) {
				    if (isset($iceCreamBox)) {
				        $favoriteIceCreams .= $iceCreamBox;
				        $favoriteIceCreams .= '<br>';
				    }
				}
				unset($iceCreamBox);
			}
		// Save the text area if it was filled out.
			if (!empty($_POST['comments'])) {
			    $textArea = $_POST['comments'];
			}
			
			if (array_filter($errors)) {
			    // The form has errors.
			    
			    echo '<!DOCTYPE html>
                      <html lang="en">
                      <head>
	                  <link rel="stylesheet" href="StyleSheet.css">
                      <meta charset="UTF-8">
                      <meta name="viewport" content="width=device-width, initial-scale=1.0">
                      <meta http-equiv="X-UA-Compatible" content="ie=edge">
                      <title>Candy Form</title>
                      </head>
                      <body>
	                       <form action="index.php" method="POST" enctype="multipart/form-data">
		                      <div>
			                     <label for="email">Email</label>
			                     <input type="email" name="email" id="email"><label> </label><label style = "color: #ff0000;">';
			    
			                     echo $errors['email'] ;
			    
			            echo '</label></input>
		                      </div>
		                      <div>
			                     <label for="username">Username</label>
			                     <input type="text" name="username" id="username"><label> </label><label style = "color: #ff0000;">';
			    
			                     echo $errors['username'];
			    
			            echo '</label></input>
		                      </div>
		                      <div>
			                     <label for="age">Age</label>
			                     <input type="number" name="age" id="age" min="1" max="150" step="1"><label> </label><label style = "color: #ff0000;">';
			    
			                     echo $errors['age'];
			    
			            echo '</label></input>
		                      </div>
		                      <div>
			                     <label for="birthday">Birthday</label>
			                     <input type="date" name="birthday" id="birthday"><label> </label><label style = "color: #ff0000;">';
			    
			                     echo $errors['birthday'];
			    
			            echo '</label></input>
		                      </div>
		                      <div>
			                     <label for="password">Password</label>
			                     <input type="password" name="password" id="password"><label> </label><label style = "color: #ff0000;">';
			    
			                     echo $errors['password'];
			                 
			            echo '</label></input>
		                      </div>
		                      <div>
			                     <br>
		                      </div>
		                      <div>
			                     <label>Favorite Candy (Choose One)<label> </label><label style = "color: #ff0000;">';
			    
			                     echo $errors['favoriteCandy'];
			    
			            echo '</label></label>
		                      </div>
		                      <div>
			                     <input type="radio" id="favoriteCandyChocolate" name="favoriteCandy" value="favoriteCandyChocolate">
			                     <label for="favoriteCandyChocolate">Chocolate</label>
		                      </div>
		                      <div>
			                     <input type="radio" id="favoriteCandyGummies" name="favoriteCandy" value="favoriteCandyGummies">
			                     <label for="favoriteCandyGummies">Gummies</label>
		                      </div>
		                      <div>
			                     <input type="radio" id="favoriteCandyPastries" name="favoriteCandy" value="favoriteCandyPastries">
			                     <label for="favoriteCandyPastries">Pastries</label>
		                      </div>
		                      <div>
			                     <input type="radio" id="favoriteCandyBakedGoods" name="favoriteCandy" value="favoriteCandyBakedGoods">
			                     <label for="favoriteCandyBakedGoods">Baked Goods</label>
		                      </div>
		                      <div>
			                     <input type="radio" id="favoriteCandyCaramels" name="favoriteCandy" value="favoriteCandyCaramels">
			                     <label for="favoriteCandyCaramels">Caramels</label>
		                      </div>
		                      <div>
			                     <br>
		                      </div>';
			    
			            echo '
		                      <div>
			                     <label>Favorite Ice Cream Flavors (Choose As Many As You Want)</label>
		                      </div>
		                      <div>
			                     <input type="checkbox" id="favoriteIceCreamVanilla" name="favoriteIceCream[]" value="Vanilla">
			                     <label for="favoriteIceCreamVanilla">Vanilla</label>
		                      </div>
		                      <div>
			                     <input type="checkbox" id="favoriteIceCreamChocolate" name="favoriteIceCream[]" value="Chocolate">
			                     <label for="favoriteIceCreamChocolate">Chocolate</label>
		                      </div>
		                      <div>
			                     <input type="checkbox" id="favoriteIceCreamStrawberry" name="favoriteIceCream[]" value="Strawberry">
			                     <label for="favoriteIceCreamStrawberry">Strawberry</label>
		                      </div>
		                      <div>
			                     <input type="checkbox" id="favoriteIceCreamCookiesAndCream" name="favoriteIceCream[]" value="Cookies and Cream">
			                     <label for="favoriteIceCreamCookiesAndCream">Cookies and Cream</label>
		                      </div>
		                      <div>
			                     <input type="checkbox" id="favoriteIceCreamMintChocolateChip" name="favoriteIceCream[]" value="Mint Chocolate Chip">
			                     <label for="favoriteIceCreamMintChocolateChip">Mint Chocolate Chip</label>
		                      </div>
		                      <div>
			                     <br>
		                      </div>';
			    
			            echo '
		                      <div>
			                     <label>Anything You Would Like To Add?</label>
		                      </div>
		                      <div>
			                     <textarea id="comments" name="comments"></textArea>
		                      </div>
		                      <div>
			                     <button type="reset">Clear</button>
			                     <button type="submit" id="submit" name="submit">Submit</button>
		                      </div>
	                       </form>
                        </body>
                        </html>';
			} else {
			    // The form is valid.
                
			    echo '<!DOCTYPE html>
                      <html lang="en">
                      <head>
	                  <link rel="stylesheet" href="StyleSheet.css">
	                  <meta charset="UTF-8">
	                  <meta name="viewport" content="width=device-width, initial-scale=1.0">
	                  <meta http-equiv="X-UA-Compatible" content="ie=edge">
	                  <title>Candy Form</title>
                      </head>
                      <body>
                          <form action="index.php" method="POST" enctype="multipart/form-data">
                              <div>
                                  <label>Email: ';
			                      echo $email;
			                      echo '<br></label><label>Username: ';
			                      echo $username;
			                      echo '<br></label><label>Age: ';
			                      echo $age;
			                      echo '<br></label><label>Birthday: ';
			                      echo $birthday;
			                      echo '<br></label><label>Password: ';
			                      echo $password;
			                      echo '<br></label><label>Favorite Candy: ';
			                      echo $favoriteCandy;
			                      echo '<br></label><label>Favorite Ice Cream Flavors:<br>';
			                      echo $favoriteIceCreams;
			                      echo '</label><label>Comments: ';
			                      echo $textArea;
			                      echo '</label>
                              </div>';
			    
		                echo '<div>
                                  <br>
			                      <label>Thank you for your input.</label>
		                      </div>
                              <br>
                              <a href="index.php">Back To The Form</A>
                          </form>
                      </body>
                      </html>';
			}

	} // End of the POST check.

	else {
	    // The form has not been submitted.
	    
	    echo '<!DOCTYPE html>
                      <html lang="en">
                      <head>
	                  <link rel="stylesheet" href="StyleSheet.css">
                      <meta charset="UTF-8">
                      <meta name="viewport" content="width=device-width, initial-scale=1.0">
                      <meta http-equiv="X-UA-Compatible" content="ie=edge">
                      <title>Candy Form</title>
                      </head>
                      <body>
	                       <form action="index.php" method="POST" enctype="multipart/form-data">
		                      <div>
			                     <label for="email">Email</label>
			                     <input type="email" name="email" id="email"><label> </label><label style = "color: #ff0000;">';
	    
	                             echo $errors['email'] ;
	    
	                    echo '</label></input>
		                      </div>
		                      <div>
			                     <label for="username">Username</label>
			                     <input type="text" name="username" id="username"><label> </label><label style = "color: #ff0000;">';
	    
	                             echo $errors['username'];
	    
	                    echo '</label></input>
		                      </div>
		                      <div>
			                     <label for="age">Age</label>
			                     <input type="number" name="age" id="age" min="1" max="150" step="1"><label> </label><label style = "color: #ff0000;">';
	    
	                             echo $errors['age'];
	    
	                    echo '</label></input>
		                      </div>
		                      <div>
			                     <label for="birthday">Birthday</label>
			                     <input type="date" name="birthday" id="birthday"><label> </label><label style = "color: #ff0000;">';
	    
	                             echo $errors['birthday'];
	    
	                    echo '</label></input>
		                      </div>
		                      <div>
			                     <label for="password">Password</label>
			                     <input type="password" name="password" id="password"><label> </label><label style = "color: #ff0000;">';
	    
	                             echo $errors['password'];
	    
	                    echo '</label></input>
		                      </div>
		                      <div>
			                     <br>
		                      </div>
		                      <div>
			                     <label>Favorite Candy (Choose One)<label> </label><label style = "color: #ff0000;">';
	    
	                             echo $errors['favoriteCandy'];
	    
	                    echo '</label></label>
		                      </div>
		                      <div>
			                     <input type="radio" id="favoriteCandyChocolate" name="favoriteCandy" value="favoriteCandyChocolate">
			                     <label for="favoriteCandyChocolate">Chocolate</label>
		                      </div>
		                      <div>
			                     <input type="radio" id="favoriteCandyGummies" name="favoriteCandy" value="favoriteCandyGummies">
			                     <label for="favoriteCandyGummies">Gummies</label>
		                      </div>
		                      <div>
			                     <input type="radio" id="favoriteCandyPastries" name="favoriteCandy" value="favoriteCandyPastries">
			                     <label for="favoriteCandyPastries">Pastries</label>
		                      </div>
		                      <div>
			                     <input type="radio" id="favoriteCandyBakedGoods" name="favoriteCandy" value="favoriteCandyBakedGoods">
			                     <label for="favoriteCandyBakedGoods">Baked Goods</label>
		                      </div>
		                      <div>
			                     <input type="radio" id="favoriteCandyCaramels" name="favoriteCandy" value="favoriteCandyCaramels">
			                     <label for="favoriteCandyCaramels">Caramels</label>
		                      </div>
		                      <div>
			                     <br>
		                      </div>';
	    
	                    echo '
		                      <div>
			                     <label>Favorite Ice Cream Flavors (Choose As Many As You Want)</label>
		                      </div>
		                      <div>
			                     <input type="checkbox" id="favoriteIceCreamVanilla" name="favoriteIceCream[]" value="Vanilla">
			                     <label for="favoriteIceCreamVanilla">Vanilla</label>
		                      </div>
		                      <div>
			                     <input type="checkbox" id="favoriteIceCreamChocolate" name="favoriteIceCream[]" value="Chocolate">
			                     <label for="favoriteIceCreamChocolate">Chocolate</label>
		                      </div>
		                      <div>
			                     <input type="checkbox" id="favoriteIceCreamStrawberry" name="favoriteIceCream[]" value="Strawberry">
			                     <label for="favoriteIceCreamStrawberry">Strawberry</label>
		                      </div>
		                      <div>
			                     <input type="checkbox" id="favoriteIceCreamCookiesAndCream" name="favoriteIceCream[]" value="Cookies and Cream">
			                     <label for="favoriteIceCreamCookiesAndCream">Cookies and Cream</label>
		                      </div>
		                      <div>
			                     <input type="checkbox" id="favoriteIceCreamMintChocolateChip" name="favoriteIceCream[]" value="Mint Chocolate Chip">
			                     <label for="favoriteIceCreamMintChocolateChip">Mint Chocolate Chip</label>
		                      </div>
		                      <div>
			                     <br>
		                      </div>';
	    
	                    echo '
		                      <div>
			                     <label>Anything You Would Like To Add?</label>
		                      </div>
		                      <div>
			                     <textarea id="comments" name="comments"></textArea>
		                      </div>
		                      <div>
			                     <button type="reset">Clear</button>
			                     <button type="submit" id="submit" name="submit">Submit</button>
		                      </div>
	                       </form>
                        </body>
                        </html>';
	}
