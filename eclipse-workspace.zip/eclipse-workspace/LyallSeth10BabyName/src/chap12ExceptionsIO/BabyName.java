/**
 * Seth Lyall - MVCTC
 * Oct 31, 2022
 */
package chap12ExceptionsIO;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class BabyName {

	public static void main(String[] args) {
		// Initialization of the strings for reading the variables from files, and the
		// total number of matching names.
		String file = "null";
		final int records = 1001;
		int total = 0;
		int a = 0;
		int b = 0;
		@SuppressWarnings("unused")
		String placeholder = "null";
		String boyName = "null";
		String girlName = "null";
		ArrayList<String> boyNames = new ArrayList<String>(a);
		ArrayList<String> girlNames = new ArrayList<String>(b);
		Scanner fileName = new Scanner(System.in);

		System.out.print("Please enter the name for the file you want to read from: ");
		file = fileName.next();
		fileName.close();

		// Initialization of file variables and scanners.
		File inFile = new File(file);
		Scanner input;

		// Try to read from babynameranking2021.txt to one array for boy names and one
		// for girls.
		try {
			// Initialization of a PrintWriter for writing the matching names to a new file
			// called matchingNames.txt.
			PrintWriter outFile = new PrintWriter("matchingNames.txt");
			PrintWriter output;
			input = new Scanner(inFile);
			output = new PrintWriter(outFile);

			// While there is more data to be read, read a line from the input file and add
			// the boy and girl names to the array list.
			while (input.hasNext()) {
				placeholder = input.next();
				boyNames.add(input.next());
				placeholder = input.next();
				girlNames.add(input.next());
				placeholder = input.next();
			}
			// Close the input file.
			input.close();

			for (a = 0; a < records; a++) {
				for (b = 0; b < records; b++) {
					// If the boy name is contained in the girl name and vice versa, the names
					// match. Save the matched names to the matchingNames.txt file.
					if (girlNames.get(b).contains(boyNames.get(a))) {
						if (boyNames.get(a) != boyName && girlNames.get(b) != girlName) {
							boyName = boyNames.get(a);
							girlName = girlNames.get(b);
							total++;
							output.println(girlNames.get(b));
						}

					} else if (girlNames.get(b).contains(boyNames.get(a))) {
						if (boyNames.get(a) != boyName && girlNames.get(b) != girlName) {
							boyName = boyNames.get(a);
							girlName = girlNames.get(b);
							total++;
							output.println(boyNames.get(a));
						}
						total++;
						output.println(boyNames.get(a));
					}
				}
			}
			a = 0;
			b = 0;

			// Close the output PrintWriter.
			output.close();
		} catch (FileNotFoundException ex) {
			// If there is a FileNotFoundException, print the following message and data.
			System.out.println("The file was not found.");
			ex.printStackTrace();
		}

		// Initialization for reading matchingNames.txt and a new input for reading the
		// names.
		File inFile1 = new File("matchingNames.txt");
		Scanner input1;

		if (total > 0) {
			// Display which names are used for both genders by reading from the file.
			System.out.println("");
			System.out.println(total + " names are used for both genders.");
			System.out.println("They are:");
			System.out.println("");
			// Try reading from matchingNames.txt for getting matching names and displaying
			// them.
			try {
				input1 = new Scanner(inFile1);

				// While there is data in the file, print it out.
				while (input1.hasNext()) {
					boyName = input1.next();
					System.out.println(boyName);
				}
			} catch (FileNotFoundException ex) {
				// If there is a FileNotFoundException, print the following message and data.
				System.out.println("The file was not found.");
				ex.printStackTrace();
			}
		}
	}
}
