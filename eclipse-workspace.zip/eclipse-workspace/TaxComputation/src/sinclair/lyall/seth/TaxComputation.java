/**
 * Seth Lyall - MVCTC
 * Aug 30, 2022
 */
package sinclair.lyall.seth;

import java.util.Scanner;

public class TaxComputation {

	public static void main(String[] args) {
		int filingStatus = 0;
		double taxableIncome = 0.00;
		double tax = 0.00;
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the filing status: ");
		filingStatus = input.nextInt();
		System.out.print("Enter the taxable income: ");
		taxableIncome = input.nextDouble();
		if (filingStatus == 0) {
			if (taxableIncome >= 0.00 && taxableIncome <= 8350.00) {
				tax += taxableIncome * 0.10;
			} else if (taxableIncome >= 8351.00 && taxableIncome <= 33950.00) {
				tax += (8351.00 * 0.10) + ((taxableIncome - 8351.00) * 0.15);
			} else if (taxableIncome >= 33951.00 && taxableIncome <= 82250.00) {
				tax += (8351.00 * 0.10) + ((33951.00 - 8351.00) * 0.15) + ((taxableIncome - 33951.00) * 0.25);
			} else if (taxableIncome >= 82251.00 && taxableIncome <= 171550.00) {
				tax += (8351.00 * 0.10) + ((33951.00 - 8351.00) * 0.15) + ((82251.00 - 33951.00) * 0.25)
						+ ((taxableIncome - 82251.00) * 0.28);
			} else if (taxableIncome >= 171551.00 && taxableIncome <= 372950.00) {
				tax += (8351.00 * 0.10) + ((33951.00 - 8351.00) * 0.15) + ((82251.00 - 33951.00) * 0.25)
						+ ((171551.00 - 82251.00) * 0.28) + ((taxableIncome - 171551.00) * 0.33);
			} else {
				tax += (8351.00 * 0.10) + ((33951.00 - 8351.00) * 0.15) + ((82251.00 - 33951.00) * 0.25)
						+ ((171551.00 - 82251.00) * 0.28) + ((372951.00 - 171551.00) * 0.33)
						+ ((taxableIncome - 372951.00) * 0.35);
			}
		} else if (filingStatus == 1) {
			if (taxableIncome >= 0.00 && taxableIncome <= 16700.00) {
				tax = taxableIncome * 0.10;
			} else if (taxableIncome >= 16701.00 && taxableIncome <= 67900.00) {
				tax += (16701.00 * 0.10) + ((taxableIncome - 16701.00) * 0.15);
			} else if (taxableIncome >= 67901.00 && taxableIncome <= 137050.00) {
				tax += (16701.00 * 0.10) + ((67901.00 - 16701.00) * 0.15) + ((taxableIncome - 67901.00) * 0.25);
			} else if (taxableIncome >= 137051.00 && taxableIncome <= 208850.00) {
				tax += (16701.00 * 0.10) + ((67901.00 - 16701.00) * 0.15) + ((137051.00 - 67901.00) * 0.25)
						+ ((taxableIncome - 137051.00) * 0.28);
			} else if (taxableIncome >= 208851.00 && taxableIncome <= 372950.00) {
				tax += (16701.00 * 0.10) + ((69701.00 - 16701.00) * 0.15) + ((137051.00 - 67901.00) * 0.25)
						+ ((208851.00 - 137051.00) * 0.28) + ((taxableIncome - 208851.00) * 0.33);
			} else {
				tax += (16701.00 * 0.10) + ((69701.00 - 16701.00) * 0.15) + ((137051.00 - 67901.00) * 0.25)
						+ ((208851.00 - 137051.00) * 0.28) + ((372951.00 - 208851.00) * 0.33)
						+ ((taxableIncome - 372951.00) * 0.35);
			}
		} else if (filingStatus == 2) {
			if (taxableIncome >= 0.00 && taxableIncome <= 8350.00) {
				tax = taxableIncome * 0.10;
			} else if (taxableIncome >= 8351.00 && taxableIncome <= 33950.00) {
				tax += (8351.00 * 0.10) + ((taxableIncome - 8351.00) * 0.15);
			} else if (taxableIncome >= 33951.00 && taxableIncome <= 68525.00) {
				tax += (8351.00 * 0.10) + ((33951.00 - 8351.00) * 0.15) + ((taxableIncome - 33951.00) * 0.25);
			} else if (taxableIncome >= 68526.00 && taxableIncome <= 104425.00) {
				tax += (8351.00 * 0.10) + ((33951.00 - 8351.00) * 0.15) + ((68526.00 - 33951.00) * 0.25)
						+ ((taxableIncome - 68526.00) * 0.28);
			} else if (taxableIncome >= 104426.00 && taxableIncome <= 186475.00) {
				tax += (8351.00 * 0.10) + ((33951.00 - 8351.00) * 0.15) + ((68526.00 - 33951.00) * 0.25)
						+ ((104426.00 - 68526.00) * 0.28) + ((taxableIncome - 104426.00) * 0.33);
			} else {
				tax += (8351.00 * 0.10) + ((33951.00 - 8351.00) * 0.15) + ((68526.00 - 33951.00) * 0.25)
						+ ((104426.00 - 68526.00) * 0.28) + ((186476.00 - 104426.00) * 0.33)
						+ ((taxableIncome - 186776.00) * 0.35);
			}
		} else {
			if (taxableIncome >= 0.00 && taxableIncome <= 11950.00) {
				tax = taxableIncome * 0.10;
			} else if (taxableIncome >= 11951.00 && taxableIncome <= 45500.00) {
				tax += (11951.00 * 0.10) + ((taxableIncome - 11951.00) * 0.15);
			} else if (taxableIncome >= 45501.00 && taxableIncome <= 117450.00) {
				tax += (11951.00 * 0.10) + ((45501.00 - 11951.00) * 0.15) + ((taxableIncome - 45501.00) * 0.25);
			} else if (taxableIncome >= 117451.00 && taxableIncome <= 190200.00) {
				tax += (11951.00 * 0.10) + ((45501.00 - 11951.00) * 0.15) + ((117451.00 - 45501.00) * 0.25)
						+ ((taxableIncome - 117451.00) * 0.28);
			} else if (taxableIncome >= 190201.00 && taxableIncome <= 372950.00) {
				tax += (11951.00 * 0.10) + ((45501.00 - 11951.00) * 0.15) + ((117451.00 - 45501.00) * 0.25)
						+ ((190201.00 - 117451.00) * 0.28) + ((taxableIncome - 190201.00) * 0.33);
			} else {
				tax += (11951.00 * 0.10) + ((45501.00 - 11951.00) * 0.15) + ((117451.00 - 45501.00) * 0.25)
						+ ((190201.00 - 117451.00) * 0.28) + ((372951.00 - 190201.00) * 0.33)
						+ ((taxableIncome - 372951.00) * 0.35);
			}
		}
		System.out.print("Your tax is: " + tax);
		input.close();
		System.exit(1);
	}
}
