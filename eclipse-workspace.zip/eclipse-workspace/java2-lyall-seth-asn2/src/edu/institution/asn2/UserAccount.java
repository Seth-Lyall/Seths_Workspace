package edu.institution.asn2;

public abstract class UserAccount {
	// Instance Variable(s)
	private String username;
	private String password;
	
	// Constructor(s)
	// A constructor accepting two strings; one to initiate the user name and the other to initiate the password. 
	public UserAccount(String username, String password) {
		this.username = username;
		this.password = password;
	}
	
	// Mutator(s) and Accessor(s)
	// Returns the user name supplied on the constructor.
	public String getUsername() {
		return this.username;
	}
	
	// Returns true of the argument is the same as this account's password, false otherwise.
	public boolean isPasswordCorrect(String password) {
		if ((password != null) && (password != "") && (password.equals(this.password))) {
			return true;
		} else {
			return false;
		}
	}
	
	// Sets the type of this user. @param type the type.
	public abstract void setType(String type);
	
	// Displays the user name for the account.
	@Override // Override the toString method.
	public String toString() {
		return getUsername();
	}
	
	// Uses the user name as the unique identifier for an account.
	@Override // Override the hashCode method.
	public int hashCode() {
		return getUsername().hashCode();
	}
	
	// Two accounts are equal if their user names are identical.
	@Override // Override the equals method.
	public boolean equals(Object o) {
		return this.toString().equals(o.toString());
	}
}
