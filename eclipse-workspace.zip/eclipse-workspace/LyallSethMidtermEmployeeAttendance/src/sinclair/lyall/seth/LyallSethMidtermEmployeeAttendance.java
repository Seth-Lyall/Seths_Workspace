/**
 * Seth Lyall - MVCTC
 * Oct 4, 2022
 */

package sinclair.lyall.seth;

import java.util.Scanner;

public class LyallSethMidtermEmployeeAttendance {

	static Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		Scanner inputM = new Scanner(System.in);
		// Constant variable for size of the arrays.
		final int arraySize = 10;
		// Declare arrays and fill in some data.
		String[] name = new String[arraySize];
		String[] address = new String[arraySize];
		String[] presence = new String[arraySize];
		String[] arrivalTime = new String[arraySize];
		name[0] = "Hubert         ";
		name[1] = "Frankie        ";
		address[0] = "3024 Airedale Rd.   ";
		address[1] = "6782 Greengage Dr.  ";
		presence[0] = "Present        ";
		presence[1] = "Present        ";
		arrivalTime[0] = "07:30 AM";
		arrivalTime[1] = "N/A";
		// Variable for holding user menu choice.
		int choice = 0;
		// Variable for whether or not the user wants to do another action or quit the
		// program.
		String continueProgram = "y";
		// Variable for holding what name the user wants to use for a function.
		String nameChoice = "";

		while (choice != 9 && continueProgram.charAt(0) != 'n') {

			// Display the menu and get user input.
			System.out.println("");
			System.out.println("Employee Attendance Tracker:");
			System.out.println("1. List all employees.");
			System.out.println("2. List present employees.");
			System.out.println("3. List absent employees.");
			System.out.println("4. Find an employee by name.");
			System.out.println("5. Add an employee.");
			System.out.println("6. Delete an employee by name.");
			System.out.println("7. Mark an employee's attendance by name.");
			System.out.println("8. Mark an employee's absence by name.");
			System.out.println("9. Exit the program.");
			System.out.println("");

			do {
				System.out.print("Choose an action: ");
				choice = inputM.nextInt();
			} while (choice < 1 || choice > 9);

			// Perform one of nine methods or actions depending on previous user input.
			switch (choice) {
			case 1:
				System.out.println("");
				System.out.println("All employees will be listed regardless of presence.");
				System.out.println("Press ENTER to continue:");
				listAllEmployees(name, address, presence, arrivalTime);
				break;
			case 2:
				System.out.println("");
				System.out.println("All employees with the presence 'Present' will be listed.");
				System.out.println("Press ENTER to continue:");
				listPresentEmployees(name, address, presence, arrivalTime);
				break;
			case 3:
				System.out.println("");
				System.out.println("All employees with the presence 'Absent' will be listed.");
				System.out.println("Press ENTER to continue:");
				listAbsentEmployees(name, address, presence, arrivalTime);
				break;
			case 4:
				System.out.println("");
				System.out.print("Please enter the name you want to search for: ");
				nameChoice = inputM.next();
				System.out.println("Press ENTER to continue:");
				findEmployeeByName(name, address, presence, arrivalTime, nameChoice);
				break;
			case 5:
				System.out.println("");
				System.out.println("New employees will be placed in first open location in the array.");
				System.out.println("Press ENTER to continue:");
				addEmployee(name, address, presence, arrivalTime);
				break;
			case 6:
				System.out.println("");
				System.out.println("Other records will not be reordered after the deletion.");
				System.out.println("Press ENTER to continue:");
				deleteEmployeeByName(name, address, presence, arrivalTime);
				break;
			case 7:
				System.out.println("");
				System.out.println("Attendance will be marked present; you will need to also input time attended.");
				System.out.println("Press ENTER to continue:");
				markEmployeeAttendanceByName(name, address, presence, arrivalTime);
				break;
			case 8:
				System.out.println("");
				System.out.println("Attendance will be marked absent.");
				System.out.println("Press ENTER to continue:");
				markEmployeeAbsenceByName(name, address, presence, arrivalTime);
				break;
			case 9:
				System.out.println("");
				System.out.println("Ending the program.");
				break;
			default:
				System.out.println("Invalid choice.");
				break;
			}

			// If the user input 9 for their action of choice, or they said "n" to continue,
			// end the program.
			if (choice != 9) {
				do {
					System.out.println("");
					System.out.print("Continue? (y/n): ");
					continueProgram = inputM.next();
				} while (continueProgram.charAt(0) != 'y' && continueProgram.charAt(0) != 'n');
				if (continueProgram.charAt(0) == 'n') {
					System.out.println("");
					System.out.println("Ending the program.");
				}
			}
		}
		// Close main input.
		inputM.close();
	}

	public static void listAllEmployees(String[] name, String[] address, String[] presence, String[] arrivalTime) {
		// Clear Buffer, and make sure user reads the method guide.
		input.nextLine();
		boolean tableTopDisplayed = false;
		// Loop through name array to find a full spot, and display information for that
		// employee while only displaying the table header once.
		for (int i = 0; i < name.length; i++) {
			if (name[i] != null) {
				if (tableTopDisplayed == false) {
					System.out.print("First Name:    ");
					System.out.print("Address:            ");
					System.out.print("Presence:      ");
					System.out.println("Arrival Time:");
					tableTopDisplayed = true;
				}
				System.out.println(name[i] + address[i] + presence[i] + arrivalTime[i]);
			}
		}
	}

	public static void listPresentEmployees(String[] name, String[] address, String[] presence, String[] arrivalTime) {
		boolean tableTopDisplayed = false;
		boolean presentEmployee = false;
		// Clear Buffer, and make sure user reads the method guide.
		input.nextLine();

		// Loop through presence array to find a full spot, and display information for
		// that employee while only displaying the table header once.
		for (int i = 0; i < presence.length; i++) {
			if (presence[i] != null) {
				if (presence[i].charAt(0) == 'P') {
					presentEmployee = true;
					if (presentEmployee == true) {
						if (tableTopDisplayed == false) {
							System.out.print("First Name:    ");
							System.out.print("Address:            ");
							System.out.print("Presence:      ");
							System.out.println("Arrival Time:");
							tableTopDisplayed = true;
						}
						System.out.println(name[i] + address[i] + presence[i] + arrivalTime[i]);
						presentEmployee = false;
					}
				}
			}
		}
	}

	public static void listAbsentEmployees(String[] name, String[] address, String[] presence, String[] arrivalTime) {
		boolean tableTopDisplayed = false;
		boolean absentEmployee = false;
		// Clear Buffer, and make sure user reads the method guide.
		input.nextLine();

		// Loop through presence array to find a full spot, and display information for
		// that employee while only displaying the table header once.
		for (int i = 0; i < presence.length; i++) {
			if (presence[i] != null) {
				if (presence[i].charAt(0) == 'A') {
					absentEmployee = true;
					if (absentEmployee == true) {
						if (tableTopDisplayed == false) {
							System.out.print("First Name:    ");
							System.out.print("Address:            ");
							System.out.print("Presence:      ");
							System.out.println("Arrival Time:");
							tableTopDisplayed = true;
						}
						System.out.println(name[i] + address[i] + presence[i] + arrivalTime[i]);
						absentEmployee = false;
					}
				}
			}
		}
	}

	public static void findEmployeeByName(String[] name, String[] address, String[] presence, String[] arrivalTime,
			String nameChoice) {
		boolean tableTopDisplayed = false;
		// Clear Buffer, and make sure user reads the method guide.
		input.nextLine();

		// Loop through name array to find a name match, and display information for
		// that employee while only displaying the table header once.
		for (int i = 0; i < name.length; i++) {
			if (name[i] != null) {
				if (name[i].contains(nameChoice)) {
					if (tableTopDisplayed == false) {
						System.out.print("First Name:    ");
						System.out.print("Address:            ");
						System.out.print("Presence:      ");
						System.out.println("Arrival Time:");
						tableTopDisplayed = true;
					}
					System.out.println(name[i] + address[i] + presence[i] + arrivalTime[i]);
				}
			}
		}
	}

	public static void addEmployee(String[] name, String[] address, String[] presence, String[] arrivalTime) {
		boolean newEmployee = false;
		// Clear Buffer, and make sure user reads the method guide.
		input.nextLine();

		// Loop through the name array for an empty spot, and prompt the user to enter
		// the following data.
		for (int i = 0; i < name.length; i++) {
			if (name[i] == null && newEmployee == false) {

				// Get user input for the employee name, and adjust its length accordingly.
				System.out.print("Please enter the name of your employee: ");
				name[i] = input.nextLine();
				if (name[i].length() < 15) {
					while (name[i].length() < 15) {
						name[i] += " ";
					}
				}

				// Get user input for the employee address, and adjust its length accordingly.
				System.out.print("");
				System.out.print("Please enter the address of your employee: ");
				address[i] = input.nextLine();
				if (address[i].length() < 20) {
					while (address[i].length() < 20) {
						address[i] += " ";
					}
				}

				// Get user input for employee presence with the markEmployeePresence function.
				System.out.print("");
				presence[i] = markEmployeePresence();

				// Get user input for arrival time with the markEmployeeArrivalTime function.
				// If the presence is present, run the function.
				// Otherwise, arrival time is N/A.
				System.out.print("");
				if (presence[i].contains("P")) {
					arrivalTime[i] = markEmployeeArrivalTime();
				} else {
					arrivalTime[i] = "N/A";
				}

				// Mark that the new employee was created so the for loop stop adding new
				// employees.
				newEmployee = true;
			}
		}
	}

	public static void deleteEmployeeByName(String[] name, String[] address, String[] presence, String[] arrivalTime) {
		// Clear Buffer, and make sure user reads the method guide.
		input.nextLine();
		String deletedName = "";
		boolean deleted = false;
		System.out.println("");
		System.out.print("Please enter the name of the employee you would like to delete: ");
		deletedName = input.nextLine();

		// Loop through the name array to find the matching name the user input, then
		// set all values in that location to null.
		for (int i = 0; i < name.length; i++) {
			if (name[i] != null && name[i].contains(deletedName) && deleted == false) {
				name[i] = null;
				address[i] = null;
				presence[i] = null;
				arrivalTime[i] = null;
				System.out.println(deletedName + " has been erased completely.");
				deleted = true;
			}
		}
	}

	public static void markEmployeeAttendanceByName(String[] name, String[] address, String[] presence,
			String[] arrivalTime) {
		// Clear Buffer, and make sure user reads the method guide.
		input.nextLine();
		String nameChoice = "";
		System.out.print("Enter the name of the employee you want to mark: ");
		nameChoice = input.nextLine();

		// Loop through the name array until an empty space is found, then mark the
		// presence as present and run the markEmployeeArrivalTime function.
		for (int i = 0; i < name.length; i++) {
			if (name[i] != null) {
				if (name[i].contains(nameChoice)) {
					presence[i] = "Present        ";
					arrivalTime[i] = markEmployeeArrivalTime();
				}
			}
		}
	}

	public static void markEmployeeAbsenceByName(String[] name, String[] address, String[] presence,
			String[] arrivalTime) {
		// Clear Buffer, and make sure user reads the method guide.
		input.nextLine();
		String nameChoice = "";
		System.out.println("");
		System.out.print("Enter the name of the employee you want to mark: ");
		nameChoice = input.nextLine();

		// Loop through the name array until an empty space is found, and mark the
		// presence as absent and the arrival time as N/A.
		for (int i = 0; i < name.length; i++) {
			if (name[i] != null) {
				if (name[i].contains(nameChoice)) {
					presence[i] = "Absent         ";
					arrivalTime[i] = "N/A";
				}
			}
		}
	}

	public static String markEmployeePresence() {
		String employeePresence = "";
		String presenceNum = " ";

		System.out.print("1. Present\n2. Absent\nEnter your employee's presence: ");

		// Receive user input as 1 or 2, 1 is present, and 2 is absent.
		while (presenceNum.charAt(0) != '1' && presenceNum.charAt(0) != '2') {
			presenceNum = input.next();
		}
		if (presenceNum.charAt(0) == '1') {
			employeePresence = "Present        ";
		} else {
			employeePresence = "Absent         ";
		}

		// Return employee presence.
		return employeePresence;
	}

	public static String markEmployeeArrivalTime() {
		String newEmployeeArrivalTime = "";
		int arrivalTimeHour = 0;
		int arrivalTimeMinute = 0;
		int amOrPm = 0;
		String arrivalTimeHourString = "";
		String arrivalTimeMinuteString = "";
		String amOrPmString = "";

		// Enter the hour the employee arrived from 1 to 12. If the number is below 10,
		// add a zero before the number to make it two characters to match the format.
		System.out.print("Enter the hour of arrival: ");
		do {
			arrivalTimeHour = input.nextInt();
		} while (arrivalTimeHour < 1 || arrivalTimeHour > 12);
		if (arrivalTimeHour < 10) {
			arrivalTimeHourString = "0" + arrivalTimeHour;
		} else {
			arrivalTimeHourString = arrivalTimeHour + "";
		}

		// Enter the minute the employee arrived from 1 to 60. If the number is below
		// 10, add a zero before the number to make it two characters to match the
		// format.
		System.out.print("Enter the minute of arrival: ");
		do {
			arrivalTimeMinute = input.nextInt();
		} while (arrivalTimeMinute < 0 || arrivalTimeMinute > 60);
		if (arrivalTimeMinute < 10) {
			arrivalTimeMinuteString = "0" + arrivalTimeMinute;
		} else {
			arrivalTimeMinuteString = arrivalTimeMinute + "";
		}

		// Have the user enter either 1 for AM, and 2 for PM arrival time.
		System.out.print("Arrived AM, or PM? (Enter 1 for AM, and 2 for PM!): ");
		do {
			amOrPm = input.nextInt();
		} while (amOrPm != 1 && amOrPm != 2);
		if (amOrPm == 1) {
			amOrPmString = "AM";
		} else {
			amOrPmString = "PM";
		}

		// Concatenate all of the strings for the whole employee arrival time.
		newEmployeeArrivalTime += arrivalTimeHourString + ":" + arrivalTimeMinuteString + " " + amOrPmString + "";

		// Return employee arrival time.
		return newEmployeeArrivalTime;
	}

}
