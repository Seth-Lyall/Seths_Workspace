/**
 * Seth Lyall - MVCTC
 * Nov 8, 2022
 */
package chap1415JavaFX;

public class InvestmentValue {
	// Member(s)
	private double investmentAmount;
	private int years;
	private double annualInterestRate;

	// Constructor(s)
	public InvestmentValue() {
		this.setInvestmentAmount(0.00);
		this.setYears(0);
		this.setAnnualInterestRate(0.00);
	}

	public InvestmentValue(double i, int y, double a) {
		this.setInvestmentAmount(i);
		this.setYears(y);
		this.setAnnualInterestRate(a);
	}

	// Getter(s)
	public double getInvestmentAmount() {
		return this.investmentAmount;
	}

	public int getYears() {
		return this.years;
	}

	public double getAnnualInterestRate() {
		return this.annualInterestRate;
	}

	public double getFutureValue() {
		return (getInvestmentAmount()
				* Math.pow((1.00 + ((getAnnualInterestRate() / 12.00) / 100.00)), (getYears() * 12.00)));
	}

	// Setter(s)
	public void setInvestmentAmount(double i) {
		this.investmentAmount = i;
	}

	public void setYears(int y) {
		this.years = y;
	}

	public void setAnnualInterestRate(double a) {
		this.annualInterestRate = a;
	}
}
