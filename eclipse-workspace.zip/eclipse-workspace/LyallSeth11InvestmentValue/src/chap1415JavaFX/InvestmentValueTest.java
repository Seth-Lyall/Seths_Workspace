/**
 * Seth Lyall - MVCTC
 * Nov 8, 2022
 */
package chap1415JavaFX;

import java.util.InputMismatchException;

import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class InvestmentValueTest extends Application {
	private TextField investmentAmountTextField = new TextField();
	private TextField yearsTextField = new TextField();
	private TextField annualInterestRateTextField = new TextField();
	private TextField futureValueTextField = new TextField();

	@Override // Override the start method in the Application class.
	public void start(Stage primaryStage) {
		// Create a pane and set its properties.
		GridPane gridPane = new GridPane();
		gridPane.setAlignment(Pos.CENTER);
		gridPane.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
		gridPane.setHgap(5.5);
		gridPane.setVgap(5.5);

		// Add nodes to the pane.
		Label investmentAmountLabel = new Label("Investment Amount");
		investmentAmountTextField.setAlignment(Pos.TOP_RIGHT);
		gridPane.add(investmentAmountLabel, 0, 0);
		gridPane.add(investmentAmountTextField, 1, 0);

		Label yearsLabel = new Label("Years");
		yearsTextField.setAlignment(Pos.TOP_RIGHT);
		gridPane.add(yearsLabel, 0, 1);
		gridPane.add(yearsTextField, 1, 1);

		Label annualInterestRateLabel = new Label("Annual Interest Rate");
		annualInterestRateTextField.setAlignment(Pos.TOP_RIGHT);
		gridPane.add(annualInterestRateLabel, 0, 2);
		gridPane.add(annualInterestRateTextField, 1, 2);

		Label futureValueLabel = new Label("Future Value");
		futureValueTextField.setAlignment(Pos.TOP_RIGHT);
		futureValueTextField.setEditable(true);
		futureValueTextField.setMouseTransparent(true);
		futureValueTextField.setFocusTraversable(false);
		gridPane.add(futureValueLabel, 0, 3);
		gridPane.add(futureValueTextField, 1, 3);

		Button calculate = new Button("Calculate");
		calculate.setOnAction(e -> calculateFutureValue());
		gridPane.add(calculate, 1, 4);
		GridPane.setHalignment(calculate, HPos.RIGHT);

		// Create the scene and put the pane in the scene.
		Scene scene = new Scene(gridPane, 300, 175);

		// Set the stage title, scene, and show the stage.
		primaryStage.setTitle("Investment Value");
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	private void calculateFutureValue() {
		// Initialize values for storing user input to create an InvestmentValue class.
		double investmentAmount = 0.00;
		int years = 0;
		double annualInterestRate = 0.00;
		boolean noExceptions = true;

		// Try to parse the text from the investment value text field to
		// investmentAmount. Catch an InputMismatchException, and an
		// IllegalArgumentException.
		try {
			investmentAmount = Double.parseDouble(investmentAmountTextField.getText());
			if (investmentAmount < 0.00)
				throw new IllegalArgumentException("Please enter a positive investment amount.");
		} catch (InputMismatchException ex) {
			noExceptions = false;
			System.out.println("Please enter a number for investment amount.");
		} catch (IllegalArgumentException ex) {
			noExceptions = false;
			System.out.println("Exception: " + ex.getMessage());
		}

		// Try to parse the text from the years text field to investmentAmount. Catch an
		// InputMismatchException, and an IllegalArgumentException.
		try {
			years = Integer.parseInt(yearsTextField.getText());
			if (years < 0)
				throw new IllegalArgumentException("Please enter a positive year.");
		} catch (InputMismatchException ex) {
			noExceptions = false;
			System.out.println("Please enter a number for the investment duration in years.");
		} catch (IllegalArgumentException ex) {
			noExceptions = false;
			System.out.println("Exception: " + ex.getMessage());
		}

		// Try to parse the text from the annual interest rate text field to
		// investmentAmount. Catch an InputMismatchException, and an
		// IllegalArgumentException.
		try {
			annualInterestRate = Double.parseDouble(annualInterestRateTextField.getText());
			if (annualInterestRate < 0.00)
				throw new IllegalArgumentException("Please enter a positive interest rate.");
		} catch (InputMismatchException ex) {
			noExceptions = false;
			System.out.println("Please enter a number for the investment's annual interest rate.");
		} catch (IllegalArgumentException ex) {
			noExceptions = false;
			System.out.println("Exception: " + ex.getMessage());
		}

		// If no exceptions were thrown, change the future value text field to
		// getFutureValue() from the InvestmentValue class.
		if (noExceptions) {
			InvestmentValue investment = new InvestmentValue(investmentAmount, years, annualInterestRate);
			futureValueTextField.setText(String.format("$%,10.2f", investment.getFutureValue()));
		}
	}

	public static void main(String[] args) {
		// Launch the overridden start method.
		launch(args);
	}
}
