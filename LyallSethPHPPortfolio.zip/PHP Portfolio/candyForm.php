<?php

if (isset($_POST['txtCustomerName'])){
    $customerName=$_POST['txtCustomerName'];
    $boxSize=$_POST['boxSize'];
    $candyList=$_POST['candyList'];
    echo '<h1>'. $customerName .'</h1>'. $boxSize;
    echo '<h1>'. $customerName .'</h1>'. $candyList;
}
echo '
    
<!DOCTYPE html>
<html>
<head>
<title>Candy Form</title>
</head>
<body>
    
<form method="POST" action="candyForm.php">
<h2>Candy Form</h2>
<p><label for="txtcustomerName">Name</label>
<input type="text" name="txtcustomerName">

';

echo '

<fieldset id="boxSize">
<legend>Select the Box Size.</legend>
<input type="radio" name="boxSize" value="L">Large
<input type="radio" name="boxSize" value="M">Medium
<input type="radio" name="boxSize" value="S">Small
</fieldset>

<fieldset id="password">
<legend>Input Your Password.</legend>
<input type="password" name="boxSize" value="L">
</fieldset>
    
<fieldset id="candyList">
<legend>Select your favorite candies.</legend>
<input type="checkbox" name="candies" value="Chocolates">Chocolates
<input type="checkbox" name="candies" value="HardCandies">Hard Candies
<input type="checkbox" name="candies" value="Gummies">Gummies
</fieldset>
    
<label for="filling">Choose your fillings:</label>
    
<select name="fillings" id="fillings">
<optgroup label="foreign">
  <option value="strawberry">Strawberry</option>
  <option value="chocolate">Chocolate</option>
  <option value="cream">Cream</option>
  <option value="custard">Custard</option>
  </optgroup>
</select>

<fieldset id="textArea">
<legend>Comments.</legend>
<input type="textArea" name="comments">
</fieldset>
    
<input type="submit">
<input type="reset">
</form>
</body>
</html>

';
?>