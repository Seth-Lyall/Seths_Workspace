<?php

require ("dbconn.php");
include ("head.php");
include ("nav.php");

session_start();   
session_unset();   
$_SESSION['visited'] = 0;  
header("Refresh: 3; url=login.php");

echo '<h3>You have been logged out, and will be redirected shortly.</h3>';

?>

<?php 
include "footer.php";
?>
