<?php

require ("dbconn.php");
include ("head.php");
include ("nav.php");

    echo '
        
    <!DOCTYPE html>
    <html>
    <head>
    <title>Login</title>
    </head>
    <body>
        
    <form method="POST" action="discussionBoard.php">
    <h2>Discussion Board</h2>
        
    <h3>
       <p>
            <label for="message"><tt>Start Typing:</label>
            <br />
            <input type="textArea" name="message">
       </p>
            <input type="submit">
            <input type="reset">
    </h3>
        
    ';
    
    $message = htmlspecialchars($_POST['message']);
    
    if (isset($_POST['message'])){
        $sql = "INSERT INTO discussionBoard (email, username, role, access, message) VALUES (?, ?, 0, 1, ?)";
        $query = $con->prepare($sql);
        $query->bind_param('sss', htmlspecialchars($_SESSION["sessionEmail"]),  htmlspecialchars($_SESSION["sessionUsername"]), $message);
        $query->execute();
    }
    unset($message);
    $message = '';
    unset($_POST);
    $_POST = array();
    
    $sql = "SELECT * FROM discussionBoard ORDER BY email DESC";
    
    if ($result = $con->query($sql)){
        while ($row = $result->fetch_assoc()){
            $queryUsername = $row['username'];
            $queryMessage = $row['message'];
            echo '
            <br>' . '<p><b>' . $queryUsername . ':</b> ' . $queryMessage . '</p>' . '<br>'
            ;
        }
    }
    
?>

<?php 
include "footer.php";
?>
