<?php
require 'dbconn.php';

$sql =  'create table discussionBoard (email VARCHAR(64) NOT NULL, username VARCHAR(16) NOT NULL, role INTEGER(1) NOT NULL, access BOOLEAN NOT NULL, message VARCHAR(500) NOT NULL)';

if ($con->query($sql)){
    echo '<h2>Discussion Board Table Created</h2>';
}
else{
    echo '<h2>Error creating table: '.$con->error.' '.$con->error.'<h2>';
}

$con->close();
?>