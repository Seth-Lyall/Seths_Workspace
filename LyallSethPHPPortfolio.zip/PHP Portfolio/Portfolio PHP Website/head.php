<?php 

//error_reporting(E_ALL); ini_set('display_errors', '1');
session_start();

?>

<head>
<meta charset="ISO-8859-1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="SethStyle.css">
<title>Seth Lyall's Portfolio</title>
</head>