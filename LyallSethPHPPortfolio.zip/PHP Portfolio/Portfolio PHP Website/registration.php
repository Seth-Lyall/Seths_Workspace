<?php

require ("dbconn.php");
include ("head.php");
include ("nav.php");

if (isset($_POST['email'])){ // If these variables have values, continue, otherwise display the form.
    $email = htmlspecialchars($_POST['email']);
    $username = htmlspecialchars($_POST['username']);
    $password = htmlspecialchars(md5($_POST['password']));
    echo '<h3>Success 1.</h3>';
    $sql = "SELECT COUNT(email) AS NumberOfAccounts FROM registration WHERE email = ? AND username = ?";
    $query = $con->prepare($sql);
    echo '<h3>Success prepare.</h3>';
    $query->bind_param('ss', $email, $username);
    $query->execute();
    echo '<h3>Success execute.</h3>';
    $query->store_result();
    $query->bind_result($result);
    $query->fetch(); // Check if the created user already exists.
    echo '<h3>Success fetch.</h3>';
    if ($result == 0){ // Check if the query returned any results.
        $sql = "INSERT INTO registration (email, username, password, role, access) VALUES (?, ?, ?, 0, 1)";
        $query = $con->prepare($sql);
        $query->bind_param('sss', $email, $username, $password);
        $query->execute();
        
        echo '<h3>You have successfully created your account, you will be redirected shortly.</h3>';
        header("Refresh: 3; url=login.php");
        // The account is created, and the user is redirected to the login page.
        
    }
    else {
        
        echo '<h3>Sorry, this email or username already exists.</h3>';
        header("Refresh: 3; url=registration.php");
    }
}
else {
    
    echo '
        
    <!DOCTYPE html>
    <html>
    <head>
    <title>Register</title>
    </head>
    <body>
            
    <form method="POST" action="registration.php">
    <h2>Register</h2>
            
    <h3>
        <p>
            <label for="email"><tt>Email</label>
            <br />
            <input type="email" name="email">
        </p>
        <p>
            <label for="username"><tt>Username</label>
            <br />
            <input type="text" name="username">
        </p>
        <p>
            <label for="password"><tt>Password</label>
            <br />
            <input type="password" name="password">
        </p>
            
            <br />
            <input type="submit">
            <input type="reset">
    </h3>
            
    ';
    
}

?>

<?php 
include "footer.php";
?>
