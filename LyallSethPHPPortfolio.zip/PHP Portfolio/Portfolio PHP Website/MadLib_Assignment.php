<?php
include "head.php";
include "nav.php";
?>

	<article>

		<h1>Summary</h1>

		<table>
			<tr>
				<td>				
					<p>						
						This project was done for my instructor, Melissa Goodall, for the 2021-2022 MVCTC school year during the first month of august. 
						The program asks for a variety of word inputs to create an output in the shape of a story. It asks for common words without
						telling the user what they create as the program is running, so the story is a surprise in the end. However, tense was not
						explained during the creation of the program, so the result was difficult to read, but it could be done.
						The output of this program is as follows:
					</p>
				</td>
			</tr>
		</table>

	</article>
	
	<article>
	
	<img src="Mad Lib Output.PNG" class="img-fluid" alt="The Output for my Program.">
	
	</article>

<?php 
include "footer.php";
?>

</body>
</html>