<?php
include "head.php";
include "nav.php";
?>

	<article>

		<h1>Summary</h1>

		<table>
			<tr>
				<td>				
					<p>						
						This project was done for my instructor, Melissa Goodall, for the 2021-2022 MVCTC school year during the first month of august. 
						The program calculates the cost for financing various tablet computers and desktop computers in a hypothetical situation.
						The output of this program is as follows:
					</p>
				</td>
			</tr>
		</table>

	</article>
	
	<article>
	
	<img src="Basic Math Program Output.PNG" class="img-fluid" alt="The Output for my Program.">
	
	</article>

<?php 
include "footer.php";
?>

</body>
</html>