<?php
include "head.php";
include "nav.php";
?>

	<article>

		<h2 style="font-size: 30px; font-family: customFont; src: url(https://fonts.google.com/specimen/Ms+Madi);"><i>"Success is a lousy teacher. It seduces smart people into thinking they can't lose." - Bill Gates</i></h2>
		
		<h1>What is My Home School?</h1>

		<table>
			<tr>
				<td>
					<ul>
						<li>Bethel High School.</li>
					</ul>
				</td>
			</tr>
		</table>
		
		<h1>What Are My Pets? My Friends? Hobbies?</h1>
		
		<table>
			<tr>
				<td>
					<ul>
						<li>I live in a family of five, along with a dog I have had for years now. His name is
						Benji.</li>
						<li>I would say that those I consider friends are those that share my ideas and values.
						It is good to make friends with those who share your ideas to keep a steady
						relationship with that person, and to help grow that friendship through exposure to one
						another.</li>
						<li>I thoroughly enjoy going out to the movies or other sorts of shows with my family.
						Whenever given the chance to do something like that, I almost always have a suggestion.
						</li>
					</ul>
				</td>
			</tr>
		</table>

	</article>

	<article>
	
	<h1>What to Know Professionally?</h1>
	
<div class="accordion" id="accordionExample">
<div class="accordion-item">
	<h2 class="accordion-header" id="headingOne">
		<button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
		My Work:
		</button>
	</h2>
<div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
<div class="accordion-body">
	<p>
		<b style="margin-top: 10px; margin-left: 10px; margin-right: 10px; margin-bottom: 10px;">How I Prefer to Work and Get the Job Done:</b>
	</p>
	<table>
		<tr>
			<td>
				<ul>
					<li>I am a determined, hard worker.</li>
					<li>I will sacrifice my time to get the job done.</li>
					<li>I only provide my best work.</li>
				</ul>
			</td>
		</tr>
	</table>
</div>
</div>
</div>
<div class="accordion-item">
	<h2 class="accordion-header" id="headingTwo">
		<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
		My Conversational Skills:
		</button>
	</h2>
<div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
<div class="accordion-body">
	<p>
		<b style="margin-top: 10px; margin-left: 10px; margin-right: 10px; margin-bottom: 10px;">A Brief Description of How I Interact With Others:</b>
	</p>
	<table>
		<tr>
			<td>
				<ul>
					<li>I can clearly communicate ideas.</li>
					<li>I am open to correction.</li>
					<li>I have patience when helping others.</li>
					<li>I enjoy working as a team.</li>
					</ul>
				</td>
			</tr>
		</table>
</div>
</div>
</div>
</div>
	
	</article>

<?php 
include "footer.php";
?>

</body>
</html>