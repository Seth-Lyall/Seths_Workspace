<?php
require 'dbconn.php';

$sql =  'create table registration (id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, email VARCHAR(64) NOT NULL, username VARCHAR(16) NOT NULL, password VARCHAR(256) NOT NULL, role INTEGER(1) NOT NULL, access BOOLEAN NOT NULL )';

if ($con->query($sql)){
    echo '<h2>Registration Table Created</h2>';
}
else{
    echo '<h2>Error creating table: '.$con->error.' '.$con->error.'<h2>';
}

$con->close();
?>