<?php

require ('dbconn.php');

if (isset($_SESSION['visited'])){
    $query = 'select * from hit_counter order by hitCounter desc limit 1';
    
// Gets output from a select query.
    if ($result = $con->query($query)){
        $row = $result->fetch_assoc();
        $nbrhits = $row['hitCounter'];
        echo ' Visitor #: ' . $nbrhits;
    }
}
else {
    $_SESSION ['visited'] = 1;
    $sql= 'insert into hit_counter (hitCounter) values (NULL)';
    
// Inserts new record.
// Variables in the same order as they were created in the tables.
    if ($con->query($sql)){
        $query = 'select * from hit_counter order by hitCounter desc limit 1';
        $nbrhits = 0;
        if ($result = $con->query($query)){
            while ($row = $result->fetch_assoc()){
                $nbrhits = $row['hitCounter'];
                echo ' Visitor #: ' . $nbrhits;
            }
            $result->free();
            
            $query = 'delete from hit_counter where hitCounter < ' . $nbrhits;
            
            if (!$con->query($query)){
                echo '<h2>Error: Cannot delete record(' . $con->errno . ') ' . $con->error . '</h2>';
            }
        }
    }
}

$con->close();

?>
