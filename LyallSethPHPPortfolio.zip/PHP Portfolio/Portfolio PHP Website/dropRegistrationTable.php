<?php
require 'dbconn.php';

$sql =  'drop table registration';

if ($con->query($sql)){
    echo '<h2>Registration Table Dropped</h2>';
}
else{
    echo '<h2>Error dropping table: '.$con->error.' '.$con->error.'<h2>';
}

$con->close();
?>