<?php 
session_start();
include "head.php";
?>

<?php 
include "nav.php";
?>

	<article>

		<h1>Summary</h1>

		<table>
			<tr>
				<td>				
					<p>						
						My name is Seth A. Lyall, and I am a Junior from Bethel Local School District in Miami 
						County. I am studying in the field of computer programming, and my goal is to leave 
						high school in good condition for a College setting. My interest in computers stems 
						from their presence in the modern world. Wherever you go, you will always discover 
						computers being put into action one way or another. They connect people through the 
						internet, they help	control machinery and buildings, they help to control the flow of
						power and people, and they help to keep the entire population generally connected and 
						orderly. I wish to improve the lives of people of any race, gender, and culture, by playing 
						a part in the creation of a more connected world. Being a part of this ever expanding field
						will be an honor, and I will do my best to be an example to any who come after me.
					</p>
				</td>
			</tr>
		</table>

	</article>

	<article>
	
<div class="accordion" id="accordionExample">
<div class="accordion-item">
	<h2 class="accordion-header" id="headingOne">
		<button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
		My Skills:
		</button>
	</h2>
<div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
<div class="accordion-body">
	<p>
		<b style="color:#3333FF; margin-top: 10px; margin-left: 10px; margin-right: 10px; margin-bottom: 10px;">My general skills are:</b>
	</p>
	<table>
		<tr>
			<td>
				<ul>
					<li>A good ability to solve problems.</li>
					<li>Effective critical thinking.</li>
					<li>Careful discernment of my own ideas.</li>
				</ul>
			</td>
		</tr>
	</table>
</div>
</div>
</div>
<div class="accordion-item">
	<h2 class="accordion-header" id="headingTwo">
		<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
		My Goals:
		</button>
	</h2>
<div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
<div class="accordion-body">
	<p>
		<b style="color:#3333FF; margin-top: 10px; margin-left: 10px; margin-right: 10px; margin-bottom: 10px;">My goals are:</b>
	</p>
	<table>
		<tr>
			<td>
				<ul>
					<li>To be a prominent member of a work force.</li>
					<li>To provide a can-do attitude to any setting.</li>
					<li>To provide support and guidance to others.</li>
					<li>To always be learning and improving.</li>
				</ul>
			</td>
		</tr>
	</table>
</div>
</div>
</div>
</div>
	
	</article>

<?php 
include "footer.php";
?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>