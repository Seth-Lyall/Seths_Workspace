<?php
require 'dbconn.php';

$sql =  'create table hit_counter (hitCounter INT NOT NULL AUTO_INCREMENT PRIMARY KEY)';

if ($con->query($sql)){
    echo '<h2>Hit Counter Table Created</h2>';
}
else{
    echo '<h2>Error creating table: '.$con->error.' '.$con->error.'<h2>';
}

$con->close();
?>