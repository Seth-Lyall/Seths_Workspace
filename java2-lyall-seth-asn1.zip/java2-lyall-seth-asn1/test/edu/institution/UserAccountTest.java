package edu.institution;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class UserAccountTest {

	@Test // The exact same user name should be returned by the getUsername() method.
	public void getUsernameReturnsSuppliedUsername() {
		UserAccount anonymousUser = new UserAccount("anonymous", "anonymousPassword");
		assertTrue(anonymousUser.getUsername().equals("anonymous"));
	}
	
	@Test // The exact same password should return true from the isPasswordCorrect() method.
	public void goodPasswordCheckReturnsTrue() {
		UserAccount anonymousUser = new UserAccount("anonymous", "anonymousPassword");
		assertTrue(anonymousUser.isPasswordCorrect("anonymousPassword"));
	}
	
	@Test // A different password should return false from the isPasswordCorrect() method.
	public void badPasswordCheckReturnsFalse() {
		UserAccount anonymousUser = new UserAccount("anonymous", "anonymousPassword");
		assertFalse(anonymousUser.isPasswordCorrect("publicPassword"));
	}
	
	@Test // A null password should return false from the isPasswordCorrect() method.
	public void nullPasswordCheckReturnsFalse() {
		UserAccount anonymousUser = new UserAccount("anonymous", "anonymousPassword");
		assertFalse(anonymousUser.isPasswordCorrect(null));
	}
	
	@Test // The toString() method should return the exact same value as the getUsername() method.
	public void toStringReturnsGetUsername() {
		UserAccount anonymousUser = new UserAccount("anonymous", "anonymousPassword");
		assertTrue(anonymousUser.getUsername().equals(anonymousUser.toString()));
	}
	
	@Test // Two different class instances should return true with the exact same user names with the getUsername() method.
	public void sameUsernamesSameClassesEqual() {
		UserAccount anonymousUser = new UserAccount("anonymous", "anonymousPassword");
		UserAccount publicUser = new UserAccount("anonymous", "anonymousPassword");
		assertTrue(anonymousUser.getUsername().equals(publicUser.getUsername()));
	}
	
	@Test // Two different UserAccount classes with two different user names should return false when the equals method is used.
	public void differentUsernamesInDifferentClassInstancesNotEqual() {
		UserAccount anonymousUser = new UserAccount("anonymous", "anonymousPassword");
		UserAccount publicUser = new UserAccount("public", "publicPassword");
		assertFalse(anonymousUser.equals(publicUser));
	}
	
	@Test // False should be returned when a separate object is compared to a UserAccount object.
	public void userAccountUsernameDifferentThanOtherObject() {
		UserAccount anonymousUser = new UserAccount("anonymous", "anonymousPassword");
		assertFalse(anonymousUser.equals(new Object()));
	}
	
	@Test // The hashCode() method should not return a value of zero when ran.
	public void hashCodeReturnsANonZeroValue() {
		UserAccount anonymousUser = new UserAccount("anonymous", "anonymousPassword");
		assertFalse(anonymousUser.hashCode() == 0);
	}
}
