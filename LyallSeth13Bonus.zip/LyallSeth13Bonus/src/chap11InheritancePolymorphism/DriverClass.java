/**
 * Seth Lyall - MVCTC
 * Dec 5, 2022
 */
package chap11InheritancePolymorphism;

import java.util.ArrayList;
import java.util.Scanner;

public class DriverClass {

	public static void main(String[] args) {
		final int arraySize = 100;
		Scanner input = new Scanner(System.in);
		ArrayList<ShiftWorker> workers = new ArrayList<ShiftWorker>(arraySize);
		ShiftWorker worker = new ShiftWorker();

		// Get user input for a new shift worker.
		System.out.print("Please enter your employee's first name: ");
		while (worker.getFirstName() == "" || worker.getFirstName() == null) {
			worker.setFirstName(input.nextLine());
		}
		System.out.print("Please enter your employee's last name: ");
		while (worker.getLastName() == "" || worker.getLastName() == null) {
			worker.setLastName(input.nextLine());
		}
		System.out.print("Please enter your employee's phone number. [000-0000-0000]: ");
		while (worker.getPhoneNumber() == "" || worker.getPhoneNumber() == null) {
			worker.setPhoneNumber(input.nextLine());
		}
		System.out.print("Please enter your employee's shift number. [ 1 = Day, 2 = Night ]: ");
		while (worker.getShiftNumber() != 1 && worker.getShiftNumber() != 2) {
			worker.setShiftNumber(input.nextInt());
		}
		if (worker.getShiftNumber() != 1 && worker.getShiftNumber() != 2) {
			System.out.println("Please enter only 1 or 2 for the shift number.");
			worker.setShiftNumber(1);
		}
		System.out.print("Please enter your employee's hourly pay rate: ");
		do {
			worker.setPayRate(input.nextDouble());
		} while (worker.getPayRate() < 0.00 || worker.getPayRate() > Double.MAX_VALUE);
		System.out.print("Please enter your employee's hours worked: ");
		do {
			worker.setHoursWorked(input.nextDouble());
		} while (worker.getHoursWorked() < 0.00 || worker.getHoursWorked() > Double.MAX_VALUE);

		// Add the new shift worker to the workers array list.
		workers.add(worker);

		// Add three more workers initialized with ShiftWorker class constructors.
		workers.add(new ShiftWorker("Gregor", "Meierson", "937-321-9876", 18.75, 40.00, 2));
		workers.add(new ShiftWorker("Malar", "Palla", "937-222-1234", 33.34, 25.55, 1));
		workers.add(new ShiftWorker("Serena", "Moreau", "937-898-4567", 25.24, 41.75, 2));

		// Display all Shift Workers.
		System.out.println("");
		System.out.println("This employee list contains " + workers.size() + " elements:\n[");
		for (int i = 0; i < workers.size(); i++) {
			System.out.println(workers.get(i).toString());
		}
		System.out.println("]");

		input.close();
	}
}
