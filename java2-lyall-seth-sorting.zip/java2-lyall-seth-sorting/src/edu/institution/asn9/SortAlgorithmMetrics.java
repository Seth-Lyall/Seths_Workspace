package edu.institution.asn9;

import java.util.List;
import java.time.Duration;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class SortAlgorithmMetrics {
	
	@SuppressWarnings("static-access")
	public List<MetricData> retrieveMetrics() {
		final int ARRAY_SIZE = 80000;
		List<MetricData> metricDataList = new ArrayList<MetricData>();
		List<Integer> list = new ArrayList<Integer>();
		Integer template[] = {};
		Random random = new Random();
		
		for (int i = 0; i < ARRAY_SIZE; i++) {
			list.add(random.nextInt());
		}
		Integer numbers[] = list.toArray(template);
		
		LocalTime startTime;
		LocalTime endTime;
		long duration;
		
		// Bubble Sort.
			Integer numbersCopy[] = new Integer[ARRAY_SIZE];
			System.arraycopy(numbers, 0, numbersCopy, 0, ARRAY_SIZE);
			MetricData bubbleMetricData = new MetricData(SortAlgorithm.BUBBLE_SORT);
			BubbleSort bubbleSort = new BubbleSort();
			
			startTime = LocalTime.now();
			bubbleSort.bubbleSort(numbersCopy);
			endTime = LocalTime.now();
			duration = Duration.between(startTime, endTime).toMillis();
			
			bubbleMetricData.setExecutionTime(duration);
			bubbleMetricData.setTimeComplexity(TimeComplexity.QUADRATIC);
			metricDataList.add(bubbleMetricData);
		// Heap Sort.
			numbersCopy = new Integer[ARRAY_SIZE];
			System.arraycopy(numbers, 0, numbersCopy, 0, ARRAY_SIZE);
			MetricData heapMetricData = new MetricData(SortAlgorithm.HEAP_SORT);
			HeapSort heapSort = new HeapSort();
			
			startTime = LocalTime.now();
			heapSort.heapSort(numbersCopy);
			endTime = LocalTime.now();
			duration = Duration.between(startTime, endTime).toMillis();
			
			heapMetricData.setExecutionTime(duration);
			heapMetricData.setTimeComplexity(TimeComplexity.LOGARITHMIC);
			metricDataList.add(heapMetricData);
		// Insertion Sort.
			numbersCopy = new Integer[ARRAY_SIZE];
			System.arraycopy(numbers, 0, numbersCopy, 0, ARRAY_SIZE);
			MetricData insertionMetricData = new MetricData(SortAlgorithm.INSERTION_SORT);
			InsertionSort insertionSort = new InsertionSort();
			
			startTime = LocalTime.now();
			insertionSort.insertionSort(numbersCopy);
			endTime = LocalTime.now();
			duration = Duration.between(startTime, endTime).toMillis();
			
			insertionMetricData.setExecutionTime(duration);
			insertionMetricData.setTimeComplexity(TimeComplexity.QUADRATIC);
			metricDataList.add(insertionMetricData);
		// Merge Sort.
			numbersCopy = new Integer[ARRAY_SIZE];
			System.arraycopy(numbers, 0, numbersCopy, 0, ARRAY_SIZE);
			MetricData mergeMetricData = new MetricData(SortAlgorithm.MERGE_SORT);
			MergeSort mergeSort = new MergeSort();
			
			startTime = LocalTime.now();
			mergeSort.mergeSort(numbersCopy);
			endTime = LocalTime.now();
			duration = Duration.between(startTime, endTime).toMillis();
			
			mergeMetricData.setExecutionTime(duration);
			mergeMetricData.setTimeComplexity(TimeComplexity.LOGARITHMIC);
			metricDataList.add(mergeMetricData);
		// Quick Sort.
			numbersCopy = new Integer[ARRAY_SIZE];
			System.arraycopy(numbers, 0, numbersCopy, 0, ARRAY_SIZE);
			MetricData quickMetricData = new MetricData(SortAlgorithm.QUICK_SORT);
			QuickSort quickSort = new QuickSort();
			
			startTime = LocalTime.now();
			quickSort.quickSort(numbersCopy);
			endTime = LocalTime.now();
			duration = Duration.between(startTime, endTime).toMillis();
			
			quickMetricData.setExecutionTime(duration);
			quickMetricData.setTimeComplexity(TimeComplexity.LOGARITHMIC);
			metricDataList.add(quickMetricData);
		// Selection Sort (Optional Extra Credit).
			numbersCopy = new Integer[ARRAY_SIZE];
			System.arraycopy(numbers, 0, numbersCopy, 0, ARRAY_SIZE);
			MetricData selectionMetricData = new MetricData(SortAlgorithm.SELECTION_SORT);
			SelectionSort selectionSort = new SelectionSort();
			
			startTime = LocalTime.now();
			selectionSort.selectionSort(numbersCopy);
			endTime = LocalTime.now();
			duration = Duration.between(startTime, endTime).toMillis();
			
			selectionMetricData.setExecutionTime(duration);
			selectionMetricData.setTimeComplexity(TimeComplexity.QUADRATIC);
			metricDataList.add(selectionMetricData);
		
		Collections.sort(metricDataList);
		
		return metricDataList;
	 }
}
