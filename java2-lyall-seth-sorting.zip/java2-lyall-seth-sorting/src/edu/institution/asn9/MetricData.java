package edu.institution.asn9;

import java.util.Objects;

public class MetricData implements Comparable<MetricData> {
	// Member Variable(s)
	// The sort algorithm used to sort the data.
	private SortAlgorithm sortAlgorithm;
	// The time complexity for the sort algorithm.
	private TimeComplexity timeComplexity;
	// The time (in milliseconds) that it took to sort the data.
	private long executionTime;
	
	// Constructor(s)
	public MetricData(SortAlgorithm sa) {
		this.sortAlgorithm = sa;
	}

	// Getter(s) and Accessor(s)
	public SortAlgorithm getSortAlgorithm() {
		return this.sortAlgorithm;
	}

	public TimeComplexity getTimeComplexity() {
		return this.timeComplexity;
	}
	
	public long getExecutionTime() {
		return this.executionTime;
	}

	public void setTimeComplexity(TimeComplexity timeComplexity) {
		this.timeComplexity = timeComplexity;
	}

	public void setExecutionTime(long executionTime) {
		this.executionTime = executionTime;
	}

	@Override // Override the hashCode() method.
	public int hashCode() {
		return Objects.hash(sortAlgorithm);
	}

	@Override // Override the equals() method.
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MetricData other = (MetricData) obj;
		return sortAlgorithm == other.sortAlgorithm;
	}

	@Override // Override the toString method.
	public String toString() {
		String sortName = "" + getSortAlgorithm().display();
		String executionTime = "" + getExecutionTime() + " ms";
		String timeComplexity = "" + getTimeComplexity().display();
		
		while (sortName.length() != 15) {
			sortName += " ";
		}
		while (executionTime.length() != 15) {
			executionTime += " ";
		}
		while (timeComplexity.length() != 23) {
			timeComplexity += " ";
		}

		return "| " + sortName + "| " + executionTime + "| " + timeComplexity + "|";
	}

	@Override // Override the compareTo() method.
	public int compareTo(MetricData o) {
		if (getExecutionTime() < o.getExecutionTime()) {
			return -1;
		} else if (getExecutionTime() > o.getExecutionTime()) {
			return 1;
		} else {
			return 0;
		}
	}
}
