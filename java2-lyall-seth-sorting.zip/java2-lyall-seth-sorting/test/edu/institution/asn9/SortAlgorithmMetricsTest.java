package edu.institution.asn9;

import org.junit.Test;
import java.util.List;
import java.util.ArrayList;
import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertArrayEquals;

public class SortAlgorithmMetricsTest {

	@Test // Asserts that each returned metrics list has 5 entries (6 because selection sort is added).
		  // Asserts that each returned metrics list has been sorted correctly (least to greatest execution time).
		  // Asserts that each returned metric in its metrics list has the correct Time Complexity for the sort algorithm.
		  // All tests are ran on one method because the execution time for the test is at or above 90 seconds.
		  // Running more than one test would take several minutes.
	public void assertAllMetricListsReturnAppropriateSortedData() {
		SortAlgorithmMetrics sort = new SortAlgorithmMetrics();
		List<MetricData> metricData1 = new ArrayList<MetricData>();
		List<MetricData> metricData2 = new ArrayList<MetricData>();
		List<MetricData> metricData3 = new ArrayList<MetricData>();
		boolean metricsSorted = true;
		boolean correctTimeComplexity = true;
		long previousExecutionTime = 0;
		
		System.out.println("Retrieving Metrics...");
		
		// Read in and validate the first list of metrics.
		int metricCount1 = 0;
		for(MetricData md: sort.retrieveMetrics()) {
			metricData1.add(md);
			metricCount1++;
		}
		assertEquals(6, metricCount1); // Assert that six metrics have been created.
		for (MetricData md: metricData1) {
			if (md.getExecutionTime() < previousExecutionTime) {
				metricsSorted = false;
			}
			previousExecutionTime = md.getExecutionTime();
		}
		assertEquals(true, metricsSorted); // Assert that the metric data is sorted correctly.
		for (MetricData md: metricData1) {
			switch (md.getSortAlgorithm()) {
			case BUBBLE_SORT:
			if (md.getTimeComplexity() != TimeComplexity.QUADRATIC) {
				correctTimeComplexity = false;
			}
				break;
			case INSERTION_SORT:
				if (md.getTimeComplexity() != TimeComplexity.QUADRATIC) {
					correctTimeComplexity = false;
				}
				break;
			case MERGE_SORT:
				if (md.getTimeComplexity() != TimeComplexity.LOGARITHMIC) {
					correctTimeComplexity = false;
				}
				break;
			case QUICK_SORT:
				if (md.getTimeComplexity() != TimeComplexity.LOGARITHMIC) {
					correctTimeComplexity = false;
				}
				break;
			case HEAP_SORT:
				if (md.getTimeComplexity() != TimeComplexity.LOGARITHMIC) {
					correctTimeComplexity = false;
				}
				break;
			default:
				if (md.getTimeComplexity() != TimeComplexity.QUADRATIC) {
					correctTimeComplexity = false;
				}
			}
		}
		assertEquals(true, correctTimeComplexity); // Assert that the metric data has the correct time complexity.
		
		// Read in and validate the second list of metrics.
		int metricCount2 = 0;
		previousExecutionTime = 0;
		metricsSorted = true;
		correctTimeComplexity = true;
		for(MetricData md: sort.retrieveMetrics()) {
			metricData2.add(md);
			metricCount2++;
		}
		assertEquals(6, metricCount2); // Assert that six metrics have been created.
		for (MetricData md: metricData2) {
			if (md.getExecutionTime() < previousExecutionTime) {
				metricsSorted = false;
			}
			previousExecutionTime = md.getExecutionTime();
		}
		assertEquals(true, metricsSorted); // Assert that the metric data is sorted correctly.
		for (MetricData md: metricData2) {
			switch (md.getSortAlgorithm()) {
			case BUBBLE_SORT:
			if (md.getTimeComplexity() != TimeComplexity.QUADRATIC) {
				correctTimeComplexity = false;
			}
				break;
			case INSERTION_SORT:
				if (md.getTimeComplexity() != TimeComplexity.QUADRATIC) {
					correctTimeComplexity = false;
				}
				break;
			case MERGE_SORT:
				if (md.getTimeComplexity() != TimeComplexity.LOGARITHMIC) {
					correctTimeComplexity = false;
				}
				break;
			case QUICK_SORT:
				if (md.getTimeComplexity() != TimeComplexity.LOGARITHMIC) {
					correctTimeComplexity = false;
				}
				break;
			case HEAP_SORT:
				if (md.getTimeComplexity() != TimeComplexity.LOGARITHMIC) {
					correctTimeComplexity = false;
				}
				break;
			default:
				if (md.getTimeComplexity() != TimeComplexity.QUADRATIC) {
					correctTimeComplexity = false;
				}
			}
		}
		assertEquals(true, correctTimeComplexity); // Assert that the metric data has the correct time complexity.
		
		// Read in and validate the third list of metrics.
		int metricCount3 = 0;
		previousExecutionTime = 0;
		metricsSorted = true;
		correctTimeComplexity = true;
		for(MetricData md: sort.retrieveMetrics()) {
			metricData3.add(md);
			metricCount3++;
		}
		assertEquals(6, metricCount3); // Assert that six metrics have been created.
		for (MetricData md: metricData3) {
			if (md.getExecutionTime() < previousExecutionTime) {
				metricsSorted = false;
			}
			previousExecutionTime = md.getExecutionTime();
		}
		assertEquals(true, metricsSorted); // Assert that the metric data is sorted correctly.
		for (MetricData md: metricData3) {
			switch (md.getSortAlgorithm()) {
			case BUBBLE_SORT:
			if (md.getTimeComplexity() != TimeComplexity.QUADRATIC) {
				correctTimeComplexity = false;
			}
				break;
			case INSERTION_SORT:
				if (md.getTimeComplexity() != TimeComplexity.QUADRATIC) {
					correctTimeComplexity = false;
				}
				break;
			case MERGE_SORT:
				if (md.getTimeComplexity() != TimeComplexity.LOGARITHMIC) {
					correctTimeComplexity = false;
				}
				break;
			case QUICK_SORT:
				if (md.getTimeComplexity() != TimeComplexity.LOGARITHMIC) {
					correctTimeComplexity = false;
				}
				break;
			case HEAP_SORT:
				if (md.getTimeComplexity() != TimeComplexity.LOGARITHMIC) {
					correctTimeComplexity = false;
				}
				break;
			default:
				if (md.getTimeComplexity() != TimeComplexity.QUADRATIC) {
					correctTimeComplexity = false;
				}
			}
		}
		assertEquals(true, correctTimeComplexity); // Assert that the metric data has the correct time complexity.
		
		// All data is displayed below.
		System.out.println("+----------------+----------------+------------------------+");
		System.out.println("| Sort Name      | Execution Time | Big-O Value            |");
		System.out.println("+----------------+----------------+------------------------+");
		for(MetricData md: metricData1) {
			System.out.println(md.toString());
		}
		System.out.println("+----------------+----------------+------------------------+");
		for(MetricData md: metricData2) {
			System.out.println(md.toString());
		}
		System.out.println("+----------------+----------------+------------------------+");
		for(MetricData md: metricData3) {
			System.out.println(md.toString());
		}
		System.out.println("+----------------+----------------+------------------------+");
	}
}
