/**
 * Seth Lyall - MVCTC
 * Dec 8, 2022
 */
package LyallSethFinal;

import java.io.FileNotFoundException;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class EmployeeAttendanceGUI extends Application{

	// Initialization of the employees array and the employee file.
	public static java.io.File employeeFile = new java.io.File("empAtt.txt");
	private static final int arraySize = 100; // Constant variable for size of the arrays.
	private static ArrayList<Attendance> employees = new ArrayList<Attendance>(arraySize);
	
	// Initialization of the buttons.
	private Button listAllEmployees = new Button("List Employees");
	private Button listPresentEmployees = new Button("List Present Employees");
	private Button listAbsentEmployees = new Button("List Absent Employees");
	private Button addEmployee = new Button("Add an Employee");
	private Button findEmployeeByName = new Button("Find an Employee by Name");
	private Button deleteEmployeeByName = new Button("Delete an Employee by Name");
	private Button markEmployeeAttendanceByName = new Button("Mark Attendance by Name");
	private Button confirmAttendance = new Button("Confirm Attendance");
	private Button confirmEmployee = new Button("Confirm");
	private Button confirmDeletion = new Button("Confirm Deletion");
	private Button confirmName = new Button("Confirm Name");
	private Button returnToStart = new Button("Return");
	private Button exitProgramButton = new Button("Exit Program");
	
	// Initialization of the text labels.
	private Text employeeTableWindow = new Text(500, 100, "");
	private Label employeeNameLabel = new Label("Employee Name");
	private Label employeeAddressLabel = new Label("Employee Address");
	private Label employeePresenceLabel = new Label("Employee is Present");
	
	// Initialization of the text fields.
	private TextField employeeNameTextField = new TextField();
	private TextField employeeAddressTextField = new TextField();
	
	// Initialization of the presence check box.
	private CheckBox employeePresenceCheckBox = new CheckBox();
	
	// Initialization of the window VBox and the VBoxes for employee data input.
	private VBox window = new VBox();
	private VBox employeeDataLabelColumn = new VBox();
	private VBox employeeDataTextFieldColumn = new VBox();
	
	// Initialization of the employee data input HBox and the button HBoxes.
	private HBox employeeDataInput = new HBox();
	private HBox buttons1 = new HBox();
	private HBox buttons2 = new HBox();
	
	@Override // Override the start method in the Application class.
	public void start(Stage primaryStage) {
		// Read any older employee records in from empAtt.txt
		readEmployees();

		// Set the properties for text fields and labels.
		employeeNameLabel.setContentDisplay(ContentDisplay.CENTER);
		employeeNameLabel.setPadding(new Insets(5, 5, 5, 5));
		employeeAddressLabel.setContentDisplay(ContentDisplay.CENTER);
		employeeAddressLabel.setPadding(new Insets(5, 5, 5, 5));
		employeePresenceLabel.setContentDisplay(ContentDisplay.CENTER);
		employeePresenceLabel.setPadding(new Insets(5, 5, 5, 5));
		employeeNameTextField.setPadding(new Insets(5, 5, 5, 5));
		employeeAddressTextField.setPadding(new Insets(5, 5, 5, 5));

		// Set the properties for the buttons.
		listAllEmployees.setContentDisplay(ContentDisplay.CENTER);
		listAllEmployees.setPadding(new Insets(5, 5, 5, 5));
		listAllEmployees.setOnAction(e -> allEmployeesTable());
		listPresentEmployees.setContentDisplay(ContentDisplay.CENTER);
		listPresentEmployees.setPadding(new Insets(5, 5, 5, 5));
		listPresentEmployees.setOnAction(e -> presentEmployeesTable());
		listAbsentEmployees.setContentDisplay(ContentDisplay.CENTER);
		listAbsentEmployees.setPadding(new Insets(5, 5, 5, 5));
		listAbsentEmployees.setOnAction(e -> absentEmployeesTable());
		findEmployeeByName.setContentDisplay(ContentDisplay.CENTER);
		findEmployeeByName.setPadding(new Insets(5, 5, 5, 5));
		findEmployeeByName.setOnAction(e -> findAnEmployeeByName());
		addEmployee.setContentDisplay(ContentDisplay.CENTER);
		addEmployee.setPadding(new Insets(5, 5, 5, 5));
		addEmployee.setOnAction(e -> addAnEmployee());
		deleteEmployeeByName.setContentDisplay(ContentDisplay.CENTER);
		deleteEmployeeByName.setPadding(new Insets(5, 5, 5, 5));
		deleteEmployeeByName.setOnAction(e -> deleteAnEmployeeByName());
		markEmployeeAttendanceByName.setContentDisplay(ContentDisplay.CENTER);
		markEmployeeAttendanceByName.setPadding(new Insets(5, 5, 5, 5));
		markEmployeeAttendanceByName.setOnAction(e -> markAttendanceByName());
		exitProgramButton.setContentDisplay(ContentDisplay.CENTER);
		exitProgramButton.setPadding(new Insets(10, 10, 10, 10));
		exitProgramButton.setOnAction(e -> exitProgram());

		// Buttons for confirming actions.
		confirmEmployee.setContentDisplay(ContentDisplay.CENTER);
		confirmEmployee.setPadding(new Insets(5, 5, 5, 5));
		confirmEmployee.setOnAction(e -> confirmYourEmployee());
		confirmDeletion.setContentDisplay(ContentDisplay.CENTER);
		confirmDeletion.setPadding(new Insets(5, 5, 5, 5));
		confirmDeletion.setOnAction(e -> confirmDeletingEmployee());
		confirmAttendance.setContentDisplay(ContentDisplay.CENTER);
		confirmAttendance.setPadding(new Insets(5, 5, 5, 5));
		confirmAttendance.setOnAction(e -> confirmAttendanceByName());
		confirmName.setContentDisplay(ContentDisplay.CENTER);
		confirmName.setPadding(new Insets(5, 5, 5, 5));
		confirmName.setOnAction(e -> confirmEmployeesName());

		// Properties for return to start button and employee presence check box.
		returnToStart.setContentDisplay(ContentDisplay.CENTER);
		returnToStart.setPadding(new Insets(5, 5, 5, 5));
		returnToStart.setOnAction(e -> exitButton());
		employeePresenceCheckBox.setContentDisplay(ContentDisplay.CENTER);
		employeePresenceCheckBox.setPadding(new Insets(5, 5, 5, 5));

		// Add the main menu buttons to the three button VBoxes.
		buttons1.getChildren().addAll(addEmployee, deleteEmployeeByName, listAllEmployees, listPresentEmployees);
		buttons1.setPadding(new Insets(5, 5, 5, 5));
		buttons2.getChildren().addAll(listAbsentEmployees, findEmployeeByName,
				markEmployeeAttendanceByName);
		buttons2.setPadding(new Insets(5, 5, 5, 5));

		// Build the employeeData HBox with the two employee data columns.
		employeeDataInput.getChildren().addAll(employeeDataLabelColumn, employeeDataTextFieldColumn);
		employeeDataInput.setPadding(new Insets(5, 5, 5, 5));

		// Add the employee attendance table, the buttons, and the employeeData text
		// fields to the window VBox.
		window.getChildren().addAll(employeeTableWindow, buttons1, buttons2, exitProgramButton);
		window.setPadding(new Insets(5, 5, 5, 5));

		// Create the scene and put the border pane in the scene.
		Scene scene = new Scene(window, 520, 500);

		// Set the stage title, scene, and show the stage.
		primaryStage.setTitle("Employee Attendance");
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
	// Displays all employees with the toString() method.
	private void allEmployeesTable() {
		String allEmployees = "";
		for (int i = 0; i < employees.size(); i++) {
			allEmployees += employees.get(i).toString();
		}
		if (allEmployees == "") {
			employeeTableWindow.setText("There are no employees.");
		} else {
			employeeTableWindow.setText(allEmployees);
		}
	}

	// Displays present employees with the toString() method.
	private void presentEmployeesTable() {
		String presentEmployees = "";
		for (int i = 0; i < employees.size(); i++) {
			if (employees.get(i).getPresence() == true) {
				presentEmployees += employees.get(i).toString();
			}
		}
		if (presentEmployees == "") {
			employeeTableWindow.setText("There are no present employees.");
		} else {
			employeeTableWindow.setText(presentEmployees);
		}
	}
	
	// Displays absent employees with the toString() method.
	private void absentEmployeesTable() {
		String absentEmployees = "";
		for (int i = 0; i < employees.size(); i++) {
			if (employees.get(i).getPresence() == false) {
				absentEmployees += employees.get(i).toString();
			}
		}
		if (absentEmployees == "") {
			employeeTableWindow.setText("There are no absent employees.");
		} else {
			employeeTableWindow.setText(absentEmployees);
		}
	}
	
	// Displays buttons for entering an employee name and finding it.
	private void findAnEmployeeByName() {
		window.getChildren().removeAll(buttons1, buttons2, exitProgramButton);
		window.getChildren().addAll(employeeDataInput, confirmName, returnToStart, exitProgramButton);

		employeeDataLabelColumn.getChildren().addAll(employeeNameLabel);
		employeeDataTextFieldColumn.getChildren().addAll(employeeNameTextField);
	}

	// Displays all employees that contain the name entered in the employee name text field.
	private void confirmEmployeesName() {
		String employeeByName = "";
		for (int i = 0; i < employees.size(); i++) {
			if (employees.get(i).getName().contains(employeeNameTextField.getText())) {
				employeeByName += employees.get(i).toString();
			}
		}
		if (employeeByName == "") {
			employeeTableWindow.setText("There are no employees named " + employeeNameTextField.getText() + ".");
		} else {
			employeeTableWindow.setText(employeeByName);
		}
	}
	
	// Displays buttons needed to mark whether or not an employee attended by their name.
	private void markAttendanceByName() {
		window.getChildren().removeAll(buttons1, buttons2, exitProgramButton);
		window.getChildren().addAll(employeeDataInput, confirmAttendance, returnToStart, exitProgramButton);

		employeeDataLabelColumn.getChildren().addAll(employeeNameLabel, employeePresenceLabel);
		employeeDataTextFieldColumn.getChildren().addAll(employeeNameTextField, employeePresenceCheckBox);
	}
	
	// Sets the attendance of an employee given their name.
	private void confirmAttendanceByName() {
		boolean employeePresence;
		boolean employeeNameMatch = false;
		if (employeePresenceCheckBox.isSelected()) {
			employeePresence = true;
		} else {
			employeePresence = false;
		}
		for (int i = 0; i < employees.size(); i++) {
			if (employees.get(i).getName().contains(employeeNameTextField.getText())) {
				employees.get(i).setPresence(employeePresence);
				employeeTableWindow.setText(employeeNameTextField.getText() + "'s attendance has been set to " + employeePresence + ".");
				employeeNameMatch = true;
			}
		}
		if (!employeeNameMatch) {
			employeeTableWindow.setText("There are no employees named " + employeeNameTextField.getText() + ".");
		}
	}

	// Displays the buttons needed to add an employee.
	private void addAnEmployee() {
		window.getChildren().removeAll(buttons1, buttons2, exitProgramButton);
		window.getChildren().addAll(employeeDataInput, confirmEmployee, returnToStart, exitProgramButton);

		employeeDataLabelColumn.getChildren().addAll(employeeNameLabel, employeeAddressLabel, employeePresenceLabel);
		employeeDataTextFieldColumn.getChildren().addAll(employeeNameTextField, employeeAddressTextField, employeePresenceCheckBox);
	}
	
	// Adds an employee based on data input in the add an employee text fields and check box.
	private void confirmYourEmployee() {
		boolean isException = false;
		String na = employeeNameTextField.getText();
		String ad = employeeAddressTextField.getText();
		boolean pr = employeePresenceCheckBox.isSelected();
		try {
			if (na == null || na == "") {
				throw new IllegalArgumentException("Please enter a value for employee name.");
			} else if (ad == null || ad == "") {
				throw new IllegalArgumentException("Please enter a value for employee address.");
			}
		} catch (IllegalArgumentException ex) {
			employeeTableWindow.setText(ex.getMessage());
			isException = true;
		} finally {
			if (!isException) {
				employees.add(new Attendance(na, ad, pr));
				employeeTableWindow.setText(employeeNameTextField.getText() + " has been added.");
				writeEmployees();
			}
		}
	}
	
	// Displays the buttons needed to delete an employee record by their name.
	private void deleteAnEmployeeByName() {
		window.getChildren().removeAll(buttons1, buttons2, exitProgramButton);
		window.getChildren().addAll(employeeDataInput, confirmDeletion, returnToStart, exitProgramButton);

		employeeDataLabelColumn.getChildren().addAll(employeeNameLabel);
		employeeDataTextFieldColumn.getChildren().addAll(employeeNameTextField);
	}
	
	// Deletes the latest employee record with a matching name.
	private void confirmDeletingEmployee() {
		boolean employeeNameMatch = false;
		for (int i = 0; i < employees.size(); i++) {
			if (employees.get(i).getName().contains(employeeNameTextField.getText())) {
				employees.remove(i);
				employeeTableWindow.setText(employeeNameTextField.getText() + " has been deleted.");
				employeeNameMatch = true;
			}
		}
		if (!employeeNameMatch) {
			employeeTableWindow.setText("There are no employees named " + employeeNameTextField.getText() + ".");
		}
		writeEmployees();
	}

	// Closes all unneeded buttons and displays the main menu buttons.
	private void exitButton() {
		window.getChildren().removeAll(confirmAttendance, confirmEmployee, confirmDeletion, confirmName,
				returnToStart, employeeNameLabel, employeeAddressLabel, employeePresenceLabel,
				employeeNameTextField, employeeAddressTextField, employeePresenceCheckBox,
				employeeDataLabelColumn, employeeDataTextFieldColumn, employeeDataInput, exitProgramButton);
		employeeDataLabelColumn.getChildren().removeAll(confirmAttendance, confirmEmployee,
				confirmDeletion, confirmName, returnToStart, employeeNameLabel, employeeAddressLabel,
				employeePresenceLabel, employeeNameTextField, employeeAddressTextField,
				employeePresenceCheckBox, employeeDataLabelColumn,
				employeeDataTextFieldColumn, employeeDataInput);
		employeeDataTextFieldColumn.getChildren().removeAll(confirmAttendance, confirmEmployee,
				confirmDeletion, confirmName, returnToStart, employeeNameLabel, employeeAddressLabel,
				employeePresenceLabel, employeeNameTextField, employeeAddressTextField,
				employeePresenceCheckBox, employeeDataLabelColumn,
				employeeDataTextFieldColumn, employeeDataInput);
		window.getChildren().addAll(buttons1, buttons2, exitProgramButton);
		allEmployeesTable();
	}
	
	// Reads the saved employees from the empAtt.txt file.
	private void readEmployees() {
		String buffer = "";
		String name = "";
		String address = "";
		boolean presence = false;
		String date = "";
		try {
			java.util.Scanner fileInput = new java.util.Scanner(employeeFile);
			while (fileInput.hasNext()) {
				name = fileInput.nextLine();
				address = fileInput.nextLine();
				buffer = fileInput.nextLine();
				System.out.println(buffer);
				if (buffer.contains("true")) {
					presence = true;
				} else if (buffer.contains("false")) {
					presence = false;
				}
				date = fileInput.nextLine();
				employees.add(new Attendance(name, address, presence, date));
			}
			fileInput.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			try {
				java.io.PrintWriter fileOutput = new java.io.PrintWriter(employeeFile);
				fileOutput.print(" ");
				fileOutput.close();
			} catch (FileNotFoundException ex) {
				e.printStackTrace();
			}
		}
		allEmployeesTable();
	}

	// Writes all current employees to the empAtt.txt file.
	private void writeEmployees() {
		String allEmployees = "";
		for (int i = 0; i < employees.size(); i++) {
			allEmployees += employees.get(i).getName() + "\n" + 
							employees.get(i).getAddress() + "\n" + 
							employees.get(i).getPresence() + "\n" + 
							employees.get(i).getDate() + "\n";
		}
		try {
			java.io.PrintWriter fileOutput = new java.io.PrintWriter(employeeFile);
			fileOutput.print(allEmployees);
			fileOutput.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	// Saves the employees and closes the program.
	private void exitProgram() {
		writeEmployees();
		System.exit(0);
	}
	
	public static void main(String[] args) {
		// Launch the overridden start method.
		launch(args);
	}
}
