/*
 * Seth Lyall - MVCTC
 * Nov 14, 2022
 */
package chap16JavaFXUI;

public class TaxCalculator {
	// Member(s)
	private double taxableIncome;
	private int filingStatus;

	// Constructor(s)
	public TaxCalculator() {
		setTaxableIncome(0);
		setFilingStatus(0);
	}

	public TaxCalculator(double taxableIncomeInput, int filingStatusInput) {
		setTaxableIncome(taxableIncomeInput);
		setFilingStatus(filingStatusInput);
	}

	// Setter(s) and Getter(s)
	public void setTaxableIncome(double taxableIncomeInput) {
		this.taxableIncome = taxableIncomeInput;
	}

	public void setFilingStatus(int filingStatusInput) {
		this.filingStatus = filingStatusInput;
	}

	public double getTaxableIncome() {
		return this.taxableIncome;
	}

	public int getFilingStatus() {
		return this.filingStatus;
	}

	public double getTax() {
		double tax = 0.00;
		if (getFilingStatus() == 0) {
			if (getTaxableIncome() >= 0.00 && getTaxableIncome() <= 8350.00) {
				tax += getTaxableIncome() * 0.10;
			} else if (getTaxableIncome() >= 8351.00 && getTaxableIncome() <= 33950.00) {
				tax += (8351.00 * 0.10) + ((getTaxableIncome() - 8351.00) * 0.15);
			} else if (getTaxableIncome() >= 33951.00 && getTaxableIncome() <= 82250.00) {
				tax += (8351.00 * 0.10) + ((33951.00 - 8351.00) * 0.15) + ((getTaxableIncome() - 33951.00) * 0.25);
			} else if (getTaxableIncome() >= 82251.00 && getTaxableIncome() <= 171550.00) {
				tax += (8351.00 * 0.10) + ((33951.00 - 8351.00) * 0.15) + ((82251.00 - 33951.00) * 0.25)
						+ ((getTaxableIncome() - 82251.00) * 0.28);
			} else if (getTaxableIncome() >= 171551.00 && getTaxableIncome() <= 372950.00) {
				tax += (8351.00 * 0.10) + ((33951.00 - 8351.00) * 0.15) + ((82251.00 - 33951.00) * 0.25)
						+ ((171551.00 - 82251.00) * 0.28) + ((getTaxableIncome() - 171551.00) * 0.33);
			} else {
				tax += (8351.00 * 0.10) + ((33951.00 - 8351.00) * 0.15) + ((82251.00 - 33951.00) * 0.25)
						+ ((171551.00 - 82251.00) * 0.28) + ((372951.00 - 171551.00) * 0.33)
						+ ((getTaxableIncome() - 372951.00) * 0.35);
			}
		} else if (getFilingStatus() == 1) {
			if (getTaxableIncome() >= 0.00 && getTaxableIncome() <= 16700.00) {
				tax = getTaxableIncome() * 0.10;
			} else if (getTaxableIncome() >= 16701.00 && getTaxableIncome() <= 67900.00) {
				tax += (16701.00 * 0.10) + ((getTaxableIncome() - 16701.00) * 0.15);
			} else if (getTaxableIncome() >= 67901.00 && getTaxableIncome() <= 137050.00) {
				tax += (16701.00 * 0.10) + ((67901.00 - 16701.00) * 0.15) + ((getTaxableIncome() - 67901.00) * 0.25);
			} else if (getTaxableIncome() >= 137051.00 && getTaxableIncome() <= 208850.00) {
				tax += (16701.00 * 0.10) + ((67901.00 - 16701.00) * 0.15) + ((137051.00 - 67901.00) * 0.25)
						+ ((getTaxableIncome() - 137051.00) * 0.28);
			} else if (getTaxableIncome() >= 208851.00 && getTaxableIncome() <= 372950.00) {
				tax += (16701.00 * 0.10) + ((67901.00 - 16701.00) * 0.15) + ((137051.00 - 67901.00) * 0.25)
						+ ((208851.00 - 137051.00) * 0.28) + ((getTaxableIncome() - 208851.00) * 0.33);
			} else {
				tax += (16701.00 * 0.10) + ((67901.00 - 16701.00) * 0.15) + ((137051.00 - 67901.00) * 0.25)
						+ ((208851.00 - 137051.00) * 0.28) + ((372951.00 - 208851.00) * 0.33)
						+ ((getTaxableIncome() - 372951.00) * 0.35);
			}
		} else if (getFilingStatus() == 2) {
			if (getTaxableIncome() >= 0.00 && getTaxableIncome() <= 8350.00) {
				tax = getTaxableIncome() * 0.10;
			} else if (getTaxableIncome() >= 8351.00 && getTaxableIncome() <= 33950.00) {
				tax += (8351.00 * 0.10) + ((getTaxableIncome() - 8351.00) * 0.15);
			} else if (getTaxableIncome() >= 33951.00 && getTaxableIncome() <= 68525.00) {
				tax += (8351.00 * 0.10) + ((33951.00 - 8351.00) * 0.15) + ((getTaxableIncome() - 33951.00) * 0.25);
			} else if (getTaxableIncome() >= 68526.00 && getTaxableIncome() <= 104425.00) {
				tax += (8351.00 * 0.10) + ((33951.00 - 8351.00) * 0.15) + ((68526.00 - 33951.00) * 0.25)
						+ ((getTaxableIncome() - 68526.00) * 0.28);
			} else if (getTaxableIncome() >= 104426.00 && getTaxableIncome() <= 186475.00) {
				tax += (8351.00 * 0.10) + ((33951.00 - 8351.00) * 0.15) + ((68526.00 - 33951.00) * 0.25)
						+ ((104426.00 - 68526.00) * 0.28) + ((getTaxableIncome() - 104426.00) * 0.33);
			} else {
				tax += (8351.00 * 0.10) + ((33951.00 - 8351.00) * 0.15) + ((68526.00 - 33951.00) * 0.25)
						+ ((104426.00 - 68526.00) * 0.28) + ((186476.00 - 104426.00) * 0.33)
						+ ((getTaxableIncome() - 186776.00) * 0.35);
			}
		} else {
			if (getTaxableIncome() >= 0.00 && getTaxableIncome() <= 11950.00) {
				tax = getTaxableIncome() * 0.10;
			} else if (getTaxableIncome() >= 11951.00 && getTaxableIncome() <= 45500.00) {
				tax += (11951.00 * 0.10) + ((getTaxableIncome() - 11951.00) * 0.15);
			} else if (getTaxableIncome() >= 45501.00 && getTaxableIncome() <= 117450.00) {
				tax += (11951.00 * 0.10) + ((45501.00 - 11951.00) * 0.15) + ((getTaxableIncome() - 45501.00) * 0.25);
			} else if (getTaxableIncome() >= 117451.00 && getTaxableIncome() <= 190200.00) {
				tax += (11951.00 * 0.10) + ((45501.00 - 11951.00) * 0.15) + ((117451.00 - 45501.00) * 0.25)
						+ ((getTaxableIncome() - 117451.00) * 0.28);
			} else if (getTaxableIncome() >= 190201.00 && getTaxableIncome() <= 372950.00) {
				tax += (11951.00 * 0.10) + ((45501.00 - 11951.00) * 0.15) + ((117451.00 - 45501.00) * 0.25)
						+ ((190201.00 - 117451.00) * 0.28) + ((getTaxableIncome() - 190201.00) * 0.33);
			} else {
				tax += (11951.00 * 0.10) + ((45501.00 - 11951.00) * 0.15) + ((117451.00 - 45501.00) * 0.25)
						+ ((190201.00 - 117451.00) * 0.28) + ((372951.00 - 190201.00) * 0.33)
						+ ((getTaxableIncome() - 372951.00) * 0.35);
			}
		}
		return tax;
	}
}
